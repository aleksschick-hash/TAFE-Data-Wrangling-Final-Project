

* Settings for the Brazil Rio crime & education project 

// * run quietly without STATA-window output (for cleanliness)
// qui {
********************  C O D E  ******************************

* store the code directory in a global	
global code  "${proj_git}/code"

	* create the code directory
	cap mkdir 	 "${code}"
	* create the standard subdirectories
	foreach dir in a b e {
		cap mkdir "${code}/`dir'"
		}

********************  D A T A  ******************************

* set the data directory & subdirectories
global data  	"${project}/data" 
global raw   	"${data}/raw"
global tmp    	"${data}/temp"

	cap mkdir "${data}"
	cap mkdir "${raw}"
	cap mkdir "${tmp}"
	
* directory for the processed (initial round subsamples) and clean (with changes) project-specific data 
global processed 	"${data}/processed"
global clean  	 	"${data}/clean"
	
	cap mkdir "${clean}"
	cap mkdir "${processed}"


*****************  R E S U L T S  ***************************

* create results folder and subfolders if not present 
global results   "${proj_shared}/results"

* store the results subfolders into globals 
global figures   "${results}/figures"
global tables    "${results}/tables"

	* store the results directory in a global	
	cap mkdir  		 "${results}"
	cap mkdir  		 "${figures}"
	cap mkdir  		 "${tables}"

	
********************************************************
*			 Colors & Graph Settings
********************************************************

* set plot background colors 
global graphregion 		graphregion(color(white) fcolor(white) lwidth(medium) lcolor(gray))

global hist_colors    	"color(ebblue%40) "
global graphreg_hist_by "by( , graphregion(color(white) fcolor(white) lwidth(medium) lcolor(gray)) )  color(ebblue%40)"


/* set color sequences */

global mcolor_seq "mcolor(pink%60 cranberry%80  red%60 orange%80  dkorange%80  gold%80  sandb%80  sand%80  lime%40  midgreen%70  eltgreen%80  emerald%80  eltblue%80  ebblue%80  blue%60 navy%80 purple%70 erose%80 )"	

global mcolors_32 "mcolor(dknavy%80 navy%80 edkblue%80 emidblue%80 ebblue%80 eltblue%80 ltblue%80 bluishgray%80 ltbluishgray%80  dimgray%80 gray%80 olive_teal%80 eltgreen%80  teal%80  forest_green%80  emerald%80  dkgreen%80  green%80  midgreen%80  mint%80  khaki%80  ltkhaki%80  sand%80  sandb%80  gold%80  orange%70  dkorange%80  orange_red%80  cranberry%80 maroon%80 erose%80 )"	

global mcolors_32 "mcolor(dknavy%80 navy%80 edkblue%80 emidblue%80 ebblue%80 eltblue%80 ltblue%80 bluishgray%80  olive_teal%80  eltgreen%80  teal%80  emerald%80  dkgreen%80   midgreen%80  mint%80   ltkhaki%80  sand%80  sandb%80  gold%80  dkorange%60  orange%80    cranberry%80 maroon%80 erose%80  purple%40)"	

global mcolor_seq_5 "mcolor(cranberry%80  orange%80  gold%80   midgreen%70  emerald%80  ebblue%80  navy%80 purple%70 )"


* bar colors 
global bar_colors4_pairs	`"  bar(1 , color(navy%70))  bar(2 , color(navy%30))  bar(3, color(ebblue%70))  	bar(4, color(ebblue%30))  	bar(5 , color(lavender%70))    bar(6, color(lavender%20))     bar(7 , color(gold%70))  bar(8, color(gold%30) )  "'

global bar_colors4	`" bar(1 , color(navy%70))  bar(2, color(ebblue%70))  bar(3 , color(lavender%70))  bar(4 , color(gold%70)) "'

global bar_colors6	`"  bar(1 , color(navy%70)) bar(2 , color(eltblue%70))  bar(3 , color(eltgreen%70))  bar(4 , color(khaki%70))   bar(5 , color(orange%80))  bar(6, color(cranberry%70) )  "'

global bar_colors8  `"  bar(1 , color(navy%70))  	bar(2 , color(ebblue%70))  	bar(3 , color(eltblue%60))  	bar(4 , color(olive_teal%70))   bar(5 , color(midgreen%70))  bar(6 , color(gold%70))   bar(7 , color(orange%80))  bar(8, color(cranberry%70) )  "'

global bar_colors8_v2	`"  bar(1 , color(navy%70))  	bar(2 , color(ebblue%70))  	bar(3 , color(eltblue%60))  	bar(4 , color(ebg%70))  bar(5 , color(lavender%50))    bar(6, color("218 112 214"%30))     bar(7 , color(purple%30))  bar(8, color(purple%60) )  "'

// global bar_colors8_v2	`"  bar(1 , color(navy%70))  	bar(2 , color(ebblue%70))  	bar(3 , color(eltblue%60))  	bar(4 , color(ebg%70))   bar(5 , color(lavender%20))  bar(6 , color(lavender%70))   bar(7 , color(purple%20))  bar(8, color(purple%70) )  "'

global bar_colors	`" bar(1 , color(dknavy%70)) 	 bar(2, color(navy%70) )  	 	bar(3 , color(edkblue%70))  	 bar(4 , color(emidblue%70))  	bar(5, color(ebblue%70))  bar(6 , color(eltblue%70))     bar(7 , color(ltblue%70)) 	  bar(8, color(bluishgray%70) )  	 bar(40 , color(ltbluishgray%70))  bar(40 , color(dimgray%70)) 	 bar(40, color(gray%70)) bar(9 , color(olive_teal%70))  bar(10 , color(eltgreen%70))  bar(40 , color(forest_green%70))  bar(11, color(emerald%70) )   bar(12 , color(dkgreen%70))   bar(40 , color(green%70)) bar(13, color(midgreen%70) )   bar(40 , color(khaki%70))   bar(40 , color(ltkhaki%70)) 	 bar(14, color(sand%70) )  	     bar(15 , color(sandb%70))   	bar(16 , color(gold%70))  bar(17, color(dkorange%60) )   bar(18 , color(orange%80))   bar(40 , fcolor(orange_red%70))  	bar(19, color(cranberry%70) )   bar(20 , color(maroon%70))     bar(21 , color(erose%80))  bar(40 , color(olive%40))   	bar(22 , color(purple%40))   bar(22 , color(olive%30)) bar(22 , color(gray%30))   "'


// graph bar took_q1-took_q22, over(treat, relabel(1 "Control (0)" 2 "Treated (1)"))    ///
// 							 legend(off)  $bar_colors   $graphregion  ///
// 							 title(Quiz Taking in LD Micro FA17 by Treatment) 
//							 

/* Gloobal for significance stars */
global star = "* 0.1 ** 0.05 *** 0.01"

****************************************************************************************************
// * end of quiet loop 
// }

*************************************************

* Display that the file ran 
 di "  Project configurations were set  "
	