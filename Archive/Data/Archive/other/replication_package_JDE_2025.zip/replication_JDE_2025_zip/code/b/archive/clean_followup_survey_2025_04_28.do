
/*

* This file merges and cleans the follow-up survey to the participant roster 

*/


 
do "${code}/b/process_followup_responses.do"


* pull the file with the email list of participants identified as valid responses for follow up 
use "${processed}/mh_survey_uniqueid_email_treat_for_followup.dta", replace 

	// NOTE: the file above was created on Google Drive from "${clean}/mh_survey_uniqueid_email_treat.dta"
	// 		 by adding the names of Alisher/Ida to send initial email invites 
	//  	 (the addition of the name is not replicated using STATA code)

	rename name sender_name 

	replace email = lower(email)
	
	drop if email  == ""
	
	
	* fix leading zeros 
	replace email = "a01285012@tex.mx" if  email == "a1285012@tec.mx"
	replace email = "a00833393@tec.mx" if  email == "a000833393@tec.mx"
	
	* fix apparent typos
	replace email = "a00840798@tex.mx" if  email == "a00840798@tex.mc"
	
	replace email = "a00843064@tec.mx" if  email == "a00843064@tec.mz"
	replace email = "a01178778@tec.mx" if  email == "a01178778@tec.mc"
	
	
	
	* merge in the response emails 
	merge 1:1 email using "${processed}/followup_2025_05/response_emails${date_stamp}.dta" , keep(master match)

	* get an indicator for invalid emails 
	gen invalid_email = 0
		
		* fix Ida's non-delivery emails 
		replace invalid_email = 1 if email == "a000833393@tec.mx"   	// attempted to fix: removing a leading zero
		replace invalid_email = 1 if email == "a1285012@tec.mx"  		// attempted to fix:   adding a leading zero
	
		replace invalid_email = 1 if email == "a00840798@tec.mx"	
		replace invalid_email = 1 if email == "a01620933@tec.mx"
		replace invalid_email = 1 if email == "a01731473@tec.mx"
		replace invalid_email = 1 if email == "a00830126@tec.mx"
		replace invalid_email = 1 if email == "a01660134@tec.mx"	
		
		* fix Alisher's non-delivery emails 
		replace invalid_email = 1 if email == "a01235932@tec.mx"
		replace invalid_email = 1 if email == "a00843193@tex.mx"
		replace invalid_email = 1 if email == "a01781085@tec.mx"
		replace invalid_email = 1 if email == "a00739721@tec.mx"
		replace invalid_email = 1 if email == "a0082169@tec.mx"
		
		replace invalid_email = 1 if email == "a00830691@tec.mx"
		replace invalid_email = 1 if email == "a0842135@tec.mx"
		replace invalid_email = 1 if email == "a00835880@tec.mx"
		replace invalid_email = 1 if email == "a01247267@tec.mx"
		
		
	* clean up varnames 
	rename hastomadoclas~2  	took_classes_2025
	
	rename respondesobre~n 		used_mh_on_campus
	rename f 					used_mh_off_campus
	
	rename g 					recommend_mh_on_campus
	rename h 					recommend_mh_off_campus
	
	rename i 					discuss_own_mh_probl
	rename j 					discuss_therapy_on_campus
	
	rename respondesobre~p 		would_use_on_campus
	rename l 					would_use_off_campus

	
	* convert to binary vars 
	foreach var in took_classes_2025 ///
             used_mh_on_campus 			used_mh_off_campus ///
             recommend_mh_on_campus   	recommend_mh_off_campus ///
             discuss_own_mh_probl 	 	discuss_therapy_on_campus ///
             would_use_on_campus   		would_use_off_campus {

		replace `var' = "1" if `var' == "Sí"
		replace `var' = "0" if `var' == "No"
		destring `var', replace force		
		
		* end of varlist 
		}			
		
	* get cleaner treated vars 
	
	gen treatment = real(substr(treatm_group, 2, 1))
	
	gen treat_any = (treatment >= 1)
	
		replace treat_any = . if treatment == .
	
		
	* check attrition 	
	tab treatment  _merge , row
	tab treat_any  _merge , row

	* get a response confirmation indicator 
	gen responded = (_merge == 3)
	
		* explore attrition 
		bysort treat_any: sum responded
		bysort treatment: sum responded
	
		* get the sample size
		sum treat_any  if responded == 1 & took_classes_2025 == 1 
			global sample = r(N)
			di "$sample"
	
	
	* test attrition
	gen attrite = (_merge == 1)
	
		tab attrite  _merge
	
		* prep for saving 
		isid email 
		
		order  uniqueid treatment  treat_any  email  responded  invalid_email  sender_name 
		
		
		save "${processed}/followup_2025_05/email_list_post${date_stamp}.dta" , replace 
		
		
		* export excel with emails based on merge 
		export excel uniqueid treatment  treat_any  email  responded  invalid_email  sender_name  ///
						using  "${processed}/followup_2025_05/email_list_post${date_stamp}.xlsx", firstrow(variables) replace
		
		
		
		gen 		timestamp_num = timestamp
			format 	timestamp_num  %15.0g

	exit 	
		
	* explore attrition 
	
	* test if attrition is different by treatment group 
		reg attrite treat_any , r 
		
		reg attrite i.treatment   , r 
// 		exit

		

	
	* explore results 

		* get the sample size
		sum treat_any  if responded == 1 & took_classes_2025 == 1 
			global sample = r(N)
			di "$sample"
	
	
	eststo clear 
	
	local i = 1
		
	* convert to binary vars 
	foreach var in  ///
             used_mh_on_campus 			used_mh_off_campus 			///
             recommend_mh_on_campus   	recommend_mh_off_campus 	///
             would_use_on_campus   		would_use_off_campus 		///
			 discuss_own_mh_probl 		discuss_therapy_on_campus   {
	
		
		* test if attrition is different by treatment group 
// 		eststo   y_`var' : reg  `var'  i.treat_any  /*  i.took_classes_2025  */ , r 
		eststo  y_`var'  : reg  `var'  i.treat_any  if  took_classes_2025 == 1 , r 
// 		eststo  y_`var'  : reg  `var'  i.treatment  if  took_classes_2025 == 1 , r 
		
		local i = `i' + 1
		
		* end of varlist 
		}

		coefplot y_*use*off*  y_*use*on*    y_*recomm*  y_*discuss*    ,     ci(90)   keep(*treat*)  ///
						xline(0, lcolor(purple%50))  note("N = ${sample}. 90% CIs shown.")   ///
						
			graph export  "${figures}/survey_followup/coefplot_new_outcomes${date_stamp}.png",  replace
			
			
		bysort treatm_group: sum used*  would*
		
		bysort treatm_group: sum  recommend*
		
		
		global main_followup_y "used_mh_on_campus  used_mh_off_campus   recommend_mh_on_campus  recommend_mh_off_campus  would_use_on_campus   would_use_off_campus   discuss_own_mh_probl 	  discuss_therapy_on_campus " 
	
		
			sum ${main_followup_y} if treat_any == 0
		
			tabstat  ${main_followup_y} if treat_any == 0  , col(stats)  varwidth(30)  format(%10.3f)
		
		
// 	local i = 1
//		
// 	* convert to binary vars 
// 	foreach var in  ///
//              used_mh_on_campus 			used_mh_off_campus ///
//              recommended_mh_on_campus   recommended_mh_off_campus ///
//              shared_own_mh 				shared_exp_mh_on_campus ///
//              would_use_on_campus   		would_use_off_campus {
//			 
// 		* test if attrition is different by treatment group 
// 		eststo  treatm`i' : reg  `var'  i.treatment   if  took_classes_2025   , r 
//		
// 		local i = `i' + 1
//		
// 		* end of varlist 
// 		}
//
// 		coefplot treatm? , keep(*treat*)  xline(0, lcolor(purple%50))
		
		
		
		
// 		eststo  y_`var'  : reg  `var'  i.treat_any  if  took_classes_2025 == 1 & timestamp <= 2060977438720, r  
//		eststo  y_`var'  : reg  `var'  i.treat_any  if  took_classes_2025 == 1 & timestamp <= 2060891848704, r  
			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		