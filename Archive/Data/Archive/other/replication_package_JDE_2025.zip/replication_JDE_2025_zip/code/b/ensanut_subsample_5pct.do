
** Stratified ENSANUT 5% sample *
/* The following resulting database is the ENSANUT data on adults and adolescents is the stratified subsample at 5% (drawn with sample 5, by(estrato) and seed 20231202). For exact replication of the paper, download the full ENSANUT microdata from: [https://www.inegi.org.mx/programas/ensanut/2018/#microdatos]."
 */

/* Read in dataset for respondents 20 years o older */
use "${raw}/ENSANUT/adultos_ensanut2023_w_n.dta", clear
generate adult = 1
append using "${raw}/ENSANUT/adolescentes_ensanut2023_w_n.dta"
replace adult = 0 if missing(adult)/* Read in dataset for respondents 20 years o older */

* 2. Take a 5% *person-level* subsample, stratified by survey strata
set seed 20231202          // choose & report this seed
sample 5, by(estrato)      // 5% within each stratum

* 3. Save replication file
save "${raw}/ENSANUT/ensanut2023_rep_5pct.dta", replace
