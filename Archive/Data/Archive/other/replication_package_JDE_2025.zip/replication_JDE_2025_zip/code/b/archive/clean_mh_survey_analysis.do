
* this file does the first round of cleaning of raw Qualtrics output data 


* import the raw data file 
import excel "${raw}/MH_survey_experiment_qualtrics_2024_11_23_ALL.xlsx", sheet("Sheet0") firstrow case(lower)  clear 


	/******************************************/
	/*    Clean variable names and labels     */
	/******************************************/

	* drop invariate vars 
	drop introandconsent  status distributionchannel  recipientlastname recipientfirstname recipientemail externalreference

	compress 

	* fix unique ID var 
	format uniqueid %22s
	
	* get rid of the case issue 
	replace uniqueid = lower(uniqueid)
	
		* get attention IDs 
	gen attention_passed_gym = (attention_gym == "Gym")

	gen attention_passed_id  = (uniqueid != "ma09he12" )

	gen attention_passed_both = ( attention_passed_gym == 1  &  attention_passed_id == 1)

	
// 	tab t2_info_c if attention_passed_both == 1
	
	
	global likert_qs "therapy_good_likert_1 therapy_good_likert_2 therapy_good_likert_3 therapy_good_likert_4  t1_likert_sofia_1 t1_likert_sofia_2 t1_likert_jose_1 t1_likert_jose_2 campus_support_1 campus_support_2 campus_support_3  self_stigma"

	* replace the longer part of the question to have more info in the label later (label is cutoff at some characters)
	foreach var of global likert_qs  {
		replace `var' = subinstr(`var', "How much do you agree with the following statement?", "(Dis)Agree? ", .) 
		replace `var' = subinstr(`var', "How much do you agree or disagree with the following statements? - ", "(Dis)Agree? ", .) 
		replace `var' = subinstr(`var', "How much do you agree with the following statements? - ", "(Dis)Agree? ", .) 
		replace `var' = subinstr(`var', "Do you agree or disagree with the following statements?  - ", "(Dis)Agree? ", .) 
		replace `var' = subinstr(`var', "Do you agree or disagree with the following statements? - ", "(Dis)Agree? ", .) 
		replace `var' = subinstr(`var', "There is a good support", "Good support", .) 
		replace `var' = subinstr(`var', "student", "stt", .) 
		replace `var' = subinstr(`var', "with", "w", .) 
		replace `var' = subinstr(`var', "professional help", "prof help", .) 
		list `var' in 1
	}

	* do the same for PHD/GAD questions 
	foreach var of varlist phq4_gad4_?  {
		replace `var' = subinstr(`var', "Over the last two weeks, how often have you been bothered by any of the following problems? - ", "How often in 2wks bothered by: ", .) 
		}

	foreach var of varlist therapy_misc_binary_?  {
		replace `var' = subinstr(`var', "Answer the following questions: - ", "Y/N: ", .) 
		replace `var' = subinstr(`var', "Do you have", "Have", .) 
		replace `var' = subinstr(`var', "Would you be open", "Open", .) 
		replace `var' = subinstr(`var', "you think ", "", .) 
		replace `var' = subinstr(`var', "mental health", "MH", .) 
		}

	* FIX SERVICE QUESTIONS 

	foreach var of varlist services_available_?  {
		* replace the long part of the service question
		replace `var' = subinstr(`var', "Which of the following services are available for students at your university campus? - ", "Service available on campus? ", .)	
		}
		

	foreach var of varlist control_c_?  {
		* replace the long part of the service question
		replace `var' = subinstr(`var', "What are some of the resources you feel are particularly good and those could be better for students at your university? - ", "Resource good or could be better at your uni? ", .)	
		}
		

	foreach var of varlist  rank_?  rank_??  {
		* replace the long part of the service question
		replace `var' = subinstr(`var', "Rank the following individuals in terms of how comfortable you would feel working closely with them on a joint course project:", "Rank a student who (1 most, 6 least comfortable) ", .)	
		replace `var' = subinstr(`var', "1 = Most comfortable to work with", "", .)	
		replace `var' = subinstr(`var', "6 = Least comfortable to work with", "", .)	
		replace `var' = subinstr(`var', "You can drag and drop the options below.", "", .)	 
		replace `var' = subinstr(`var', " - ", "", .)
		replace `var' = subinstr(`var', "A student who", "", .)
		list `var' in 1
		}

	* clean up guess-related questions  // remove the guess-related prompts from the label 
	foreach var of varlist  therapy_use_others_1 open_to_share_guess_1 perceived_stigma_1 perceived_stigma_2 perceived_stigma_3 guess_self_stigma_1  {
		* replace the long part of the service question
		replace `var' = subinstr(`var', "Out of every 100 students at your university (Tec), how many do you think", "Guess # of 100 students in your univ who", .)	
		replace `var' = subinstr(`var', "Out of every 100 students in this university, how many would be ", "Guess # of 100 students in your univ", .)	
		replace `var' = subinstr(`var', "What do you think is the percentage of students, professors, and parents of students do you believe ", "Guess % of X ", .)	
		replace `var' = subinstr(`var', "would view a student negatively for experiencing mental health issues like anxiety or depression? - ", "view negatively a student w anxiety/depression? X = ", .)	
		replace `var' = subinstr(`var', "Please guess how many participants of this study, out of every 100 students, responded to the question above with", "Guess # of 100 participants", .)	
		replace `var' = subinstr(`var', "? In other words, out of every 100 students, ", "", .)	
		replace `var' = subinstr(`var', "how many responded", "", .)	
		replace `var' = subinstr(`var', "Strongly agree", "", .)	
		replace `var' = subinstr(`var', "Strongly Agree", "", .)	
		replace `var' = subinstr(`var', "Somewhat agree", "", .)	
		replace `var' = subinstr(`var', "Somewhat Agree", "", .)	
		replace `var' = subinstr(`var', "Agree", "", .)	
		replace `var' = subinstr(`var', "Strongly ", "", .)	
		replace `var' = subinstr(`var', "Somewhat ", "", .)	
		replace `var' = subinstr(`var', "do you think ", "", .)	
		replace `var' = subinstr(`var', "do you believe ", "", .)
		replace `var' = subinstr(`var', "that they would ", "who would ", .)
		replace `var' = subinstr(`var', "If your guess is within 5 students of the correct answeryou will earn a bonus of 50 MXN.", "", .)
		replace `var' = subinstr(`var', "If your guess is within 5 students of the correct answer, you will earn a bonus of 50 MXN.", "", .)
		replace `var' = subinstr(`var', "(The correct estimate will be calculated based on the answers of the survey respondents. One of the bonus questions will be randomly chosen for payment.)", "", .)
		replace `var' = subinstr(`var', "(The correct answer will be calculated based on responses from this survey. One of the bonus questions will be randomly chosen for payment.)", "", .)	
		replace `var' = subinstr(`var', " - Number of students out of 100", "", .)
		replace `var' = subinstr(`var', " - Guess the number of students", "", .)
		replace `var' = subinstr(`var', "Out of every 100 students in this university, how many would be" , "Guess # of 100 students in your univ", .)	
		list `var' in 1
		}

	* clean up guess-related questions (symbols)
	foreach var of varlist  therapy_use_others_1 open_to_share_guess_1 perceived_stigma_1 perceived_stigma_2 perceived_stigma_3 guess_self_stigma_1  {
		* replace the long part of the service question
		replace `var' = subinstr(`var', " / ", "", .)
		replace `var' = subinstr(`var', ", ", "", .)
		replace `var' = subinstr(`var', " or ", "", .)
		replace `var' = subinstr(`var', "`""""'", "", .)
		list `var' in 1
		}	

	* set second row as varlabels 
		* label each var with its value in row 1
		foreach x of varlist * {
		   label var `x' `"`=`x'[1]'"' 
			}
		* drop row 1 of var labels 
		drop in 1
		
		* destring vars that are otherwise numeric (except for previous row 1 with labels)
		foreach x of varlist * {
		   cap destring `x', replace
			}

	compress 
		
		
	* fix the Likert answers into categorical in correct order 

	label define  Lbl_Likert  	1 "Strongly agree" 		2 "Agree" 		3 "Somewhat agree" ///
								4 "Somewhat disagree"  	5 "Disagree" 	6 "Strongly disagree"  ///
								, replace 

		numlabel Lbl_Likert , add   mask("(#) ")
								
	foreach var of global likert_qs {
		* convert all to lower case first 
		replace `var'  =  strlower(`var')
		
	// 	* check the values of each var 
	// 	tab `var' 
		
		* replace all values 
		replace `var'  =  "1"   if  `var'  == "strongly agree" 		
		replace `var'  =  "2"   if  `var'  == "agree" 		
		replace `var'  =  "3"   if  `var'  == "somewhat agree" 
		replace `var'  =  "4"   if  `var'  == "somewhat disagree"  	
		replace `var'  =  "5"   if  `var'  == "disagree" 	
		replace `var'  =  "6"   if  `var'  == "strongly disagree"
		
		destring `var' , replace 
		label values `var'  Lbl_Likert
		tab `var'
	} 


	
	/*************************************/
	/*      Generate new variables  	 */
	/*************************************/

	* get new vars 
	drop if uniqueid == ""
	
	* clean the dates : convert the string of the date part into date 
	gen date =  date(substr(startdate, 1, 11),"MDY", 2050)

		format date %td
		
		gen day = day(date)
		
		* drop our test responses before the survey was launched 
		drop if day < 14
				
			
	* get new vars 
		
	rename transfer_oth_therapy_1  donation_pct 

	rename wtp_1   		   wtp_therapy_self 
	rename wtp_friend_1    wtp_therapy_friend 

	* define label for treatment groups 
	label define Lbl_treat_group  	1 "T1: Info + Reflection"  ///
									2 "T2: Info only"  ///
									0 "Control"  , replace 
	
		numlabel  Lbl_treat_group , add mask("(#) ")
		
	gen treatm_group = .
		replace treatm_group = 1 if t1_info_a != ""
		replace treatm_group = 2 if t2_info_a != ""
		replace treatm_group = 0 if control_c_1 != ""
		
		label values treatm_group  Lbl_treat_group 
		
		label var treatm_group  "Treatment group"

		
	* gen dummies by control / treatment type 
	gen control  	     = (treatm_group == 0) 
	gen treat_info_refl  = (treatm_group == 2) 
	gen treat_info 	     = (treatm_group == 1) 	
	
		replace control 		= . if treatm_group == .
		replace treat_info_refl	= . if treatm_group == .
		replace treat_info 		= . if treatm_group == .
		
	* get gender vars 	
	gen female = (gender == "Female")
	gen   male = (gender == "Male")

	* get a numeric categorical major 
	encode major, gen(major_id )

		* recode an "other" category to combine others 
		replace major_id = 9 if major_id == 1  // architecture + design 
		replace major_id = 9 if major_id == 3  // creative arts / humanities 
		replace major_id = 9 if major_id == 7  // other 

	* get a numeric var for year in college 
	gen year_uni = real(substr(degree_year, 1, 1))

	rename studies_22_guess_1     guess_22_studies
	rename open_to_share_guess_1  guess_open_to_share 
	rename wait_time_guess  	  guess_wait_time
	rename therapy_use_others_1   guess_therapy_use 
	
	rename guess_self_stigma_1    guess_self_stigma
	
	rename perceived_stigma_1   perceived_stigma_students
	rename perceived_stigma_2   perceived_stigma_profs
	rename perceived_stigma_3   perceived_stigma_stt_parents
	
	* Define the label for the categories
	label define Lbl_services 	1 "Have NOT heard about this service existing on campus" ///
								2 "Heard service exists on campus" ///
								3 "Heard service exists on campus + Friend/I used it"  , replace 

		numlabel Lbl_services , add   mask("(#) ")	
		
	foreach var of varlist services_available_?  {
		* take the number from parantheses
		replace `var'  =  substr(`var', 2, 1)
		
		destring `var' , replace 
		
		label values `var'  Lbl_services
		
// 		tab `var'
	} 
		
	replace  prior_3_mh_gpa_corr  =  subinstr(prior_3_mh_gpa_corr , "correlation", "corr", .)

		
	gen prior_3_mh_gpa_num  =  . 

		replace  prior_3_mh_gpa_num  =  1  if  prior_3_mh_gpa_corr == "Much better      (corr > 0.5)"   
		replace  prior_3_mh_gpa_num  =  2  if  prior_3_mh_gpa_corr == "Better             (0.3 < corr < 0.5)"  
		replace  prior_3_mh_gpa_num  =  3  if  prior_3_mh_gpa_corr == "No better or worse (-0.3 < corr < 0.3)" 
		replace  prior_3_mh_gpa_num  =  4  if  prior_3_mh_gpa_corr == "Worse (-0.5 < corr < -0.3)"   
		replace  prior_3_mh_gpa_num  =  5  if  prior_3_mh_gpa_corr == "Much worse (corr < -0.5)" 
		
		
		label define  Lbl_prior_mh_gpa   ///
					 1  "Much better (corr > 0.5)"  		2 "Better (0.3, 0.5)"  ///
					 3  "No better or worse (-0.3, 0.3)"   		///
					 4  "Worse (-0.5, -0.3)"   				5  "Much worse (corr < -0.5)"   	///
						,  replace 
		
		label values  prior_3_mh_gpa_num   Lbl_prior_mh_gpa 
		
	* get the extra vars 
	/* Generate MH distree score (0-24) */
	* get binary vars representing a score for each component
	foreach var in phq4_gad4_1 phq4_gad4_2 phq4_gad4_3 phq4_gad4_4 phq4_gad4_5 phq4_gad4_6 phq4_gad4_7 phq4_gad4_8 {
		generate `var'_num = ///
			cond(`var' == "Not at all",  			  0, ///
			cond(`var' == "Several Days", 			  1, ///
			cond(`var' == "More than half the days",  2, ///
			cond(`var' == "Nearly Every Day", 		  3, .))))
	}
	
	* get the total MH score as a sum of all components 
	egen mh_score = rowtotal(phq4_gad4_1_num-phq4_gad4_8_num)
	
		
	* clean up other varnames 
	
	rename therapy_misc_binary_1  prof_help_now 
	rename therapy_misc_binary_2  prof_help_ever 
	rename therapy_misc_binary_3  prof_help_friend_ever
	rename therapy_misc_binary_4  prof_help_friend_benefit
	rename therapy_misc_binary_5  open_to_share
	
	rename therapy_good_likert_1  therapy_good_self 
	rename therapy_good_likert_2  therapy_good_general
	rename therapy_good_likert_3  therapy_support_by_friends
	rename therapy_good_likert_4  therapy_support_by_parents
	
	
	rename services_available_1  available_health_cent
	rename services_available_2  available_psyc_counsl
	rename services_available_3  available_gym
	rename services_available_4  available_hotline
	rename services_available_5  available_acad_counsl
	rename services_available_6  available_career
	rename services_available_7  available_free_res
	rename services_available_8  available_meditat_space
	
	rename campus_support_1  campus_support_physical_act
	rename campus_support_2  campus_support_prof_help_emot
	rename campus_support_3  campus_support_finance_stress
	
	rename durationinseconds durations_sec
	
	rename locationlatitude   lat 
	rename locationlongitude  lon 
		
	
	* extra var cleaning 
	
	label var donation_pct "Donation % for therapy for a student w financ need" 
	
	rename  services_amount_12m  support_amount
	
		label var support_amount "Desired amount of prior mh support (past 12 month)" 
	
	replace support_amount =  "(1) As much support as needed (27%)"  ///
				if support_amount == "I received  as much support  (counseling, therapy, or medication) for my mental or emotional health as I wanted"
	replace support_amount =  "(2) Less support than desired (20%)"  ///
				if support_amount == "I received  less support  (counseling, therapy, or medication) for my mental or emotional health than I would have wanted"
	replace support_amount =  "(3) Was not seeking support (53%)"  ///
				if support_amount == "I was  not seeking support  (counseling, therapy, or medication) for my mental or emotional health"

	
	* get the joint treatment var 
	gen treat_any = (treatm_group == 1 | treatm_group == 2 )
	
		* define label for treatment groups 
		label define Lbl_treat_any  	1 "Any treatment (T1+T2)"  ///
										0 "Control"  , replace 
		
		numlabel  Lbl_treat_any , add mask("(#) ")
		
		label values treat_any  Lbl_treat_any 
		
		label var treat_any  "Treatment (any)"

		
	
	* recode ranks to outcomes comparing MH symptoms / talking to low academic performance
	gen prefer_mh_sympt_over_low_gpa 	= (rank_3 < rank_10)
	gen prefer_mh_talk_over_low_gpa		= (rank_9 < rank_10)
		
	* recode ranks to outcomes comparing MH symptoms / talking to low academic performance
	gen prefer_low_gpa_over_mh_sympt 	= (rank_3 > rank_10)
	gen prefer_low_gpa_over_mh_talk 	= (rank_9 > rank_10)
		
		label var prefer_low_gpa_over_mh_sympt 	"Rank low-gpa over MH distress symptoms"
		label var prefer_low_gpa_over_mh_talk 	"Rank low-gpa over talking about MH"
	
	* get a mental distress dummy 
	gen mh_distress = (mh_score >= 12)
	
		label var mh_distress "Mental distress (dummy) (if mh score >= 12)"
	 
	
		
	/* Subset to the final sample */
	
	* drop the incomplete responses 
	drop if progress != 100	
	
	* drop those who provided did not create a unique ID 
	drop if uniqueid == "ma09he12"
	
	* get a numeric student id 
	encode responseid , gen(student_id)
		
		drop  responseid
		
	isid student_id
	
	sort student_id
		
	compress 	
	
	label data "MH survey data by student 2024-11"
		
	save "${clean}/mh_survey_analysis.dta" , replace 
	






/*


	




