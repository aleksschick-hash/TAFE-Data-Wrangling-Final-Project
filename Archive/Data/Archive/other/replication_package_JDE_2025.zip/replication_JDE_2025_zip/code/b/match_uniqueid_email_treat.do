import excel "${raw}/Lista-de-correos-2024-11-ESP_respuestas.xlsx", firstrow case(lower)  clear 

drop timestamp correocorrecto
rename idúnico uniqueid

* fix unique ID var 
format uniqueid %22s
rename correoinstitucionaldetec email
	
* get rid of the case issue or extra space issue
replace uniqueid = lower(uniqueid)
replace uniqueid = trim(uniqueid)
replace email  = lower(email)

* replacing "0" with "o" for 1,2,5,6th characters of uniqueid
replace uniqueid = ///
    cond(substr(uniqueid, 1, 1) == "0", "o", substr(uniqueid, 1, 1)) + ///
    cond(substr(uniqueid, 2, 1) == "0", "o", substr(uniqueid, 2, 1)) + ///
    substr(uniqueid, 3, 2) + ///
    cond(substr(uniqueid, 5, 1) == "0", "o", substr(uniqueid, 5, 1)) + ///
	cond(substr(uniqueid, 6, 1) == "0", "o", substr(uniqueid, 6, 1)) + ///
    substr(uniqueid, 7, 2)

* replacing "o" with "0" for 3,4,7,8th characters of uniqueid
replace uniqueid = ///
	substr(uniqueid, 1, 2) + ///
    cond(substr(uniqueid, 3, 1) == "o", "0", substr(uniqueid, 3, 1)) + ///
    cond(substr(uniqueid, 4, 1) == "o", "0", substr(uniqueid, 4, 1)) + ///
    substr(uniqueid, 5, 2) + ///
    cond(substr(uniqueid, 7, 1) == "o", "0", substr(uniqueid, 7, 1)) + ///
	cond(substr(uniqueid, 8, 1) == "o", "0", substr(uniqueid, 8, 1))

* drop "ma09he12"
keep if uniqueid != "ma09he12"
duplicates drop 
duplicates tag uniqueid, gen(dup_id)
tab dup_id
isid uniqueid
gen id_using = _n

* save the file
* "${processed}/mh_survey_uniqueid_email.xlsx"

save "${tmp}/mh_survey_uniqueid_email.dta", replace


* Load the data and generate new vars
use "${clean}/mh_survey_analysis.dta" , replace

	keep uniqueid treatm_group
	replace uniqueid = trim(uniqueid)
	gen id_master = _n

	merge 1:1 uniqueid using "${tmp}/mh_survey_uniqueid_email.dta"

	keep if _merge == 1
	drop _merge

	save "${tmp}/mh_survey_temp.dta", replace

	
	
use "${tmp}/mh_survey_temp.dta", replace

	// reclink id_first6 id_last6 using "${tmp}/mh_survey_uniqueid_email.dta", idm(uniqueid_master) idu(uniqueid_using) gen(match_score)

	* Executing fuzzy merge 
	matchit id_master uniqueid using "${tmp}/mh_survey_uniqueid_email.dta", idusing(id_using) txtusing(uniqueid) 

	gsort -similscore
	// export excel using "${processed}/mh_survey_merged_uniqueid_email_treat.xlsx", firstrow(variables) replace

	keep if similscore > 0.7
	drop if uniqueid == "pe01se29" & uniqueid1 == "be01se27"
	isid uniqueid
	rename uniqueid1 matched_uniqueid
	keep uniqueid matched_uniqueid

	save "${tmp}/mh_survey_fuzzy_matches.dta", replace


* Load the data and generate new vars
use "${clean}/mh_survey_analysis.dta" , replace

	keep uniqueid treatm_group
	replace uniqueid = trim(uniqueid)

	merge 1:1 uniqueid using "${tmp}/mh_survey_uniqueid_email.dta", nogen keep(master match)


	merge 1:1 uniqueid using "${tmp}/mh_survey_fuzzy_matches.dta", nogen keep(master match)
	rename uniqueid uniqueid_orig
	rename matched_uniqueid uniqueid
	compress
	rename email email_orig

	merge m:1 uniqueid using "${tmp}/mh_survey_uniqueid_email.dta", nogen keep(master match) keepusing(email)

	replace email_orig = email if email_orig == ""
	drop email
	rename email_orig email

	drop uniqueid
	rename uniqueid_orig uniqueid

	drop dup_id id_using

	sort treatm_group uniqueid 
	compress
	isid uniqueid

	save "${processed}/mh_survey_uniqueid_email_treat.dta", replace
