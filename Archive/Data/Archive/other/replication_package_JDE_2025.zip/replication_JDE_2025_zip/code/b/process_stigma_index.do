
* Process stigma-related measures w PCA 


global outcomes_scaled2 "wtp_therapy_pct_self  wtp_therapy_pct_friend donation_pct "
 
global vars "perceived_stigma_students  perceived_stigma_profs perceived_stigma_stt_parents  guess_self_stigma  prefer_low_gpa_over_mh_talk  prefer_low_gpa_over_mh_sympt  "

global ncomp 2


	
	use "${processed}/mh_survey_analysis_draft.dta" , replace 

		* keep relevant vars 
		keep uniqueid treat*  wtp_therapy_*  donation_pct    $vars

		* standardize vars for PCA inputs 
		foreach var of global vars {
			egen `var'_std = std(`var')
			}

		* get a list of standardized results 
		global vars_std *_std

		
		* run PCA on standardized vars 
		pca $vars_std

		// * plot the PCA component power drop off and identify count above 1 (visually)
		// screeplot, yline(1)

		* run variations of PCA 
		pca $vars_std, mineigen(1)
		pca $vars_std, comp($ncomp)
		pca $vars_std, comp($ncomp) blanks(.3)

		* generate the predicted measures corr w stigma inputs from the PCA (2 main components)
		predict stigma_index1  stigma_index2

		* clean the dataset for saving 
		compress
		isid uniqueid 
		
		keep uniqueid stigma_index* 
		
		
		save  "${processed}/stigma_index_by_student.dta" , replace 

		
		exit
		
		
		* checking the results 
			
				
	*********************************************************************************
	*  Summary Statistics for Stigma Index by Treatment Group
	***************************************************************************

	/*
	
	sum stigma_index, d
	egen index2 = std(stigma_index)
	sum index2, d
	gen d_stigma_above_p50 = index2 > r(mean)
	gen d_stigma_above_p75 = index2 > r(p75)

	* Heterogeneity by self-stigma
		eststo clear
		local i = 1
			
		foreach var of global outcomes_scaled2 {
		
			eststo reg_ss`i' , title("test`i'"):  ///
				reg `var'  i.treat_any##c.index2 , r
			local i = `i' + 1
			
			}

					
			coefplot reg_ss? , xline(0, lcolor(purple%50))  drop(_cons)  ///
								legend(order(2 "WTP for therapy (self) (%)"  4 "WTP for therapy for a friend (%)"  ///
											 6 "Donation for therapy (%)") ///
									   size(small))  ///
								title("Main effects (joint treatment, N = 680)", size(medsmall)) ///
								xlabel( -0.1 "-10%" -0.05 "-5%" 0 "0%" 0.05 "5%" 0.1 "10%" ) ///
								levels(90)   note("90% CIs") /// 
								subtitle("(Effects by Treatment Group)", size(small))  
								
			graph export "$figures/coefplot_by_stigma.png" , replace 				

								
