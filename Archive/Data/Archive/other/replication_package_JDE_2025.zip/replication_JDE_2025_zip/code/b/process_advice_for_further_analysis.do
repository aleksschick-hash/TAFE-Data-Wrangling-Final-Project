
	
	/* ************************************************************************** */

	/* The open-ended advice text box was processed and categorized by ChatGPT o4 
		and then cross-validated and (re-)classified by our research assistants 
	
	
		This file imports the results of that advice classification where the rows 
			with advice are identical to the advice in the raw survey data 
			(exported as columns directly from the raw survey) 
																				  */
	
	/* ************************************************************************** */

	
	* import the output from ChatGPT with word and character counts 
	import excel "${raw}/advice_with_word_counts.xlsx", sheet("Sheet1") firstrow case(lower)  clear
	
		drop if uniqueid == ""
		
		* clean the uniqueID case 
		replace uniqueid = lower(uniqueid)
		drop if uniqueid == "ma09he12"
	
		duplicates tag uniqueid, gen(dup_id)
	
		rename char_count  	advice_char_count 
		rename word_count   advice_word_count
		
		isid uniqueid
	
		save "${tmp}/advice_with_word_count.dta", replace 
	
	
	* import the output from ChatGPT with word and character counts 
	import excel "${raw}/advice_eng_w_flags.xlsx", sheet("Sheet1") firstrow case(lower) clear
	
		rename uniqueness  uniqueid
	
		drop if uniqueid == ""
		* clean the uniqueID case 
		replace uniqueid = lower(uniqueid)
		drop if uniqueid == "ma09he12"
	
		duplicates tag uniqueid, gen(dup_id)
	
		rename mentions_professional_help 	advice_mention_prof_help
		
		isid uniqueid
	
		merge 1:1 uniqueid using "${tmp}/advice_with_word_count.dta", nogen
	
		keep uniqueid advice_char_count advice_word_count advice_mention_prof_help 
	
		isid uniqueid
		
		save "${processed}/advice_with_flags_w_counts.dta", replace 
	
	
	
/* 

########################################################
#    Python code from ChatGPT // Pre-RA validation: 
########################################################
	
# Translated into English on translate.google.com 
	
# define inclusion terms for the detection function
def check_professional_help_complete(text):
    comprehensive_synonyms = [
        'therapy', 'therapist', 'professional help', 'professional support',
        'mental health professional', 'psychologist', 'psychologists', 
        'psychiatrist', 'medication', 'counseling', 'counselling',
        'help sessions', 'support sessions', 'a professional',
        'betterhelp', 'appropriate services', 'professional attention',
        'trained professionals', 'health professional', 'trained professional',
        'someone professional', 'qualified professional', 'qualified', 'counselor'
    ]
    text_lower = text.lower()
    return int(any(re.search(rf'\b{synonym}\b', text_lower) for synonym in comprehensive_synonyms))

# Apply the updated function to detect mentions of professional help comprehensively
english_data['mentions_professional_help'] = english_data['advice_outcome'].apply(check_professional_help_complete)

# Save the final updated data to a new file
output_file_path_complete = '/mnt/data/advice_english_with_complete_flags.xlsx'
english_data.to_excel(output_file_path_complete, index=False)

output_file_path_complete


