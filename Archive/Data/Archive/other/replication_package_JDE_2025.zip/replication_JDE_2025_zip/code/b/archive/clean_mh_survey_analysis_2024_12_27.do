
* this file does the first round of cleaning of raw Qualtrics output data 


* import the raw data file 
import excel "${raw}/MH_survey_experiment_qualtrics_2024_11_23_ALL.xlsx", sheet("Sheet0") firstrow case(lower)  clear 


	/******************************************/
	/*    Clean variable names and labels     */
	/******************************************/

	* drop invariate vars 
	drop introandconsent  status distributionchannel  recipientlastname recipientfirstname recipientemail externalreference

	compress 

	* fix unique ID var 
	format uniqueid %22s
	
	* get rid of the case issue 
	replace uniqueid = lower(uniqueid)
	
		* get attention IDs 
	gen attention_passed_gym = (attention_gym == "Gym")

	gen attention_passed_id  = (uniqueid != "ma09he12" )

	gen attention_passed_both = ( attention_passed_gym == 1  &  attention_passed_id == 1)

	
// 	tab t2_info_c if attention_passed_both == 1
	
	
	global likert_qs "therapy_good_likert_1 therapy_good_likert_2 therapy_good_likert_3 therapy_good_likert_4  t1_likert_sofia_1 t1_likert_sofia_2 t1_likert_jose_1 t1_likert_jose_2 campus_support_1 campus_support_2 campus_support_3  self_stigma"

	* replace the longer part of the question to have more info in the label later (label is cutoff at some characters)
	foreach var of global likert_qs  {
		replace `var' = subinstr(`var', "How much do you agree with the following statement?", "(Dis)Agree? ", .) 
		replace `var' = subinstr(`var', "How much do you agree or disagree with the following statements? - ", "(Dis)Agree? ", .) 
		replace `var' = subinstr(`var', "How much do you agree with the following statements? - ", "(Dis)Agree? ", .) 
		replace `var' = subinstr(`var', "Do you agree or disagree with the following statements?  - ", "(Dis)Agree? ", .) 
		replace `var' = subinstr(`var', "Do you agree or disagree with the following statements? - ", "(Dis)Agree? ", .) 
		replace `var' = subinstr(`var', "There is a good support", "Good support", .) 
		replace `var' = subinstr(`var', "student", "stt", .) 
		replace `var' = subinstr(`var', "with", "w", .) 
		replace `var' = subinstr(`var', "professional help", "prof help", .) 
		list `var' in 1
	}

	* do the same for PHD/GAD questions 
	foreach var of varlist phq4_gad4_?  {
		replace `var' = subinstr(`var', "Over the last two weeks, how often have you been bothered by any of the following problems? - ", "How often in 2wks bothered by: ", .) 
		}

	foreach var of varlist therapy_misc_binary_?  {
		replace `var' = subinstr(`var', "Answer the following questions: - ", "Y/N: ", .) 
		replace `var' = subinstr(`var', "Do you have", "Have", .) 
		replace `var' = subinstr(`var', "Would you be open", "Open", .) 
		replace `var' = subinstr(`var', "you think ", "", .) 
		replace `var' = subinstr(`var', "mental health", "MH", .) 
		}

	* FIX SERVICE QUESTIONS 

	foreach var of varlist services_available_?  {
		* replace the long part of the service question
		replace `var' = subinstr(`var', "Which of the following services are available for students at your university campus? - ", "Service available on campus? ", .)	
		}
		

	foreach var of varlist control_c_?  {
		* replace the long part of the service question
		replace `var' = subinstr(`var', "What are some of the resources you feel are particularly good and those could be better for students at your university? - ", "Resource good or could be better at your uni? ", .)	
		}
		

	foreach var of varlist  rank_?  rank_??  {
		* replace the long part of the service question
		replace `var' = subinstr(`var', "Rank the following individuals in terms of how comfortable you would feel working closely with them on a joint course project:", "Rank a student who (1 most, 6 least comfortable) ", .)	
		replace `var' = subinstr(`var', "1 = Most comfortable to work with", "", .)	
		replace `var' = subinstr(`var', "6 = Least comfortable to work with", "", .)	
		replace `var' = subinstr(`var', "You can drag and drop the options below.", "", .)	 
		replace `var' = subinstr(`var', " - ", "", .)
		replace `var' = subinstr(`var', "A student who", "", .)
		list `var' in 1
		}

	* clean up guess-related questions  // remove the guess-related prompts from the label 
	foreach var of varlist  therapy_use_others_1 open_to_share_guess_1 perceived_stigma_1 perceived_stigma_2 perceived_stigma_3 guess_self_stigma_1  {
		* replace the long part of the service question
		replace `var' = subinstr(`var', "Out of every 100 students at your university (Tec), how many do you think", "Guess # of 100 students in your univ who", .)	
		replace `var' = subinstr(`var', "Out of every 100 students in this university, how many would be ", "Guess # of 100 students in your univ", .)	
		replace `var' = subinstr(`var', "What do you think is the percentage of students, professors, and parents of students do you believe ", "Guess % of X ", .)	
		replace `var' = subinstr(`var', "would view a student negatively for experiencing mental health issues like anxiety or depression? - ", "view negatively a student w anxiety/depression? X = ", .)	
		replace `var' = subinstr(`var', "Please guess how many participants of this study, out of every 100 students, responded to the question above with", "Guess # of 100 participants", .)	
		replace `var' = subinstr(`var', "? In other words, out of every 100 students, ", "", .)	
		replace `var' = subinstr(`var', "how many responded", "", .)	
		replace `var' = subinstr(`var', "Strongly agree", "", .)	
		replace `var' = subinstr(`var', "Strongly Agree", "", .)	
		replace `var' = subinstr(`var', "Somewhat agree", "", .)	
		replace `var' = subinstr(`var', "Somewhat Agree", "", .)	
		replace `var' = subinstr(`var', "Agree", "", .)	
		replace `var' = subinstr(`var', "Strongly ", "", .)	
		replace `var' = subinstr(`var', "Somewhat ", "", .)	
		replace `var' = subinstr(`var', "do you think ", "", .)	
		replace `var' = subinstr(`var', "do you believe ", "", .)
		replace `var' = subinstr(`var', "that they would ", "who would ", .)
		replace `var' = subinstr(`var', "If your guess is within 5 students of the correct answeryou will earn a bonus of 50 MXN.", "", .)
		replace `var' = subinstr(`var', "If your guess is within 5 students of the correct answer, you will earn a bonus of 50 MXN.", "", .)
		replace `var' = subinstr(`var', "(The correct estimate will be calculated based on the answers of the survey respondents. One of the bonus questions will be randomly chosen for payment.)", "", .)
		replace `var' = subinstr(`var', "(The correct answer will be calculated based on responses from this survey. One of the bonus questions will be randomly chosen for payment.)", "", .)	
		replace `var' = subinstr(`var', " - Number of students out of 100", "", .)
		replace `var' = subinstr(`var', " - Guess the number of students", "", .)
		replace `var' = subinstr(`var', "Out of every 100 students in this university, how many would be" , "Guess # of 100 students in your univ", .)	
		list `var' in 1
		}

	* clean up guess-related questions (symbols)
	foreach var of varlist  therapy_use_others_1 open_to_share_guess_1 perceived_stigma_1 perceived_stigma_2 perceived_stigma_3 guess_self_stigma_1  {
		* replace the long part of the service question
		replace `var' = subinstr(`var', " / ", "", .)
		replace `var' = subinstr(`var', ", ", "", .)
		replace `var' = subinstr(`var', " or ", "", .)
		replace `var' = subinstr(`var', "`""""'", "", .)
		list `var' in 1
		}	

	* fix variable description for priors from long-form text 
	replace prior_1_effective   = "Guess #1: Therapy reduced mild+moderate depression 4-5 years later? Y/N" in 1
	replace prior_2_mild_moder  = "Guess #2: Most students w prof MH help have mild/no symptoms of depress/anxiety? Y/N" in 1
	replace prior_3_mh_gpa_corr = "Guess #3: Corr betw GPA & mental health state across students? Y/N" in 1    					
	
	
	replace t1_info_a  = "Post-guess 1: Therapy reduced mild+moderate depression 4-5 years later? Y/N" in 1
	replace t1_info_b  = "Post-guess 2: Most students w prof MH help have mild/no symptoms of depress/anxiety? Y/N" in 1
	replace t1_info_c  = "Post-guess 3: Corr betw GPA & mental health state across students? Y/N" in 1    					
	
	replace t2_info_a  = "Post-guess 1: Therapy reduced mild+moderate depression 4-5 years later? Y/N" in 1
	replace t2_info_b  = "Post-guess 2: Most students w prof MH help have mild/no symptoms of depress/anxiety? Y/N" in 1
	replace t2_info_c  = "Post-guess 3: Corr betw GPA & mental health state across students? Y/N" in 1    					
	
	
	* set second row as varlabels 
		* label each var with its value in row 1
		foreach x of varlist * {
		   label var `x' `"`=`x'[1]'"' 
			}
		* drop row 1 of var labels 
		drop in 1
		
		* destring vars that are otherwise numeric (except for previous row 1 with labels)
		foreach x of varlist * {
		   cap destring `x', replace
			}

	compress 
		
		
	* fix the Likert answers into categorical in correct order 

	label define  Lbl_Likert  	1 "Strongly agree" 		2 "Agree" 		3 "Somewhat agree" ///
								4 "Somewhat disagree"  	5 "Disagree" 	6 "Strongly disagree"  ///
								, replace 

		numlabel Lbl_Likert , add   mask("(#) ")
								
	foreach var of global likert_qs {
		* convert all to lower case first 
		replace `var'  =  strlower(`var')
		
	// 	* check the values of each var 
	// 	tab `var' 
		
		* replace all values 
		replace `var'  =  "1"   if  `var'  == "strongly agree" 		
		replace `var'  =  "2"   if  `var'  == "agree" 		
		replace `var'  =  "3"   if  `var'  == "somewhat agree" 
		replace `var'  =  "4"   if  `var'  == "somewhat disagree"  	
		replace `var'  =  "5"   if  `var'  == "disagree" 	
		replace `var'  =  "6"   if  `var'  == "strongly disagree"
		
		destring `var' , replace 
		label values `var'  Lbl_Likert
		tab `var'
	} 
	
	* create a Yes/No label applicable for multiple	questions 
	label define Lbl_Yes_No   1 "Yes" 0 "No" , replace 
		numlabel Lbl_Yes_No, add mask("(#) ")
		
	
	* fix the priors and posterior updates 
	foreach var of varlist  prior_1_* prior_2_*  t?_info_a  t?_info_b  {
		
		replace `var'  =  substr(`var' ,  1, 3)
		replace `var'  =  subinstr(`var' , "No,", "No", .)
				
		}
				
	* recode yes/no vars 
	foreach var of varlist  finished  therapy_use_12m  therapy_misc_binary*  t1_easy_for_*  heard_of_betterhelp   prior_1_effective  prior_2_mild_moder  t?_info_a  t?_info_b    {
		
		* replace yes & no with numbers
		replace `var' = "1" if `var' == "Yes" |  `var' == "True" 
		replace `var' = "0" if `var' == "No"  |  `var' == "False"
		
		* destring the variable 
		destring `var' , replace 
		
		* label values with Yes/No label 
		label values `var'   Lbl_Yes_No
		}	
	
	* create a Yes/No label applicable for multiple	questions 
	label define Lbl_Good_Better   	0   "Don't know / have never used it"   ///
									1  	"Good as is" ///
									2  	"Wish it were better" , replace 
									
		numlabel Lbl_Good_Better, add mask("(#) ")
	
	* replace perceived service quality 
	foreach var of varlist  control_c_?  {
		
		* replace yes & no with numbers
		replace  `var' = "0" if ustrregexm(`var' , "have never used it") == 1
		replace  `var' = "1" if `var' == "Good as is" 
		replace  `var' = "2" if `var' == "Wish it were better" 
		
		* destring the variable 
		destring  `var' , replace 
		
		* label values with Yes/No label 
		label values  `var'   Lbl_Good_Better
		
		}	
	
		* Define value labels for the ordered categories
		label define Lbl_educ_level		1 "Didn't complete elementary school" ///
										2 "Completed elementary school" ///
										3 "Completed secondary school" ///
										4 "Some university studies (incompl)" ///
										5 "Completed undergraduate degree" ///
										6 "Completed grad degree (Master's+)"  ///
										,  replace 
			
			numlabel Lbl_educ_level, add mask("(#) ")
								
		* convert parental educ to ordered categorical var 
		foreach var of varlist parent_educ_*  {

			* Use regex matching to categorize based on partial matches
			replace `var' = "6"  if  ustrregexm(`var', "Completed a graduate")
			replace `var' = "5"  if  ustrregexm(`var', "Completed an undergraduate")
			replace `var' = "4"  if  ustrregexm(`var', "Some university studies")
			replace `var' = "3"  if  ustrregexm(`var', "Completed secondary school")
			replace `var' = "2"  if  ustrregexm(`var', "Completed elementary school")
			replace `var' = "1"  if  ustrregexm(`var', "t complete elementary")

			* destring into numeric 
			destring `var' , replace
			
			* Assign value labels to the new variable
			label values `var' Lbl_educ_level

			}
		
// 		* Verify the recoded variable
// 		tab1 parent_educ_?, missing

	* Define value labels for the ordered categories
		label define Lbl_scholarship 	0 "No"   ///
										1 "Didn't complete elementary school"  	///
										2 "Y, scholarship for >50% tuition"  	///
										3 "Y, scholarship for 100% tuition"  	///
										4 "Y, scholarship for tuition + living cost" ///
										,  replace 
			
			numlabel Lbl_scholarship, add mask("(#) ")
								
	
		replace scholarship = "0" if  scholarship == "No"
		replace scholarship = "1" if  scholarship == "Yes, the scholarship covers most of tuition (>50%)"
		replace scholarship = "2" if  scholarship == "Yes, the scholarship covers a part of tuition (<=50%)"
		replace scholarship = "3" if  scholarship == "Yes, the scholarship covers tuition completely"
		replace scholarship = "4" if  scholarship == "Yes, the scholarship covers tuition completely AND also covers additional living expenses"
	
		destring scholarship ,  replace 
		
		label values scholarship  Lbl_scholarship
		
	gen  scholarship_some = (scholarship >  0)
	 
	gen  scholarship_full = (scholarship >= 3)
	
		label var  	  scholarship_some  "Receives some scholarship "
		label values  scholarship_some  Lbl_Yes_No
	
		label var  	  scholarship_full  "Receives a full scholarship "
		label values  scholarship_full  Lbl_Yes_No
	
	* fix wait-time variable 
	replace wait_time_guess = substr(wait_time_guess, 1, 1)
	
		label define  Lbl_wait_time   0  "I get it as soon as I request it"  ///
					 				  8  "8 or more weeks"  , replace 
	
				numlabel Lbl_scholarship, add mask("(#) ")
	
		destring wait_time_guess, replace 
	
			label values wait_time_guess  Lbl_wait_time
		
			tab wait_time_guess , m

	/* Fix services */
	
	* define a label for the recoded variable
	label define Lbl_services ///
			1 "Have NOT heard about this service on campus" ///
			2 "Heard about this service on campus" ///
			3 "Heard about this service AND a friend/I used it", replace

			numlabel Lbl_services, add mask("(#) ")	
			
	* loop over the variables services_available_6, services_available_7, services_available_8
	foreach var of varlist  services_available_?  {
		di "1"
		* extract the numeric category from the start of the string and replace the variable
		replace `var' = substr(`var', 2, 1)
		di "2"
		* convert the variable to numeric
		destring `var', replace
		di "3"
			* assign the label to the variable
			label values `var' Lbl_services
		
		}
	
	
	/*************************************/
	/*      Generate new variables  	 */
	/*************************************/

	* get new vars 
	drop if uniqueid == ""
	
	* clean the dates : convert the string of the date part into date 
	gen date =  date(substr(startdate, 1, 11),"MDY", 2050)

		format date %td
		
		gen day = day(date)
		
		* drop our test responses before the survey was launched 
		drop if day < 14
				
			
	* get new vars 
		
	rename transfer_oth_therapy_1  donation_pct 

	rename wtp_1   		   wtp_therapy_self 
	rename wtp_friend_1    wtp_therapy_friend 

	* define label for treatment groups 
	label define Lbl_treat_group  	1 "T1: Info + Reflection"  ///
									2 "T2: Info only"  ///
									0 "Control"  , replace 
	
		numlabel  Lbl_treat_group , add mask("(#) ")
		
	gen treatm_group = .
		replace treatm_group = 1 if t1_info_a 	!= .
		replace treatm_group = 2 if t2_info_a 	!= .
		replace treatm_group = 0 if control_c_1 != .
		
		label values treatm_group  Lbl_treat_group 
		
		label var treatm_group  "Treatment group"

		
	* gen dummies by control / treatment type 
	gen control  	     = (treatm_group == 0) 
	gen treat_info_refl  = (treatm_group == 2) 
	gen treat_info 	     = (treatm_group == 1) 	
	
		replace control 		= . if treatm_group == .
		replace treat_info_refl	= . if treatm_group == .
		replace treat_info 		= . if treatm_group == .
		
	* get gender vars 	
	gen female = (gender == "Female")
	gen   male = (gender == "Male")

	* get a numeric categorical major 
	encode major, gen(major_id )

		* recode an "other" category to combine others 
		replace major_id = 9 if major_id == 1  // architecture + design 
		replace major_id = 9 if major_id == 3  // creative arts / humanities 
		replace major_id = 9 if major_id == 7  // other 

	* get a numeric var for year in college 
	gen year_uni = real(substr(degree_year, 1, 1))

	rename studies_22_guess_1     guess_22_studies
	rename open_to_share_guess_1  guess_open_to_share 
	rename wait_time_guess  	  guess_wait_time
	rename therapy_use_others_1   guess_therapy_use 
	
	rename guess_self_stigma_1    guess_self_stigma
	
	rename perceived_stigma_1   perceived_stigma_students
	rename perceived_stigma_2   perceived_stigma_profs
	rename perceived_stigma_3   perceived_stigma_stt_parents
	
	* fix the corr prior var 
	
	replace  prior_3_mh_gpa_corr  =  subinstr(prior_3_mh_gpa_corr , "correlation", "corr", .)

		
	gen prior_3_mh_gpa_num  =  . 

		replace  prior_3_mh_gpa_num  =  1  if  prior_3_mh_gpa_corr == "Much better      (corr > 0.5)"   
		replace  prior_3_mh_gpa_num  =  2  if  prior_3_mh_gpa_corr == "Better             (0.3 < corr < 0.5)"  
		replace  prior_3_mh_gpa_num  =  3  if  prior_3_mh_gpa_corr == "No better or worse (-0.3 < corr < 0.3)" 
		replace  prior_3_mh_gpa_num  =  4  if  prior_3_mh_gpa_corr == "Worse (-0.5 < corr < -0.3)"   
		replace  prior_3_mh_gpa_num  =  5  if  prior_3_mh_gpa_corr == "Much worse (corr < -0.5)" 
		
		
		label define  Lbl_prior_mh_gpa   ///
						1  "Much better (corr > 0.5)"  			///
						2  "Better (0.3, 0.5)"   				///
						3  "No better or worse (-0.3, 0.3)"   	///
						4  "Worse (-0.5, -0.3)"   		 		///
						5  "Much worse (corr < -0.5)"   		///
						,  replace 
		
		label values  prior_3_mh_gpa_num   Lbl_prior_mh_gpa 
		
	* get the extra vars 
	/* Generate MH distree score (0-24) */
	* get binary vars representing a score for each component
	foreach var in phq4_gad4_1 phq4_gad4_2 phq4_gad4_3 phq4_gad4_4 phq4_gad4_5 phq4_gad4_6 phq4_gad4_7 phq4_gad4_8 {
		generate `var'_num = ///
			cond(`var' == "Not at all",  			  0, ///
			cond(`var' == "Several Days", 			  1, ///
			cond(`var' == "More than half the days",  2, ///
			cond(`var' == "Nearly Every Day", 		  3, .))))
	}
	
	* get the total MH score as a sum of all components 
	egen mh_score = rowtotal(phq4_gad4_1_num-phq4_gad4_8_num)
	
		
	* clean up other varnames 
	
	rename therapy_misc_binary_1  prof_help_now 
	rename therapy_misc_binary_2  prof_help_ever 
	rename therapy_misc_binary_3  prof_help_friend_ever
	rename therapy_misc_binary_4  prof_help_friend_benefit
	rename therapy_misc_binary_5  open_to_share
	
	rename therapy_good_likert_1  therapy_good_self 
	rename therapy_good_likert_2  therapy_good_general
	rename therapy_good_likert_3  therapy_support_by_friends
	rename therapy_good_likert_4  therapy_support_by_parents
	
	
	rename services_available_1  available_health_cent
	rename services_available_2  available_psyc_counsl
	rename services_available_3  available_gym
	rename services_available_4  available_hotline
	rename services_available_5  available_acad_counsl
	rename services_available_6  available_career
	rename services_available_7  available_free_res
	rename services_available_8  available_meditat_space
	
	rename campus_support_1  campus_support_physical_act
	rename campus_support_2  campus_support_prof_help_emot
	rename campus_support_3  campus_support_finance_stress
	
	rename durationinseconds durations_sec
	
	rename locationlatitude   lat 
	rename locationlongitude  lon 
		
	
	* extra var cleaning 
	
	label var donation_pct "Donation % for therapy for a student w financ need" 
	
	rename  services_amount_12m  support_amount
	
		label var support_amount "Desired amount of prior mh support (past 12 month)" 
	
	replace support_amount =  "(1) As much support as needed (27%)"  ///
				if support_amount == "I received  as much support  (counseling, therapy, or medication) for my mental or emotional health as I wanted"
	replace support_amount =  "(2) Less support than desired (20%)"  ///
				if support_amount == "I received  less support  (counseling, therapy, or medication) for my mental or emotional health than I would have wanted"
	replace support_amount =  "(3) Was not seeking support (53%)"  ///
				if support_amount == "I was  not seeking support  (counseling, therapy, or medication) for my mental or emotional health"

	
	* get the joint treatment var 
	gen treat_any = (treatm_group == 1 | treatm_group == 2 )
	
		* define label for treatment groups 
		label define Lbl_treat_any  	1 "Any treatment (T1+T2)"  ///
										0 "Control"  , replace 
		
		numlabel  Lbl_treat_any , add mask("(#) ")
		
		label values treat_any  Lbl_treat_any 
		
		label var treat_any  "Treatment (any, t1/t2)"
	
		* define label for treatment groups 
		label define Lbl_treat_any  	1 "Treated "  ///
										0 "Control"  , replace 
		
			numlabel  Lbl_treat_any , add mask("(#) ")
		
			label values treat_any  Lbl_treat_any 
		

	
	****************************************
	* 		Extra vars + cleaning 
	****************************************	
	
	* recode ranks to outcomes comparing MH symptoms / talking to low academic performance
	gen prefer_mh_sympt_over_low_gpa 	= (rank_3 < rank_10)
	gen prefer_mh_talk_over_low_gpa		= (rank_9 < rank_10)
		
	* recode ranks to outcomes comparing MH symptoms / talking to low academic performance
	gen prefer_low_gpa_over_mh_sympt 	= (rank_3 > rank_10)
	gen prefer_low_gpa_over_mh_talk 	= (rank_9 > rank_10)
		
		label var prefer_low_gpa_over_mh_sympt 	"Rank low-gpa over MH distress symptoms"
		label var prefer_low_gpa_over_mh_talk 	"Rank low-gpa over talking about MH"
	
	* get a mental distress dummy 
	gen mental_distress = (mh_score >= 12)
	
		label var mental_distress  "Mental distress (dummy) (if mh score >= 12)"
	
	rename advice_outcome  advice

	rename  prefer_mh_sympt_over_low_gpa   pref_mh_symp_v_low_gpa 
	rename  prefer_mh_talk_over_low_gpa    pref_mh_talk_v_low_gpa
	
	rename wta_1   wta_therapy_self
	
	gen 		wta_wtp_therapy_self = .
		replace wta_wtp_therapy_self = - wta_therapy_self  	if wtp_therapy_self == 0
		replace wta_wtp_therapy_self =   wtp_therapy_self  	if wtp_therapy_self >  0
	
		label var wtp_therapy_self      "WTP for therapy for self (pesos)"
		label var wta_therapy_self  	"WTA for therapy for self if WTP = 0 (pesos)"
		
		label var wtp_therapy_friend    "WTP for therapy for friend (pesos)"
		label var wta_wtp_therapy_self  "WTP for therapy + WTA if zero (pesos)"
		
	
	replace donation_pct = donation_pct / 100
	
		label var prefer_low_gpa_over_mh_sympt 	"Rank low-gpa over MH distress symptoms"
		label var prefer_low_gpa_over_mh_talk 	"Rank low-gpa over talking about MH"
	
	
	
	
	****************************************
	****************************************	
	
	
	****************************************
	* 		Take the final sample  
	****************************************	
	
	/* Subset to the final sample */
		
		* drop the incomplete responses 
		drop if progress != 100	
		
		* drop those who provided did not create a unique ID 
		drop if uniqueid == "ma09he12"
		
		* get a numeric student id 
		encode responseid , gen(student_id)
			
			drop  responseid
			
		isid uniqueid 
		
		sort uniqueid 
			
		compress 	
		
		label data "MH survey data by student 2024-11"
			
		save "${clean}/mh_survey_analysis_v0.dta" , replace 
	
	
	
	
	
	****************************************************
	****************************************************
	* 		Extra cleaning from descriptive files   
	****************************************************	
	****************************************************
	
	use "${clean}/mh_survey_analysis_v0.dta" , replace 

		
		/* Bring in processed vars for advice */
		merge m:1 uniqueid using "${processed}/advice_with_flags_w_counts.dta",  nogen 
		
		
		/* Add extra vars / dummies for analysis */
		
		* get dummy for self-stigma 
		gen d_self_stigma = (self_stigma <= 3)
		
			label var d_self_stigma  "I'd feel disappointed if I had a mental health issue"
			
			label var d_self_stigma  "Self-stigma dummy (feels disappointed if MH issue)"
		
		
		* get a dummy var for those who said some degree of "unlikely" for turning for help when seeking help 
		gen unlikely_seek_help  = ustrregexm(likely_seek_help ,"nlikely")
		
			label var unlikely_seek_help  "Unlikely seek help dummy (from Lickert)"
		
		
		* get dummies for correct/incorrect beliefs/priors 
		gen d_incorr_prior_2_mild_moder = ( prior_2_mild_moder != 1)
		gen d_incorr_prior_3_gpa  		= ( prior_3_mh_gpa_num != 3)
		
			label var d_incorr_prior_2_mild_moder  	"Incorrect prior (symp)"
			label var d_incorr_prior_3_gpa  		"Incorrect prior (gpa)"
		
				
		/* Winsorize main continuous outcomes */ 	
		
		winsor wta_wtp_therapy_self , p(0.01) gen(winsor_wta_wtp_therapy_self)
		winsor wtp_therapy_friend   , p(0.01) gen(winsor_wtp_therapy_friend)
		
			sum wtp_therapy_self  wta_wtp_therapy_self  winsor_wta_wtp_therapy_self , d
			
			sum wtp_therapy_friend  winsor_wtp_therapy_friend , d
		
			sum wtp_therapy_self  wta_wtp_therapy_self, d

		
		gen wtp_therapy_pct_self    = wtp_therapy_self   	/ 6400
		gen wtp_therapy_pct_friend  = wtp_therapy_friend   	/ 6400
		
		gen winz_wtp_therapy_pct_self    = winsor_wta_wtp_therapy_self   	/ 6400
	
	
	***********************************************************
	***********************************************************
	
	label var mental_distress "Mental distress (0/1)"
	
	label var wtp_therapy_pct_self  	"WTP therapy (self) (%)"
	label var wtp_therapy_pct_friend  	"WTP therapy (friend) (%)"
	
	label var donation_pct "Donation for therapy"
	
	label var advice_mention_prof_help  "Mentioned Therapy as Advice"
	
	label var pref_mh_symp_v_low_gpa  "Prefer distressed > low GPA"  
	label var pref_mh_talk_v_low_gpa   "Prefer MH talk > low GPA"
	
	
	***********************************************************
	
	* Create dummy variables using regex or simple string matching
	gen whom_help_mh_prof  		= strpos(whom_turned_for_help, "Mental health professionals") > 0
	gen whom_help_academ_progr  = strpos(whom_turned_for_help, "Academic program") > 0
								  
// 								  strpos(whom_turned_for_help, "Academic program faculty members") > 0  |  ///
// 								  strpos(whom_turned_for_help, "Academic program staff members") > 0
//	
	gen whom_help_family 	= 	strpos(whom_turned_for_help, "Family")  > 0    
	
	gen whom_help_friends 	= 	strpos(whom_turned_for_help, "Friends") > 0
	
	gen whom_help_fam_friends 	= 	strpos(whom_turned_for_help, "Family")  > 0    |  ///
									strpos(whom_turned_for_help, "Friends") > 0
	
	gen whom_help_noone 		= strpos(whom_turned_for_help, "Did not turn to anyone") > 0
	gen whom_help_no_issues   	= strpos(whom_turned_for_help, "Did not have an issue") > 0

		
		* inverse the dummy for reporting no MH issues
		gen had_issues_past_12m = (whom_help_no_issues - 1) * (-1)
		
			label var had_issues_past_12m  "Dummy for having MH issues in the last 12m (not saying 'no  issues')"
		
			* check the var inversion
			tab mental_distress had_issues_past_12m , cell
	
// 	* Check the distribution of dummies
// 	tab1  whom_help_*
//
// 	bysort mental_distress: tab whom_help_noone
// 	bysort mental_distress: tab whom_help_no_issues

	
	***********************************************************
	***********************************************************
	
	* Affordable cost of therapy
	gen pro_therapy_cost_1st  = strpos(factors_pro_therapy_1, "Affordable cost of therapy") > 0
	gen pro_therapy_cost_top3 = strpos(factors_pro_therapy_1, "Affordable cost of therapy") > 0 |   ///  
								strpos(factors_pro_therapy_2, "Affordable cost of therapy") > 0 |   ///  
								strpos(factors_pro_therapy_3, "Affordable cost of therapy") > 0

	* Belief in the potential benefits of therapy
	gen pro_therapy_benefits_1st  = strpos(factors_pro_therapy_1, "Belief in the potential benefits of therapy") > 0
	gen pro_therapy_benefits_top3 = strpos(factors_pro_therapy_1, "Belief in the potential benefits of therapy") > 0 |   ///  
									strpos(factors_pro_therapy_2, "Belief in the potential benefits of therapy") > 0 |   /// 
									strpos(factors_pro_therapy_3, "Belief in the potential benefits of therapy") > 0

	* Clear information about available services
	gen pro_therapy_info_1st  = strpos(factors_pro_therapy_1, "Clear information about available services") > 0
	gen pro_therapy_info_top3 = strpos(factors_pro_therapy_1, "Clear information about available services") > 0 |   ///  
								strpos(factors_pro_therapy_2, "Clear information about available services") > 0 |   ///  
								strpos(factors_pro_therapy_3, "Clear information about available services") > 0

	* Confidence in privacy and confidentiality
	gen pro_therapy_privacy_1st = strpos(factors_pro_therapy_1, "Confidence in privacy and confidentiality") > 0
	gen pro_therapy_privacy_top3 = strpos(factors_pro_therapy_1, "Confidence in privacy and confidentiality") > 0 |   ///  
									strpos(factors_pro_therapy_2, "Confidence in privacy and confidentiality") > 0 |   ///  
									strpos(factors_pro_therapy_3, "Confidence in privacy and confidentiality") > 0

	* Convenient appointment availability
	gen pro_therapy_availab_1st  = strpos(factors_pro_therapy_1, "Convenient appointment availability") > 0
	gen pro_therapy_availab_top3 = strpos(factors_pro_therapy_1, "Convenient appointment availability") > 0 |   ///  
									strpos(factors_pro_therapy_2, "Convenient appointment availability") > 0 |   ///  
									strpos(factors_pro_therapy_3, "Convenient appointment availability") > 0

	* Flexible personal schedule
	gen pro_therapy_time_1st  = strpos(factors_pro_therapy_1, "Flexible personal schedule") > 0
	gen pro_therapy_time_top3 = strpos(factors_pro_therapy_1, "Flexible personal schedule") > 0 |   ///  
									strpos(factors_pro_therapy_2, "Flexible personal schedule") > 0 |   ///  
									strpos(factors_pro_therapy_3, "Flexible personal schedule") > 0

	* Hearing about someone who benefited from therapy
	gen pro_therapy_hearing_1st  = strpos(factors_pro_therapy_1, "Hearing about someone who benefited from therapy") > 0
	gen pro_therapy_hearing_top3 = strpos(factors_pro_therapy_1, "Hearing about someone who benefited from therapy") > 0 |   ///  
									strpos(factors_pro_therapy_2, "Hearing about someone who benefited from therapy") > 0 |   ///  
									strpos(factors_pro_therapy_3, "Hearing about someone who benefited from therapy") > 0

	* Supportive attitudes of others
	gen pro_therapy_support_1st  = strpos(factors_pro_therapy_1, "Supportive attitudes of others") > 0
	gen pro_therapy_support_top3 = strpos(factors_pro_therapy_1, "Supportive attitudes of others") > 0 |   ///  
									strpos(factors_pro_therapy_2, "Supportive attitudes of others") > 0 |   ///  
									strpos(factors_pro_therapy_3, "Supportive attitudes of others") > 0

	* replace pro factors with missings where not reported 
	foreach var of varlist pro_therapy_* {
		replace `var' = . if factors_pro_therapy_1 == ""
	}
	
	* Check the created variables
	describe pro_therapy_*

	
		* Add labels for "whom_help_*" variables
		label var whom_help_mh_prof  	 "Sought help from mental health professionals"
		label var whom_help_academ_progr "Sought help from academic faculty or staff"
		
		label var whom_help_fam_friends  "Sought help from family or friends"
		label var whom_help_family  	 "Sought help from family"
		label var whom_help_friends   	 "Sought help from friends"
		
		label var whom_help_noone   	 "Did not turn to anyone for help"
		label var whom_help_no_issues 	 "Did not have mental health issues"

		* Add labels for "pro_therapy_*" variables (reasons for seeking therapy)
		
		label var pro_therapy_cost_1st 	 		"Main pro: Affordable cost of therapy"
		label var pro_therapy_cost_top3  		"Top3 pro: Affordable cost of therapy"

		label var pro_therapy_benefits_1st 		"Main pro: Belief in therapy benefits"
		label var pro_therapy_benefits_top3 	"Top3 pro: Belief in therapy benefits"

		label var pro_therapy_info_1st 			"Main pro: Clear information about services"
		label var pro_therapy_info_top3 		"Top3 pro: Clear information about services"

		label var pro_therapy_privacy_1st 		"Main pro: Confidence in privacy/confidentiality"
		label var pro_therapy_privacy_top3 		"Top3 pro: Confidence in privacy/confidentiality"

		label var pro_therapy_availab_1st 		"Main pro: Convenient appointment availability"
		label var pro_therapy_availab_top3 		"Top3 pro: Convenient appointment availability"

		label var pro_therapy_time_1st 			"Main pro: Flexible personal schedule"
		label var pro_therapy_time_top3 		"Top3 pro: Flexible personal schedule"

		label var pro_therapy_hearing_1st 		"Main pro: Heard of someone benefiting from therapy"
		label var pro_therapy_hearing_top3 		"Top3 pro: Heard of someone benefiting from therapy"

		label var pro_therapy_support_1st 		"Main pro: Supportive attitudes of others"
		label var pro_therapy_support_top3 		"Top3 pro: Supportive attitudes of others"

		
	***********************************************************
		
		* binarize barrier factors 
		* Cost of therapy
		gen barrier_therapy_cost_1st = 	strpos(barriers_therapy_1, "Cost of therapy") > 0
		gen barrier_therapy_cost_top3 = strpos(barriers_therapy_1, "Cost of therapy") > 0 |    ///  
										strpos(barriers_therapy_2, "Cost of therapy") > 0 |    ///  
										strpos(barriers_therapy_3, "Cost of therapy") > 0

		* Appointment availability
		gen barrier_therapy_availab_1st = 	strpos(barriers_therapy_1, "Appointment availability") > 0
		gen barrier_therapy_availab_top3 = 	strpos(barriers_therapy_1, "Appointment availability") > 0 |    ///  
											strpos(barriers_therapy_2, "Appointment availability") > 0 |    ///  
											strpos(barriers_therapy_3, "Appointment availability") > 0

		* Concerns about privacy or confidentiality
		gen barrier_therapy_privacy_1st = 	strpos(barriers_therapy_1, "Concerns about privacy or confidentiality") > 0
		gen barrier_therapy_privacy_top3 = 	strpos(barriers_therapy_1, "Concerns about privacy or confidentiality") > 0 |    ///  
											strpos(barriers_therapy_2, "Concerns about privacy or confidentiality") > 0 |    ///  
											strpos(barriers_therapy_3, "Concerns about privacy or confidentiality") > 0

		* Fear of being judged by others
		gen barrier_therapy_judged_1st  = 	strpos(barriers_therapy_1, "Fear of being judged by others") > 0
		gen barrier_therapy_judged_top3 = 	strpos(barriers_therapy_1, "Fear of being judged by others") > 0 |    ///  
											strpos(barriers_therapy_2, "Fear of being judged by others") > 0 |    ///  
											strpos(barriers_therapy_3, "Fear of being judged by others") > 0

		* Hearing about someone who felt therapy was unhelpful
		gen barrier_therapy_hearing_1st = 	strpos(barriers_therapy_1, "Hearing about someone who felt therapy was not effective") > 0
		gen barrier_therapy_hearing_top3 = 	strpos(barriers_therapy_1, "Hearing about someone who felt therapy was not effective") > 0 |    ///  
											strpos(barriers_therapy_2, "Hearing about someone who felt therapy was not effective") > 0 |    ///  
											strpos(barriers_therapy_3, "Hearing about someone who felt therapy was not effective") > 0

		* Lack of information about available services
		gen barrier_therapy_info_1st  = 	strpos(barriers_therapy_1, "Lack of information about available") > 0
		gen barrier_therapy_info_top3 = 	strpos(barriers_therapy_1, "Lack of information about available") > 0 |    ///  
											strpos(barriers_therapy_2, "Lack of information about available") > 0 |    ///  
											strpos(barriers_therapy_3, "Lack of information about available") > 0

		* Not feeling that therapy is necessary
		gen barrier_therapy_unnecess_1st  = strpos(barriers_therapy_1, "Not feeling that therapy is necessary or useful") > 0
		gen barrier_therapy_unnecess_top3 = strpos(barriers_therapy_1, "Not feeling that therapy is necessary or useful") > 0 |    ///  
											strpos(barriers_therapy_2, "Not feeling that therapy is necessary or useful") > 0 |    ///  
											strpos(barriers_therapy_3, "Not feeling that therapy is necessary or useful") > 0

		* Personal time constraints
		gen barrier_therapy_time_1st  = 	strpos(barriers_therapy_1, "Personal time constraints") > 0
		gen barrier_therapy_time_top3 = 	strpos(barriers_therapy_1, "Personal time constraints") > 0 |    ///  
											strpos(barriers_therapy_2, "Personal time constraints") > 0 |    ///  
											strpos(barriers_therapy_3, "Personal time constraints") > 0

		* replace pro factors with missings where not reported 
		foreach var of varlist barrier_therapy_* {
			replace `var' = . if barriers_therapy_1 == ""
			}																	
										
			* Add labels for all variables
			label var barrier_therapy_cost_1st 			"Primary reason: Cost of therapy"
			label var barrier_therapy_cost_top3 		"Top 3 reasons: Cost of therapy"

			label var barrier_therapy_availab_1st 		"Primary reason: Appointment availability"
			label var barrier_therapy_availab_top3 		"Top 3 reasons: Appointment availability"

			label var barrier_therapy_privacy_1st 		"Primary reason: Concerns about privacy or confidentiality"
			label var barrier_therapy_privacy_top3 		"Top 3 reasons: Concerns about privacy or confidentiality"

			label var barrier_therapy_judged_1st 		"Primary reason: Fear of being judged by others"
			label var barrier_therapy_judged_top3 		"Top 3 reasons: Fear of being judged by others"

			label var barrier_therapy_hearing_1st 		"Primary reason: Heard therapy was unhelpful"
			label var barrier_therapy_hearing_top3 		"Top 3 reasons: Heard therapy was unhelpful"

			label var barrier_therapy_info_1st 			"Primary reason: Lack of information about services"
			label var barrier_therapy_info_top3 		"Top 3 reasons: Lack of information about services"

			label var barrier_therapy_unnecess_1st 		"Primary reason: Therapy not felt necessary"
			label var barrier_therapy_unnecess_top3 	"Top 3 reasons: Therapy not felt necessary"

			label var barrier_therapy_time_1st 			"Primary reason: Personal time constraints"
			label var barrier_therapy_time_top3 		"Top 3 reasons: Personal time constraints"

// 	* Verify all created variables and labels
// 	describe barrier_therapy_*
// 	label list

		
		
	***********************************************************	
		
		isid uniqueid 
		
		sort uniqueid 
			
		compress 	
		
		label data "MH survey data by student 2024-11 (w extra vars)"
		

		save "${clean}/mh_survey_analysis.dta" , replace 


	
	
	***********************************************************
	***********************************************************
	
/*


	




