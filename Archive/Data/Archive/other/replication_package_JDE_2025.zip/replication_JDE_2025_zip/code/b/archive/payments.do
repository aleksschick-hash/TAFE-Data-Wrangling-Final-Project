/* ----------------------------------------------------------------------------
						Mental Health Survey Answers
	
	Do file objective: 
		- Determine type of payment for different types of respondents.
	

---------------------------------------------------------------------------- */


* Change directory to where the data file is located
cd "/Users/brunocalderon/Documents/MH-UCSD/data"

* Load the dataset
use "mh_survey_analysis_with_mhscore.dta", clear

* Keep only observations where 'finished' equals "True"
keep if finished == "True"

* Convert 'recordeddate' to Stata date-time format
generate double recorded_datetime = clock(recordeddate, "MDY hm")
format recorded_datetime %tc



* Step 1: Determine the first 100 respondents
* Sort data by recorded date-time in ascending order (earliest first)
sort recorded_datetime
* Create a variable indicating the order of respondents
generate respondent_order = _n
* Create a dummy variable for the first 100 respondents
generate first_100 = (respondent_order <= 100)



* Step 2: Randomly select 20 respondents for the 1,000-peso gift card
* Set seed for reproducibility
set seed 1917
* Generate a random number for each respondent
generate double rand_giftcard = runiform()
* Sort data by the random number
sort rand_giftcard
* Create a dummy variable for the 20 randomly selected respondents
generate gift_card_1000 = (_n <= 20)




* Step 3: Randomly select 5 respondents to implement outcome of WTP for self
* Set seed for reproducibility
set seed 23456
* Generate a random number for selection
generate double rand_wtp_self = runiform()
* Sort data by the random number
sort rand_wtp_self
* Create a dummy variable for WTP-Self respondents
generate wtp_self_select = (_n <= 5)
* For selected respondents, randomly assign either therapy coupon or payout
* Generate a random number for outcome assignment (only for selected respondents)
generate double rand_outcome_self = runiform() if wtp_self_select == 1
* Create a dummy variable indicating if the respondent receives the payout
generate payout_self = (rand_outcome_self <= 0.5) if wtp_self_select == 1
replace payout_self = 0 if missing(payout_self)
* Create a dummy variable indicating if the respondent receives the therapy coupon
generate therapy_coupon_self = (payout_self == 0) if wtp_self_select == 1
replace therapy_coupon_self = 0 if missing(therapy_coupon_self)
* Assign the payout amount to 'wtp' for respondents receiving the payout
generate wtp = 0
replace wtp = wtp_therapy_self if payout_self == 1




* Step 4: Randomly select 5 different respondents to implement outcome of WTP for a friend
* Identify respondents not selected for WTP-Self
generate not_wtp_self = (wtp_self_select == 0)
* Generate a random number for those not selected for WTP-Self
generate double rand_wtp_friend = runiform() if not_wtp_self == 1
* Assign a high number to rand_wtp_friend where not eligible (so they sort last)
replace rand_wtp_friend = 2 if missing(rand_wtp_friend)
* Sort data by rand_wtp_friend
sort rand_wtp_friend
* Create a dummy variable for WTP-Friend respondents
generate wtp_friend_select = (_n <= 5) & (not_wtp_self == 1)
* For selected respondents, randomly assign either therapy coupon or payout
* Generate a random number for outcome assignment (only for selected respondents)
generate double rand_outcome_friend = runiform() if wtp_friend_select == 1
* Create a dummy variable indicating if the respondent receives the payout
generate payout_friend = (rand_outcome_friend <= 0.5) if wtp_friend_select == 1
replace payout_friend = 0 if missing(payout_friend)
* Create a dummy variable indicating if the respondent's friend receives the therapy coupon
generate therapy_coupon_friend = (payout_friend == 0) if wtp_friend_select == 1
replace therapy_coupon_friend = 0 if missing(therapy_coupon_friend)
* Assign the payout amount to 'wtp_friend' for respondents receiving the payout
generate wtp_friend = 0
replace wtp_friend = wtp_therapy_friend if payout_friend == 1



	
* Step 5: Assign bonus questions

* Set seed for reproducibility
set seed 24680

* Generate a random integer between 1 and 8 for each participant
generate bonus_question = floor(8 * runiform()) + 1

* Ensure 'bonus_payment' is numeric
capture drop bonus_payment
generate bonus_payment = 0

* Initialize review flag for Question 8
generate flag_q8 = 0

* Loop over each bonus question
forvalues q = 1/8 {
    * Identify participants assigned to question q
    quietly generate byte temp_q = (bonus_question == `q')

    if `q' == 1 {
        * Question 1: 'therapy_use_others_1' based on 'therapy_use_12m'

        * Ensure 'therapy_use_12m' is properly formatted
        replace therapy_use_12m = trim(lower(therapy_use_12m))
        destring therapy_use_others_1, replace ignore(".,") force

        * Calculate actual percentage of 'Yes' responses
        quietly {
            egen total_responses = count(therapy_use_12m)
            egen yes_responses = total(therapy_use_12m == "yes")
            gen actual_percentage = (yes_responses / total_responses) * 100
        }
        replace actual_percentage = round(actual_percentage)

        * Assign bonus payment
        replace bonus_payment = 50 if temp_q & (therapy_use_others_1 == actual_percentage)

        * Drop temporary variables
        drop total_responses yes_responses actual_percentage
    }
    else if `q' == 2 {
        * Question 2: 'open_to_share_guess_1' based on 'therapy_misc_binary_5'

        * Ensure 'therapy_misc_binary_5' is properly formatted
        replace therapy_misc_binary_5 = trim(lower(therapy_misc_binary_5))
        destring open_to_share_guess_1, replace ignore(".,") force

        * Calculate actual percentage of 'Yes' responses
        quietly {
            egen total_responses = count(therapy_misc_binary_5)
            egen yes_responses = total(therapy_misc_binary_5 == "yes")
            gen actual_percentage = (yes_responses / total_responses) * 100
        }
        replace actual_percentage = round(actual_percentage)

        * Assign bonus payment
        replace bonus_payment = 50 if temp_q & (open_to_share_guess_1 == actual_percentage)

        * Drop temporary variables
        drop total_responses yes_responses actual_percentage
    }
    else if `q' == 3 {
        * Question 3: 'studies_22_guess_1' - 50 pesos if response is 22

        * Ensure 'studies_22_guess_1' is numeric
        capture confirm numeric variable studies_22_guess_1
        if _rc {
            destring studies_22_guess_1, replace ignore(".,") force
        }

        * Assign bonus payment
        replace bonus_payment = 50 if temp_q & (studies_22_guess_1 == 22)
    }
    else if `q' == 4 {
        * Question 4: 'guess_self_stigma_1' based on 'self_stigma'

        * Ensure 'guess_self_stigma_1' is numeric
        capture confirm numeric variable guess_self_stigma_1
        if _rc {
            destring guess_self_stigma_1, replace ignore(".,") force
        }

        * Identify the numeric codes for the responses
        * Codes for 'Strongly agree', 'Agree', 'Somewhat agree' are 1, 2, 3

        * Calculate total number of responses
        quietly {
            egen total_responses = count(self_stigma)
            egen agree_responses = total(inlist(self_stigma, 1, 2, 3))
            gen actual_percentage = (agree_responses / total_responses) * 100
        }
        replace actual_percentage = round(actual_percentage)

        * Assign bonus payment
        replace bonus_payment = 50 if temp_q & (guess_self_stigma_1 == actual_percentage)

        * Drop temporary variables
        drop total_responses agree_responses actual_percentage
    }
    else if `q' == 5 {
    * Question 5: 'prior_1_effective' - 50 pesos if 'Yes', 0 if 'No'

    * Ensure 'prior_1_effective' is properly formatted: trim spaces and convert to lowercase
    replace prior_1_effective = trim(lower(prior_1_effective))

    * Assign bonus payment of 50 pesos if the response starts with "yes"
    replace bonus_payment = 50 if temp_q & substr(prior_1_effective, 1, 3) == "yes"
}

else if `q' == 6 {
    * Question 6: 'prior_2_mild_moder' - 50 pesos if 'Yes', 0 if 'No'

    * Ensure 'prior_2_mild_moder' is properly formatted: trim spaces and convert to lowercase
    replace prior_2_mild_moder = trim(lower(prior_2_mild_moder))

    * Assign bonus payment of 50 pesos if the response starts with "yes"
    replace bonus_payment = 50 if temp_q & substr(prior_2_mild_moder, 1, 3) == "yes"
}
    else if `q' == 7 {
        * Question 7: 'prior_3_mh_gpa_corr' based on 'gpa_1' and 'mh_score'

        * Ensure 'gpa_1' and 'mh_score' are numeric
        destring gpa_1, replace ignore(".,") force
        destring mh_score, replace ignore(".,") force

        * Compute the correlation
        quietly {
            corr gpa_1 mh_score, means
            matrix C = r(C)
            scalar corr_coeff = C[1,2]
        }

        * Determine the correlation category
        gen str38 corr_category = ""
        replace corr_category = "Much worse" if corr_coeff < -0.5
        replace corr_category = "Worse" if corr_coeff >= -0.5 & corr_coeff < -0.3
        replace corr_category = "No better or worse" if corr_coeff >= -0.3 & corr_coeff <= 0.3
        replace corr_category = "Better" if corr_coeff > 0.3 & corr_coeff <= 0.5
        replace corr_category = "Much better" if corr_coeff > 0.5

        * Ensure 'prior_3_mh_gpa_corr' is properly formatted
        replace prior_3_mh_gpa_corr = trim(lower(prior_3_mh_gpa_corr))

        * Assign bonus payment
        replace bonus_payment = 50 if temp_q & prior_3_mh_gpa_corr == corr_category

        * Drop temporary variables
        drop corr_category
    }
    else if `q' == 8 {
        * Question 8: 'advice_response' open-ended question

        * Automatically assign bonus_payment = 50
        replace bonus_payment = 50 if temp_q

        * Flag for review
        replace flag_q8 = 1 if temp_q
    }

    * Drop the temporary variable
    drop temp_q
}
* Ensure bonus_payment is numeric and has no missing values
replace bonus_payment = 0 if missing(bonus_payment)


* Step 6: Calculate Total Pre-Final Payout
* Initialize total pre-final payment
generate total_prefinal_payment = 0
* 1. Assign 200 pesos to first 100 respondents
replace total_prefinal_payment = total_prefinal_payment + (first_100 * 200)
* 2. Assign 1,000 pesos to the 20 randomly selected gift card recipients
replace total_prefinal_payment = total_prefinal_payment + (gift_card_1000 * 1000)
* 3. Add WTP-Self payout
replace total_prefinal_payment = total_prefinal_payment + wtp
* 4. Add WTP-Friend payout
replace total_prefinal_payment = total_prefinal_payment + wtp_friend
* 5. Add bonus payment
replace total_prefinal_payment = total_prefinal_payment + bonus_payment


* Step 7: Apply Donation Amount
* Convert percentages greater than 1 to proportions
gen transfer_oth_therapy_prop = transfer_oth_therapy / 100 if transfer_oth_therapy > 1
* Handle missing values in 'transfer_oth_therapy' (assuming no donation if missing)
replace transfer_oth_therapy_prop = 0 if missing(transfer_oth_therapy_prop)
* Calculate the final payment
generate final_payment = total_prefinal_payment * (1 - transfer_oth_therapy_prop)


* Save the final dataset
save "/Users/brunocalderon/Documents/MH-UCSD/data/mh_survey_analysis_with_payments.dta", replace
