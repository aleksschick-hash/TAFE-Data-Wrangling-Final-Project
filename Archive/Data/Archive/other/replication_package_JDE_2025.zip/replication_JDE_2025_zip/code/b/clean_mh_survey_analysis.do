

	****************************************************
	****************************************************
	* 		Extra cleaning from descriptive files   
	****************************************************	
	****************************************************
	
	
	use "${processed}/mh_survey_analysis_draft.dta" , replace 

		
	*********************************************************
	* 	    Merge in additionally processed vars 
	*********************************************************
		
// 		/* Bring in processed vars for advice */
// 		merge m:1 uniqueid using "${processed}/advice_with_flags_w_counts.dta",  nogen 
		
		/* Bring in processed vars for advice */
		merge 1:1 uniqueid using "${processed}/stigma_index_by_student.dta",  nogen 
	
		/* ***************************************** */
		/* organize & process stimga index measures  */
		/* ***************************************** */
		
		sum stigma_index?, d

		egen z_stigma_index1 = std(stigma_index1)
		egen z_stigma_index2 = std(stigma_index2)
		
			label var z_stigma_index1  "Stigma index (comp1, Z score)"
			label var z_stigma_index2  "Stigma index (comp2, Z score)"
			
		sum z_stigma_index1, d
		
			gen d_stigma1_above_avg = z_stigma_index1 > r(mean)
			gen d_stigma1_above_p50 = z_stigma_index1 > r(p50)
			gen d_stigma1_above_p75 = z_stigma_index1 > r(p75)

		sum z_stigma_index2, d
		
			gen d_stigma2_above_avg = z_stigma_index2 > r(mean)
			gen d_stigma2_above_p50 = z_stigma_index2 > r(p50)
			gen d_stigma2_above_p75 = z_stigma_index2 > r(p75)

	
	***********************************************************
	***********************************************************
	
		/* ***************************************** */
		/*   Clean & Harmonize Prof Help Use Vars    */
		/* ***************************************** */
	
		* clean up var names to what we asked exactly 
		rename therapy_use_12m    prof_help_campus_12m  
		
			label var  prof_help_campus_12m  "Used prof MH services on campus (last 12 months) Y/N"
		
		* get the distinct variable 
		gen whom_help_prof_help_campus  = (strpos(whom_turned_for_help, "Mental health professionals at your u") > 0)
		gen whom_help_prof_help_outside = (strpos(whom_turned_for_help, "Mental health professionals outside") > 0)
		
			label var whom_help_prof_help_campus  "Sought help from mental health professionals AT the university"
			label var whom_help_prof_help_outside "Sought help from mental health professionals OUTSIDE the university"
		
		* clean up var names 
		rename whom_help_mh_prof  whom_help_prof_help 
		
		* get the correct therapy_use_12m var var for any type of mh help (on or off campus)
		clonevar therapy_use_12m = whom_help_prof_help  
		
		* get the opposite dummy for no therapy in the last 12m
		gen no_therapy_12m = ( therapy_use_12m == 0 ) 
		
			label var no_therapy_12m "No Therapy 12m"

		
	***********************************************************
	***********************************************************
		
	label drop student_id
	
// 		label define  Lbl_treat_txt  0  "Control"  1  "Treated `=char(13)'`=char(10)'" , replace 
		label define  Lbl_treat_txt  0  "Control"  1  "Treated " , replace 
		
		label values treat_any  Lbl_treat_txt
	
	label var  distress	"Mental Distress" 
	
	
	***********************************************************
	***********************************************************
	
	
	*********************************************************
	*   Create vars for correct/incorrect prior groups 
	*********************************************************
	
		
		/* Add extra vars / dummies for analysis */
		
		* get dummy for self-stigma 
		gen d_self_stigma = (self_stigma <= 3)
		
			label var d_self_stigma  "I'd feel disappointed if I had a mental health issue"
			
			label var d_self_stigma  "Self-stigma dummy (feels disappointed if MH issue)"
		
		
		* get a dummy var for those who said some degree of "unlikely" for turning for help when 
		gen unlikely_seek_help  = ustrregexm(likely_seek_help ,"nlikely")
		
			label var unlikely_seek_help  "Unlikely seek help dummy (from Lickert)"
		
		
		* get dummies for correct/incorrect beliefs/priors 
		gen d_incorr_prior_1_effective  = ( prior_1_effective == 0 ) 
		gen d_incorr_prior_2_mild_moder = ( prior_2_mild_moder != 1)
		gen d_incorr_prior_3_gpa  		= ( prior_3_mh_gpa_num != 3)
		
			label var d_incorr_prior_1  			"Incorrect prior (LR effect)"
			label var d_incorr_prior_2_mild_moder  	"Incorrect prior (sympt)"
			label var d_incorr_prior_3_gpa  		"Incorrect prior (GPA-MH)"
		

	***********************************************************			
	***********************************************************	 
	
		* extra interaction terms 
		gen d_incorr_priors_2_3_int = d_incorr_prior_2_mild_moder * d_incorr_prior_3_gpa
		
		gen d_distress_WO_therapy 	= distress * no_therapy_12m
	
	
		* explore group composition by 3 priors 
		
		gen temp_incorr_priors = d_incorr_prior_1_effective * 100 + d_incorr_prior_2_mild_moder * 10 + d_incorr_prior_3_gpa 
		
			label define Lbl_tmp_prior_group   ///
					0    "(0)   All correct" 						///
					1    "(3)   Only GPA-MH prior (3) incorrect" 		///
					10   "(2)   Only Mild/Moder prior (2) incorrect" 	///
					11   "(23)  Priors 2 & 3 incorrect" 				///
					100  "(1)   Only Effectiveness prior (1) incorrect" ///
					101  "(13)  Priors 1 & 3 incorrect" 				///
					110  "(12)  Priors 1 & 2 incorrect" 				///
					111  "(123) All incorrect"  						/// 
						, replace 

			* Assign the value labels to the variable
			label val temp_incorr_priors Lbl_tmp_prior_group   

		* Generate a new variable to store the simplified values
		gen incorr_priors = .
			replace incorr_priors = 0 		if temp_incorr_priors == 0
			replace incorr_priors = 3 		if temp_incorr_priors == 1
			replace incorr_priors = 2 		if temp_incorr_priors == 10
			replace incorr_priors = 23 		if temp_incorr_priors == 11
			replace incorr_priors = 1 		if temp_incorr_priors == 100
			replace incorr_priors = 13 		if temp_incorr_priors == 101
			replace incorr_priors = 12 		if temp_incorr_priors == 110
			replace incorr_priors = 123 	if temp_incorr_priors == 111

		* define the new value label
		label define Lbl_incorr_priors ///
			0    "(0)   All correct" ///
			1    "(1)   Only Effectiveness prior (1) incorrect" ///
			2    "(2)   Only Mild/Moder prior (2) incorrect" ///
			3    "(3)   Only GPA-MH prior (3) incorrect" ///
			12   "(12)  Priors 1 & 2 incorrect" ///
			13   "(13)  Priors 1 & 3 incorrect" ///
			23   "(23)  Priors 2 & 3 incorrect" ///
			123  "(123) All priors incorrect"   /// 
					, replace 
			
		* label values of the re-scaled var 
		label val  incorr_priors Lbl_incorr_priors   
		
		drop temp_incorr_priors
		
		tab incorr_priors
		 // * too few obs in some groups (especially since prior 1 correct for 95%)
		 
	gen temp_incorr_priors_4g = d_incorr_prior_2_mild_moder * 10 + d_incorr_prior_3_gpa 
	
		* Assign the value labels to the variable  // Note: the values are the same as above (options >100 are just missing)
		label val temp_incorr_priors_4g Lbl_tmp_prior_group   

		* Generate a new variable to store the simplified values
		gen incorr_priors_4g = .
			replace incorr_priors_4g = 0 	if temp_incorr_priors_4g == 0
			replace incorr_priors_4g = 3 	if temp_incorr_priors_4g == 1
			replace incorr_priors_4g = 2 	if temp_incorr_priors_4g == 10
			replace incorr_priors_4g = 23 	if temp_incorr_priors_4g == 11
			
		* define the new value label
		label define Lbl_incorr_priors_4g ///
			0    "(0)   Both correct" ///
			2    "(2)   Only Mild/Moder prior incorrect" ///
			3    "(3)   Only GPA-MH prior incorrect" ///
			23   "(23)  Both Priors incorrect" ///
					, replace 
			
		* label values of the re-scaled var 
		label val  incorr_priors_4g  Lbl_incorr_priors_4g  
		
		drop temp_incorr_priors_4g
		
// 		* explore the resulting groups 
// 		tab incorr_priors_4g
// 		 // * too few obs in some groups (especially since prior 1 correct for 95%)
		
		
	gen incorr_priors_2_3_both = (d_incorr_prior_2_mild_moder == 1 & d_incorr_prior_3_gpa == 1)

		
		gen incorr_priors_2_3_either = (d_incorr_prior_2_mild_moder == 1 | d_incorr_prior_3_gpa == 1)

		gen incorr_22studies = (guess_22_studies != 22)
		
	
	* extra new vars below 	
	
		gen less_support = ( strpos(support_amount, "Less") > 0)
		
			tab support_amount  less_support  
	
		gen gap_treatment = .
		
			replace gap_treatment = 0  if distress & therapy_use_12m == 1
			replace gap_treatment = 1  if distress & therapy_use_12m == 0
			
			label var gap_treatment  "Treatment gap (1 = a student in distress + no therapy)" 
	
	
	***********************************************************
	***********************************************************
		
		
	* extra labeling / cleaning
	
	label var treat_any  "Treatment (any)"
	
	
	label var therapy_use_12m 	"Used therapy 12m"
		label values therapy_use_12m 	
		
		
	sum therapy_use_12m  , 

		local correct_mean = round(r(mean)*100,0.1)
			
		gen overest_therapy_use = (guess_therapy_use >= `correct_mean' )
	
			
// 			eststo y1: 			reg  wtp_therapy_pct_self  i.treat_any##i.distress##i.therapy_use_12m , r  
	
		gen 	gr_distress_therapy =  0 	if distress == 0  &  therapy_use_12m == 0
		replace gr_distress_therapy =  1 	if distress == 0  &  therapy_use_12m == 1
		replace gr_distress_therapy = 10 	if distress == 1  &  therapy_use_12m == 0
		replace gr_distress_therapy = 11 	if distress == 1  &  therapy_use_12m == 1
	
	
		
			label define  Lbl_distress      0  "No Distress"  	///  
											1  "In Distress" 	,  replace  
					
					numlabel Lbl_distress , add  mask("(#) ")
					
					label val distress  Lbl_distress

		
		label define Lbl_therapy_12m   		1 "Used Prof Help"   0 "No Prof Help" , replace 
			
			label values therapy_use_12m   Lbl_therapy_12m
	
	
			label define  Lbl_distress_therapy       0  "No Distress + No Prof Help"  	///  
													 1  "No Distress + Use Prof Help" 	///
													10     "Distress + No Prof Help"  		///
													11     "Distress + Use Prof Help"    	///  	
												   	, replace
		
			label val gr_distress_therapy  Lbl_distress_therapy
		
	
	
	* tab people who haven't updated prior 3 
	gen posterior3_no_update = (t1_info_c == "worse" | t2_info_c == "worse" )
		
		replace posterior3_no_update = 99 if treat_any == 0
	
		tab posterior3_no_update , m
	
	
	gen support_emot_help_disagree  =  (campus_support_prof_help_emot >= 4)
	
		
	* process the var "Study about" -- asking participants to anticipate what the study was about
	replace study_about = lower(study_about)
	
		gen about_mh = (strpos(study_about, "salud mental") > 0 ) | (strpos(study_about, "mental health") > 0 )
	
		gen about_therapy = (strpos(study_about, "terap") > 0 ) | (strpos(study_about, "therap") > 0 )


	gen d_incorr_priors_2_3_both = (d_incorr_prior_2_mild_moder == 1 | d_incorr_prior_3_gpa == 1 )

	gen correct_22_studies 		= 22
	
	gen correct_22_studies_pct 	= 1

	
	/*  Get the guess vars as shares  */ 
	
	gen guess_22_studies_pct = guess_22_studies / 22
	
	* convert guesses out of 100 to a share (percentage)
	foreach var of varlist  guess_therapy_use guess_self_stigma  guess_open_to_share  {
		* get the avg guess by 
		gen  `var'_pct  =  `var' / 100
		}
		
		gen low_guess_22_studies = ( guess_22_studies <= 18 )
	
	
	*********************************************************
	*   Prep further advice + clicks outcomes 
	*********************************************************
	
	
// 	* standadrdize the num of characters in advice 
// 	egen advice_char_count_z = std(advice_char_count)
//	
	* replace advice text w all lower case 
	replace advice = lower(advice)
	
	/* Remove accents from advice wording */
	replace advice = subinstr(advice, "á", "a", .)
	replace advice = subinstr(advice, "é", "e", .)
	replace advice = subinstr(advice, "í", "i", .)
	replace advice = subinstr(advice, "ó", "o", .)
	replace advice = subinstr(advice, "ú", "u", .)

		* Roberto's measures 
	gen adv_therapy_v1 = (strpos(advice, "terapia") > 0 | strpos(advice, "psicolog") > 0)
	
// 	gen adv_d_dostuff_liked = (strpos(advice, "hacer algo") > 0 & strpos(advice, "disfrut") > 0)
// 	gen adv_d_wellbeing 	= (strpos(advice, "rutina de bienestar") > 0 | strpos(advice, "hacen sentir mejor") > 0)
// 	gen adv_d_meditate 		= (strpos(advice, "medita") > 0)
//
// 		gen adv_active_count = (adv_d_dostuff_liked + adv_d_wellbeing + adv_d_meditate)
// 		gen adv_active_share = (adv_active_count / 3)
//
// 		quietly sum adv_active_share, detail
// 		gen adv_active_share_std = (adv_active_share - r(mean)) / r(sd)

	gen adv_self_care   = 	(strpos(advice, "hacer algo") > 0 & strpos(advice, "disfrut") > 0)  |  (strpos(advice, "bienestar") > 0 ) |  ( strpos(advice, "hacen sentir mejor") > 0)   |   ///
							(strpos(advice, "medita") > 0)  |  (strpos(advice, "respira") > 0)  |  ( strpos(advice, "superar") > 0  &  strpos(advice, "estres") > 0 )  |   ///
							(strpos(advice, "tiempo para ti") > 0  )  |  ( strpos(advice, "ejerci") > 0 ) |  ( strpos(advice, "superar") > 0 )  |  ( strpos(advice, "ambiente sano") > 0 ) |    ///
							(strpos(advice, "organizar un plan") > 0 ) |  (  strpos(advice, "lidiar con") > 0  ) 
	
	
	gen adv_prof_help_any  	=   (strpos(advice, "terapia") > 0 ) 	 	| (strpos(advice, "psicologo") > 0) 	|  (strpos(advice, "psicologa") > 0) 	| (strpos(advice, "servicios") > 0 )  |  ///
								(strpos(advice, "profesional") > 0) 	| (strpos(advice, "consejeria") > 0 )  	|  ///
								(strpos(advice, "counseling") > 0 )  	| (strpos(advice, "counselling") > 0 )  | (strpos(advice, "therapy") > 0 )  	| (strpos(advice, "psychologist") > 0 ) | ///
								(strpos(advice, "professional") > 0) 	| (strpos(advice, "services") > 0 )     | (strpos(advice, "systemas de apoyo") > 0 )   |  ///
								(strpos(advice, "referirlo a apoyo emocional") > 0 ) |  (strpos(advice, "opciones de centros") > 0 )  |  ///
								(strpos(advice, "sesiones de ayuda") > 0 )  |  (strpos(advice, "programas de ayuda") > 0 )

	
// 	gen adv_prof_help_count = 	(strpos(advice, "terapia") > 0 ) 	 + (strpos(advice, "psicologo") > 0	) 		+  (strpos(advice, "psicologa") > 0) 	+   (strpos(advice, "profesional") > 0 ) +  ///
// 								(strpos(advice, "consejeria") > 0 )  + (strpos(advice, "servicios") > 0 )       +  ///
// 								(strpos(advice, "counsel") > 0 )     + (strpos(advice, "counselling") > 0 )  	+  (strpos(advice, "counselor") > 0 )  	+  ///
// 								(strpos(advice, "therapy") > 0 )  	 + (strpos(advice, "psychologist") > 0 )  	+  (strpos(advice, "professional") > 0) +  (strpos(advice, "services") > 0 )  

// 	egen test = noccur(advice), string("consejer")
	
	* identify the refences for campus-focused mentions 
	gen adv_campus  	   =   (strpos(advice, "campus") > 0  | strpos(advice, "tec") > 0) | (strpos(advice, "uni") > 0 ) | (strpos(advice, "colegio") > 0 )  | (strpos(advice, "college") > 0 ) 
	
	gen test2 =    (strpos(advice, "campus") > 0  | strpos(advice, "tec") > 0) | (strpos(advice, "uni") > 0 ) | (strpos(advice, "colegio") > 0 )  | (strpos(advice, "college") > 0 ) 
	
	
	* get the prof help mentions w campus specifically 
	gen  adv_campus_prof_help = adv_campus * adv_prof_help_any
	
		label var adv_campus_prof_help  "Advice mentions on-campus therapy"
	
	gen N_treatm_group = .
	
		quiet  sum student_id 			if treatm_group ==  1
		replace N_treatm_group = r(N)  	if treatm_group ==  1
	
		quiet  sum student_id 				if treatm_group ==  2
		replace N_treatm_group = r(N)  	if treatm_group ==  2

		quiet  sum student_id 				if treatm_group ==  0
		replace N_treatm_group = r(N)  	if treatm_group ==  0
	
	
	
	/*********************** */
	/* Add the clicks values */ 
	/*********************** */
	
	* T1: 44 clicks  // 35 unique 
	* T2: 92 clicks  // 59 unique 
	* C:  35 clicks  // 24 control 
	
	* get the click rate vars 	
	gen clicks_all = .
		
		replace clicks_all = 44  /  N_treatm_group  if treatm_group ==  1
		replace clicks_all = 92  /  N_treatm_group  if treatm_group ==  2
		replace clicks_all = 35  /  N_treatm_group  if treatm_group ==  0
	
	
	gen clicks_unique = .
		
		replace clicks_unique = 35 /  N_treatm_group  if treatm_group ==  1
		replace clicks_unique = 59 /  N_treatm_group  if treatm_group ==  2
		replace clicks_unique = 24 /  N_treatm_group  if treatm_group ==  0
		
		
				
	***********************************************************			
	***********************************************************	 
	
	
// 	gen long_advice = advice_char_count > 300
	
	
		gen gpa_of_10 = gpa_1 / 10
		
			sum gpa_1 , d
			
				gen gpa_under_p25  = gpa_1 <  r(p50) 
				gen gpa_p25_less   = gpa_1 <= r(p50) 
				
				gen gpa_p50_plus  = gpa_1 >= r(p50) 
				gen gpa_above_p50 = gpa_1 >  r(p50) 

				gen gpa_p75_plus  = gpa_1 >= r(p75) 
				gen gpa_above_p75 = gpa_1 >  r(p75)
				
			* get quantile identifiers 
			xtile gpa_4q = gpa_1, nq(4)
		
			xtile gpa_5q = gpa_1, nq(5)
		
			xtile gpa_8q = gpa_1, nq(8)
		
			xtile gpa_10q = gpa_1, nq(10)
		
				
		gen fin_cat  = real(substr(financial_stress, 1, 1))
		
		
		* perceived effectiveness 
		gen therapy_good_self_disagree = ( therapy_good_self >= 4 )
		gen therapy_good_general_disagree = ( therapy_good_general  >= 4 )
		
			label var  therapy_good_self_disagree  		"Disagree that going to therapy can improve MY OWN mental wellbeing"
			label var  therapy_good_general_disagree  	"Disagree that going to therapy can improve people's mental wellbeing in GENERAL"
		
		gen therapy_good_self_yes 		= ( therapy_good_self 		< 4 )
		gen therapy_good_general_yes 	= ( therapy_good_general  	< 4 )
		
			label var  therapy_good_self_yes  		"Disagree that going to therapy can improve MY OWN mental wellbeing"
			label var  therapy_good_general_yes  	"Disagree that going to therapy can improve people's mental wellbeing in GENERAL"
		
		
		* perceived support 
		gen therapy_support_by_friends_no = ( therapy_support_by_friends >= 4 )
		gen therapy_support_by_parents_no = ( therapy_support_by_parents >= 4 )
		
			label var  therapy_support_by_friends_no	"Disagree: My friends would support if I am going to therapy"
			label var  therapy_support_by_parents_no  	"Disagree: My parents would support if I am going to therapy"
		
		
		gen therapy_support_by_friends_yes = ( therapy_support_by_friends < 4 )
		gen therapy_support_by_parents_yes = ( therapy_support_by_parents < 4 )
		
			label var  therapy_support_by_friends_yes	"Agree: My friends would support if I am going to therapy"
			label var  therapy_support_by_parents_yes 	"Agree: My parents would support if I am going to therapy"
		
		  

	******************************************************************
	******************************************************************
	
// 		* clean up other vars 
// 		label var advice_mention_prof_help  "Mentioned Therapy as Advice"
	
		
		isid uniqueid 
		
		sort uniqueid 
			
		compress 	
		
		label data "MH survey data by student 2024-11 (w extra vars)"
		

		save "${clean}/mh_survey_analysis.dta" , replace 


	
	
	***********************************************************
	***********************************************************
	