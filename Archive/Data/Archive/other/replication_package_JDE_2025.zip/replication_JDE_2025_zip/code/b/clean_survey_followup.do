
/*

// global date_stamp 		"_2025_04_22_1pm"

// global survey_followup 	"${project}/survey_follow_up_2025_04" 

*/

	cap mkdir "${raw}/followup_2025_05" 
	cap mkdir "${processed}/followup_2025_05" 
	cap mkdir "${figures}/followup_2025_05"


	* import google form responses 
	import excel "${raw}/followup_2025_05/survey_followup_6m${date_stamp}.xlsx" ,  sheet("Sheet1") firstrow case(lower) clear
		
// 		* get a numeric timestamp 
// 		gen 		timestamp_num = timestamp
// 			format 	timestamp_num  	%15.0g
		
		* clean up varnames 
		rename hastomadoclaseseneltecen2  	took_classes_2025
		
		rename heutilizadoserviciosprofes 	used_mh_on_campus
		rename f 					 		used_mh_off_campus
		
		rename herecomendadolosservicios 	recommend_mh_on_campus
		rename herecomendadoserviciosprof 	recommend_mh_off_campus
		
		rename hehabladosobremisproblema 	discuss_own_mh_probl
		rename hehabladosobremiexperienc 	discuss_own_oth_therapy
		
		rename situvierasalgúnproblema 		would_use_on_campus
		rename l 					 		would_use_off_campus

		
		* remove the varlabels from the raw file 
		drop in 1
		
		* reduce the strings in vars 
		compress

		
		* convert to binary vars 
		foreach var in   					took_classes_2025  		 ///
				 used_mh_on_campus 			used_mh_off_campus 		 ///
				 recommend_mh_on_campus   	recommend_mh_off_campus  ///
				 discuss_own_mh_probl 	 	discuss_own_oth_therapy  ///
				 would_use_on_campus   		would_use_off_campus     {

			replace `var' = "1" if `var' == "Sí"
			replace `var' = "0" if `var' == "No"
			destring `var', replace force		
			
			* end of varlist 
			}			
		
	
		* get additional binary vars to identify the follow-up in the merged sample 
		
		* test attrition
		gen attrite = 1
		
		* get a response confirmation indicator 
		gen responded = 1
		
// 		* get a numeric timestamp 
// 		gen 		timestamp_num = timestamp
// 			format 	timestamp_num  	%15.0g
		
			* explore attrition 
			bysort treat_any: sum responded
			bysort treatment: sum responded		
		
	
		* get the sample size
		sum treat_any  if responded == 1 & took_classes_2025 == 1 
			global followup_sample = r(N)
			di "${followup_sample}"
	
			tab treatment responded , row
			
	
		/*   Prep for saving   */
			
		compress
		isid uniqueid 
			
		save "${clean}/survey_followup_6m.dta", replace 
		
		
	
	