
/*

* This file merges and cleans the follow-up survey to the participant roster 

*/


 
do "${code}/b/process_followup_responses.do"

cap mkdir "${figures}/survey_followup/"

* pull the file with the email list of participants identified as valid responses for follow up 
use "${processed}/mh_survey_uniqueid_email_treat_for_followup.dta", replace 

	// NOTE: the file above was created on Google Drive from "${clean}/mh_survey_uniqueid_email_treat.dta"
	// 		 by adding the names of Alisher/Ida to send initial email invites 
	//  	 (the addition of the name is not replicated using STATA code)

	rename name sender_name 

	replace email = lower(email)
	
	drop if email  == ""
	
	
	* fix leading zeros 
	replace email = "a01285012@tex.mx" if  email == "a1285012@tec.mx"
	replace email = "a00833393@tec.mx" if  email == "a000833393@tec.mx"
	
	* fix apparent typos
	replace email = "a00840798@tex.mx" if  email == "a00840798@tex.mc"
	
	replace email = "a00843064@tec.mx" if  email == "a00843064@tec.mz"
	replace email = "a01178778@tec.mx" if  email == "a01178778@tec.mc"
	
	
	
	* merge in the response emails 
	merge 1:1 email using "${processed}/followup_2025_05/response_emails${date_stamp}.dta" , keep(master match)

	* get an indicator for invalid emails 
	gen invalid_email = 0
		
		* fix Ida's non-delivery emails 
		replace invalid_email = 1 if email == "a000833393@tec.mx"   	// attempted to fix: removing a leading zero
		replace invalid_email = 1 if email == "a1285012@tec.mx"  		// attempted to fix:   adding a leading zero
	
		replace invalid_email = 1 if email == "a00840798@tec.mx"	
		replace invalid_email = 1 if email == "a01620933@tec.mx"
		replace invalid_email = 1 if email == "a01731473@tec.mx"
		replace invalid_email = 1 if email == "a00830126@tec.mx"
		replace invalid_email = 1 if email == "a01660134@tec.mx"	
		
		* fix Alisher's non-delivery emails 
		replace invalid_email = 1 if email == "a01235932@tec.mx"
		replace invalid_email = 1 if email == "a00843193@tex.mx"
		replace invalid_email = 1 if email == "a01781085@tec.mx"
		replace invalid_email = 1 if email == "a00739721@tec.mx"
		replace invalid_email = 1 if email == "a0082169@tec.mx"
		
		replace invalid_email = 1 if email == "a00830691@tec.mx"
		replace invalid_email = 1 if email == "a0842135@tec.mx"
		replace invalid_email = 1 if email == "a00835880@tec.mx"
		replace invalid_email = 1 if email == "a01247267@tec.mx"
		
		
	* clean up varnames 
	rename hastomadoclas~2  	took_classes_2025
	
	rename respondesobre~n 		used_mh_on_campus
	rename f 					used_mh_off_campus
	
	rename g 					recommend_mh_on_campus
	rename h 					recommend_mh_off_campus
	
	rename i 					discuss_own_mh_probl
	rename j 					discuss_own_oth_therapy
	
	rename respondesobre~p 		would_use_on_campus
	rename l 					would_use_off_campus

	
	* convert to binary vars 
	foreach var in took_classes_2025 ///
             used_mh_on_campus 			used_mh_off_campus ///
             recommend_mh_on_campus   	recommend_mh_off_campus ///
             discuss_own_mh_probl 	 	discuss_own_oth_therapy ///
             would_use_on_campus   		would_use_off_campus {

		replace `var' = "1" if `var' == "Sí"
		replace `var' = "0" if `var' == "No"
		destring `var', replace force		
		
		* end of varlist 
		}			
		
	* get cleaner treated vars 
	
	gen treatment = real(substr(treatm_group, 2, 1))
	
	gen treat_any = (treatment >= 1)
	
		replace treat_any = . if treatment == .
	
	* check attrition 	
	tab treatment  _merge , row
	tab treat_any  _merge , row

	* get a response confirmation indicator 
	gen responded = (_merge == 3)
	
		* explore attrition 
		bysort treat_any: sum responded
		bysort treatment: sum responded
	
		* get the sample size
		sum treat_any  if responded == 1 & took_classes_2025 == 1 
			global sample = r(N)
			di "$sample"
	
		
		tab treatment responded , row
		
	* test attrition
	gen attrite = (_merge == 1)
	
		tab attrite  _merge

	* get a numeric timestamp 
	gen 		timestamp_num = timestamp
			format 	timestamp_num  %15.0g

			
		* prep for saving 
		drop _merge 
		isid email 
		
		compress 
	
		
		order  uniqueid treatment  treat_any  email  responded  invalid_email  sender_name 
		
		
		save "${processed}/survey_followup_outcomes.dta" , replace 
		
		
		* export excel with emails based on merge 
		export excel uniqueid treatment  treat_any  email  responded  invalid_email  sender_name  ///
						using  "${processed}/followup_2025_05/email_list_post${date_stamp}.xlsx", firstrow(variables) replace
		
		
		
	/* ************************************** */
	/*    Export email lists for resending    */
	/* ************************************** */	
				
	* store the email lists only 
	use  "${processed}/survey_followup_outcomes.dta" , replace 
				
		keep  uniqueid treatment  treat_any  email  responded  invalid_email  sender_name 
		
		save "${processed}/followup_2025_05/email_list_post_all${date_stamp}.dta" , replace 
	
	
	* store the email lists only 
	use "${processed}/followup_2025_05/email_list_post_all${date_stamp}.dta" , replace 
	
		* keep valid + unresponded emails 
		keep if  invalid_email == 0  &  responded == 0 
		
		save  "${processed}/followup_2025_05/email_list_unresponded.dta" , replace 
		
		export excel  using  "${processed}/followup_2025_05/email_list_unresponded.xlsx", firstrow(variables) replace
		
		
//
// 	preserve 
//	
// 		* story only valid & not-responded emails 
// 		keep if treatment == 1 & invalid_email == 0 & responded == 0
//		
//		
// 		* export excel with emails based on merge 
// 		export excel uniqueid treatment  treat_any  email  responded  invalid_email  sender_name  ///
// 						using  "${processed}/followup_2025_05/email_list_post_valid_T1${date_stamp}.xlsx", firstrow(variables) replace
//		
// 		restore 
//		
// 	preserve 
//	
// 		* story only valid & not-responded emails 
// 		keep if treatment == 2 & invalid_email == 0 & responded == 0
//		
//		
// 		* export excel with emails based on merge 
// 		export excel uniqueid treatment  treat_any  email  responded  invalid_email  sender_name  ///
// 						using  "${processed}/followup_2025_05/email_list_post_valid_T2${date_stamp}.xlsx", firstrow(variables) replace
//		
// 		restore 
//	
//
//	
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		