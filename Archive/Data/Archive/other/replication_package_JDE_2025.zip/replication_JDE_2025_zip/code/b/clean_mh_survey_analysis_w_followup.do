
//
// /* ************************************** */
// /*   Correct Emails w Apparent Mistakes   */
// /* ************************************** */
//
// 	// * this didn't end up being useful yet -- no need to fix the emails 
//
// * correct the list of emails to remove typos 
// use "${processed}/mh_survey_uniqueid_email_treat_for_followup.dta" ,  replace 
//
// 	* convert all to lower case (if not done yet)
// 	replace email = lower(email)
//
// 	* fix leading zeros 
// 	replace email = "a01285012@tex.mx" if  email == "a1285012@tec.mx"
// 	replace email = "a00833393@tec.mx" if  email == "a000833393@tec.mx"
//	
// 	* fix apparent typos
// 	replace email = "a00840798@tex.mx" if  email == "a00840798@tex.mc"
//	
// 	replace email = "a00843064@tec.mx" if  email == "a00843064@tec.mz"
// 	replace email = "a01178778@tec.mx" if  email == "a01178778@tec.mc"
//	
//	
// 	* correct the list of emails to remove typos 
// 	save "${processed}/mh_survey_uniqueid_email_followup_corrected.dta" ,  replace 
//


	/* ************************************** */
	/*    Merge FollowUp Data on Unique ID    */
	/* ************************************** */

		
	* pull the main analysis dataset 
	use  "${clean}/mh_survey_analysis.dta" , replace 

		* merge in follow up data 
		merge m:1  uniqueid  using   "${clean}/survey_followup_6m.dta" ,  keepusing(uniqueid  treatment responded  attrite   took*  *use*  *recommend*  *discuss*  )
		
		
			* explore the sum stats to compare follow-up vs full sample 
			
			* check attrition 	
			tab treatment  _merge , row
			tab treat_any  _merge , row

		
			rename responded  responded_followup 
			rename attrite    attrite_followup
		
			replace responded = 0   if  responded == .
			replace attrite   = 1   if  responded == .
		
		
		/*  Extra vars  */

		* winsorize GPA at p1, p99
		winsor gpa_1	, gen(gpa_wins_p1) p(0.01) 
		
			label var  gpa_1    	"Overall GPA"
			label var  gpa_wins_p1  "Overall GPA (winsorized p1, p99)"
			

		* get separate scores for depression / anxiety 
		gen score_depression = phq4_gad4_1_num + phq4_gad4_2_num + phq4_gad4_3_num  + phq4_gad4_4_num 
		
			gen depression = ( score_depression >= 6)

				label var score_depression  	"Depression score (of 12)"
				label var depression    		"Depression (dummy)"
			
		gen score_anxiety =  phq4_gad4_5_num + phq4_gad4_6_num + phq4_gad4_7_num  + phq4_gad4_8_num  
		
			gen anxiety = ( score_anxiety >= 6)
			
				label var score_anxiety  		"Anxiety score (of 12)"
				label var anxiety    		 	"Anxiety (dummy)"

			tab depression 
			tab depression  therapy_use_12m , row 
			
			tab anxiety  	
			tab anxiety  	therapy_use_12m , row 
		
			tab depression anxiety , cell 

			
		/*  Get correct/incorrect posteriors */ 
		
		tab1 d_incorr_prior_1_effective d_incorr_prior_2_mild_moder d_incorr_prior_3_gpa
		
		des  t1_info_a t1_info_b t1_info_c t2_info_a t2_info_b t2_info_c
		
			tab1 t1_info_a t2_info_a
			tab1 t1_info_b t2_info_b
			tab1 t1_info_c t2_info_c
		
			* get the incorrect posterior % for treated subjects (posteriors only estimated for treated subjects, so replace with missing if not treated)
			
			* posterior 1
			gen d_incorr_post_1_effective = (t1_info_a  == 0  | t2_info_a  == 0 )
			
				replace d_incorr_post_1_effective = .  if treat_any == 0
				
				tab d_incorr_prior_1_effective  if treat_any == 0
				tab d_incorr_post_1_effective
			
			* posterior 2
			gen d_incorr_post_2_mild_moder = (t1_info_b  == 0  | t2_info_b  == 0 )
			
				replace d_incorr_post_2_mild_moder = .  if treat_any == 0
				
				tab d_incorr_prior_2_mild_moder if treat_any == 0
				tab d_incorr_post_2_mild_moder 
				
			* posterior 3
			gen d_incorr_post_3_gpa  		= (t1_info_c  == "worse"  | t2_info_c  == "worse" )
			
				replace d_incorr_post_3_gpa = .  if treat_any == 0
				
				tab d_incorr_prior_3_gpa  if treat_any == 0
				tab d_incorr_post_3_gpa 
				
				
			sum  d_incorr_prior_1_effective   	d_incorr_post_1_effective    if treat_any == 1
			
			sum  d_incorr_prior_2_mild_moder   	d_incorr_post_2_mild_moder   if treat_any == 1
			
			sum  d_incorr_prior_3_gpa  			d_incorr_post_3_gpa   		 if treat_any == 1
			
			
		* extra vars 
		
		gen in_sample = (responded == 1 & took_classes_2025 == 1)
		
			label var in_sample  "Respondent w followup data & took classes"
	
		
		gen followup_therapy_use 		=  ( used_mh_off_campus  == 1  		|  used_mh_on_campus  == 1 )
	
			replace followup_therapy_use = . if responded == 0
	
		
		gen followup_recommend_therapy 	=  ( recommend_mh_off_campus  == 1  |  recommend_mh_on_campus  == 1 )
	
			replace followup_recommend_therapy = . if responded == 0
	
		gen followup_discuss_mh 		=  ( discuss_own_mh_probl  == 1  	|  discuss_own_oth_therapy == 1 )
	
			replace followup_discuss_mh = . if responded == 0
	
		
			
		* prep for saving 
		isid uniqueid 
		sort uniqueid  
		
		compress 
		
		
		save "${clean}/mh_survey_analysis_w_followup.dta" , replace 


		
		
	