
/* ----------------------------------------------------------------------------
			Replication file for 'Beliefs, Information Sharing, 
			and Mental Health Care Use Among University Students'
			
	Authors: Alisher Batmanov, Idaliya Grigoryeva, Bruno Calderon-Hernandez,
	Roberto Gonzalez-Tellez, Alejandro Guardiola-Ramirez
	
	objective: this do file runs do files in order such that raw data is taken
	as input, cleaned, and then figures and tables in the paper are done.
---------------------------------------------------------------------------- */

/* The do files require the following user written packages for running; if
you do not have them installed, uncomment the following lines to install them */
// ssc install texsave, replace
// ssc install grqreg, replace
// ssc install winsor, replace
// ssc install ietoolkit, replace
// ssc install gtools, replace
 
// ssc install pdslasso
*! pdslasso 1.0.03 04sept2018s
*! pdslasso package 1.3 29july2020
*! authors aa/cbh/ms
/* if the tables_B13_B14.do fails, it is likely due to updates on the commands used to run the analyis. 
	If that happens, run ${code}/b/define_ivlasso_rlasso_pdslasso.do to define the commands 
	as they were defined at the time when we ran the analysis. */

clear all   

/* set the main research folder directory (the one where the project folder lives) - #### UPDATE THIS LINE */
/* directory for YOUR NAME: (put the following in STATA command window:  di "`c(username)'") */
/* directory for Alisher: (put the following in STATA command window:  di "`c(username)'") */
if "`c(username)'" == "author"  {
	global area     "/Users/.../replication_folder"   
	}


display in yellow "This is the current global directory: ${area}"

/* set the project directory */
global project    	"${area}/replication_JDE_2025"
global proj_git    	"${project}"
global proj_shared  "${project}"

global code    	"${project}/code"

/* ************************************ */
/* 		  Set up project settings   	*/
/* ************************************ */

do "${code}/config.do"



/* ************************************ */
/* 		Clean the raw survey data   	*/
/* ************************************ */


* clean the raw Qualtrics data (recording vars + labels) 
do "${code}/b/process_mh_survey_analysis.do"


* process advice text w analysis vars  
do "${code}/b/process_advice_for_further_analysis.do"

* process stigma-related measures to construct an index
do "${code}/b/process_stigma_index.do"

* merge in extra processed vars + get new vars 
do "${code}/b/clean_mh_survey_analysis.do"


/* ************************************************ */
/*  Process the 6-month follow-up survey responses  */
/* ************************************************ */

	* set the data for final export of followup survey data
	global date_stamp "_2025_05_all"


	* process the follow-up form responses 
	do "${code}/b/clean_survey_followup.do"


	* merge the follow up responses to the main analysis file 
	do "${code}/b/clean_mh_survey_analysis_w_followup.do"


	
/* ************************************ */
/* 		Analysis: figures & tables     	*/
/* ************************************ */


* Figures

do "${code}/a/Figure_1.do"

do "${code}/a/Figure_2.do"

do "${code}/a/Figure_3.do"

do "${code}/a/Figure_4.do"

do "${code}/a/Figure_5.do"

do "${code}/a/Figure_6.do"

do "${code}/a/Figure_7.do"

do "${code}/a/Figure_8.do"

do "${code}/a/Figure_9.do"

do "${code}/a/Figure_10.do"

do "${code}/a/Figure_11.do"

do "${code}/a/Figure_12.do"

do "${code}/a/Figure_13.do"


* Tables

do "${code}/a/Table_1.do"

do "${code}/a/Table_2.do"

do "${code}/a/Table_3.do"

do "${code}/a/Table_4.do"

do "${code}/a/Table_5.do"

do "${code}/a/Table_6.do"

do "${code}/a/Table_7.do"

do "${code}/a/Table_8.do"

do "${code}/a/Table_9.do"

do "${code}/a/Table_10.do"



	
/* ************************************ */
/*     Appendix: Additional Analysis    */
/* ************************************ */


/* Appendix figures and tables exclduing power calculations and randomization inference */
do "${code}/a/Appendix_figures_tables_codes.do"


/* Additional Figures/Tables */

/* Figure B2 */
do "${code}/a/Figure_B2_Appendix.do"

/* Tables B13-B14 */
do "${code}/a/Tables_B13_B14.do"

/* Power calculations (the master file running several other do files) */
do "${code}/a/power_calcs/master_powercalc.do"

/* Randomization inference */
do "${code}/a/randomization_inference.do"


















