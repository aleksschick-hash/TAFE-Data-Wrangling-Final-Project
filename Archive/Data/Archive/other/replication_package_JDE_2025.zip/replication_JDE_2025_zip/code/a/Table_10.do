/* ----------------------------------------------------------------------------
	code author: roberto gonzalez
	
	Table 10: Effects on Personal & Public Stigma-Related Outcomes
---------------------------------------------------------------------------- */

/* Read in survey dataset */
use "${clean}/mh_survey_analysis_w_followup.dta" , replace 

/* define outcome list */
local outcome_list "pref_mh_symp_v_low_gpa pref_mh_talk_v_low_gpa discuss_own_mh_probl discuss_own_oth_therapy followup_discuss_mh"

/* define treatment variable */
local treatvar "treat_any"

/* clear estimates */
estimates clear

/* initialize regression counter */
local mmm = 0
/* loop over outcomes to estimate regressions */
foreach outcome in `outcome_list' {
	/* add one to regression counter */
	local ++mmm
	/* define populations */
	if inlist(`mmm', 1, 2) {
		local population "1==1" 
	}
	else {
		local population "in_sample == 1"
	}
	/* estimate regression */
	eststo : regress `outcome' `treatvar' if `population', robust
	/* get outcome mean and sd */
	quietly summarize `outcome' if e(sample) & `treatvar' == 0
	estadd scalar ymean = r(mean)
	estadd scalar ysd = r(sd)
}

/* export regression table */
esttab _all using "${tables}/table_10.tex", replace booktabs b(3) se(3) nogaps ///
	nonotes keep(`treatvar') coeflabel(`treatvar' "Treated") stats(ymean ysd N, ///
		labels("Control Mean" "Control SD" "Observations") fmt(3 2 0)) ///
	mtitles("Distress Sympt" "MH Talk" "Own MH Issues" "Therapy" ///
		"Any MH") star(* 0.1 ** 0.05 *** 0.01) 
	