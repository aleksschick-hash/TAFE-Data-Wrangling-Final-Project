/* ============================================================================
   File: Table_B3.do

   Purpose:
       Produce Table B3:
           Summary of incorrect prior and incorrect posterior beliefs
           among treated participants.

   Output:
       Console summary statistics.

   Requirements:
       - variables t1_info_a, t1_info_b, t1_info_c
                     t2_info_a, t2_info_b, t2_info_c
         must exist in the dataset.
   ============================================================================ */

use "${clean}/mh_survey_analysis.dta", replace

* Recreate the incorrect-posterior indicators exactly as in the master file
gen d_incorr_poster_1 = (t1_info_a == 0 | t2_info_a == 0)
gen d_incorr_poster_2 = (t1_info_b == 0 | t2_info_b == 0)
gen d_incorr_poster_3 = (t1_info_c == "worse" | t2_info_c == "worse")

* Table B3 summary
summarize d_incorr_prior_1_effective ///
          d_incorr_prior_2_mild_moder ///
          d_incorr_prior_3_gpa ///
          d_incorr_poster_1 ///
          d_incorr_poster_2 ///
          d_incorr_poster_3 ///
          if treat_any == 1

exit
