/* ============================================================================
   File: Table_6.do

   Purpose:
       Produce Table 6 exactly as in the master do-file.
   ============================================================================ */

use "${clean}/mh_survey_analysis.dta", replace

preserve  

    label var guess_22_studies              "Guess \# studies $\downarrow$ depression (correct 22)"
    
    label var therapy_good_self_yes         "Agree: Therapy can improve my own well-being"
    label var therapy_good_general_yes      "Agree: Therapy can improve people's own well-being"
    
    label var therapy_support_by_friends_yes  "Agree: Friends would support me going to therapy"
    label var therapy_support_by_parents_yes  "Agree: Parents would support me going to therapy "
    
    
    label var prof_help_ever                "Have ever received professional MH help"
    label var prof_help_friend_ever         "Have a friend who received professional MH help"
    label var prof_help_friend_benefit      "Have a friend who would benefit from therapy"
    
    label var therapy_use_12m               "Sought professional mental health help (last 12 months)"        
    label var whom_help_prof_help_campus    "$\rightarrow$ professional MH help \textbf{at the university}"
    label var whom_help_prof_help_outside   "$\rightarrow$ professional MH help \textbf{outside university}"
    label var unlikely_seek_help            "Unlikely to seek help when struggling with mental health issues"
    
    
    global prof_help_vars "guess_22_studies therapy_good_self_yes  therapy_good_general_yes  therapy_support_by_friends_yes  therapy_support_by_parents_yes      therapy_use_12m  whom_help_prof_help_campus  whom_help_prof_help_outside   prof_help_ever   unlikely_seek_help   prof_help_friend_ever     prof_help_friend_benefit   "
    
    iebaltab ${prof_help_vars} , groupvar(distress)  ///
         order(0 1) control(0)  grpcodes  grplabels(0 "Not in Distress" @ 1 "Distress")  ///
         stats(desc(sd)  pair(diff))   format(%9.2f)  tblnonote  rowvarlabels   ///
         starlevels(0.1 0.05 0.01)     browse 
    
    drop v2 v4 v6 
    
    texsave * using "${tables}/means_prof_help_w_effectiv_by_distress.tex", title("Perceived Effectiveness \& Help-Seeking by Distress") label("tab:effectivByDistress")  ///
                        footnote("Notes: Difference = Distress - No distress. Sample size (680): No distress = 525, Distress = 155. . ***, **, * indicate 1, 5, 10\% significance.") ///
                        /* footnote("Notes:  The sample includes all students in the experiment (students who were enrolled on the first day of class when the experiment was announced).  ${bal_extra_note}  ***, **, * indicate 1, 5, 10\% significance.") */ ///
                        size(scriptsize)  nofix  location(htbp)  ///
                        frag  nonames replace 

restore 

exit
