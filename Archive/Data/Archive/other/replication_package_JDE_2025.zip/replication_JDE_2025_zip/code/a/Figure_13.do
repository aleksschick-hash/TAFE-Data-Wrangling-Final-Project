/* ----------------------------------------------------------------------------
	mental health 
	
	code author: roberto gonzalez
	date: november 10, 2025
	
	Figure 13: TE Heterogeneity on DIscussing MH Issues by GPA
---------------------------------------------------------------------------- */	

use "${clean}/mh_survey_analysis_w_followup.dta", replace 


	label define GPA 0 "Lower GPA (<p50)" 1 "Higher GPA (>p50)"
	label values gpa_above_p50 GPA
			
	eststo discuss_prob_by_gpa : regress discuss_own_mh_probl 1.treat_any#1.gpa_above_p50 1.treat_any#0.gpa_above_p50 ///
		1.gpa_above_p50 if in_sample == 1,  robust 
	eststo discuss_ther_by_gpa : regress discuss_own_oth_therapy 1.treat_any#1.gpa_above_p50 1.treat_any#0.gpa_above_p50 ///
		1.gpa_above_p50 if in_sample == 1, robust 

	coefplot (discuss_prob_by_gpa, mcolor(ebblue%50) ciopts(lcolor(ebblue%75) lwidth(0.6))  msize(1.5)) ///
		(discuss_ther_by_gpa, mcolor(lavender%75) ciopts(lcolor(lavender%65) lwidth(0.6)) msize(1.5)), ///
		ci(90) color(%50) order(*treat_any*) keep(1.treat*) vertical ///
		yline(0 , lcolor(purple%50))  yscale( range(-0.25 0.2) )    ylabel(-0.2 (0.1) 0.2)  ///
		legend(	pos(12)  row(1)   ///
		title("Discussed:", size(medium)  span )  ///
		order(2 "Own MH Issues"  4  "Therapy"  ) )   ///
		xsize(3.5)  ysize(3)  ///
		note("90% CI.")
		
		graph export "${figures}/Figure_13.pdf", replace
		