/* ============================================================================
   File: Figure_8.do

   Purpose:
       Produce Figure 8:
           - Bar chart of stigma index, self-stigma, and perceived self-stigma
             by distress status.

   Output:
       $figures/stigma_index1_w_self_stigma_by_distress.pdf

   Requirements:
       - $clean   : folder with cleaned data
       - $figures : folder where figures will be saved
       - Dataset: "${clean}/mh_survey_analysis.dta"
         Variables needed:
             stigma_index1
             d_self_stigma
             guess_self_stigma_pct
             distress
   ============================================================================ */

use "${clean}/mh_survey_analysis.dta", replace

graph bar stigma_index1 d_self_stigma guess_self_stigma_pct, ///
    over(distress) legend(pos(6)) horizontal ///
    xsize(6) ///
    legend(label(1 "Stigma Index") ///
           label(2 "Share with Self-Stigma") ///
           label(3 "Perceived Share with Self-Stigma")) ///
    bar(1, color(gold%50)) ///
    bar(2, color(midblue%50)) ///
    bar(3, color(navy%50))

graph export "$figures/stigma_index1_w_self_stigma_by_distress.pdf", replace

exit
