


/* ============================================================================
   Figure 5 (Main Text)
============================================================================ */

use "${clean}/mh_survey_analysis_w_followup.dta", replace 

	* create vars to identify incorrect posteriors 
	gen d_incorr_poster_1 = (t1_info_a == 0 | t2_info_a == 0)
	gen d_incorr_poster_2 = (t1_info_b == 0 | t2_info_b == 0)
	gen d_incorr_poster_3 = (t1_info_c == "worse" | t2_info_c == "worse")
	
		* remove false zeros : posteriors were only measures among those who received the info treatment 
		replace d_incorr_poster_1 = . if treat_any == 0
		replace d_incorr_poster_2 = . if treat_any == 0
		replace d_incorr_poster_3 = . if treat_any == 0
			

	* print out the relevant numbers
	sum d_incorr_prior_1_effective 	d_incorr_prior_2_mild_moder 	d_incorr_prior_3_gpa   	///
		d_incorr_poster_1 			d_incorr_poster_2  				d_incorr_poster_3   	///
			if treat_any == 1


	keep if treat_any == 1
			
	* Collapse to the treatment-group means (shares)
	collapse ///
		(mean)  prior1 = d_incorr_prior_1_effective  post1 = d_incorr_poster_1 ///
				prior2 = d_incorr_prior_2_mild_moder post2 = d_incorr_poster_2 ///
				prior3 = d_incorr_prior_3_gpa        post3 = d_incorr_poster_3

* Reshape to one row per fact with two columns (prior/posterior)
gen id = 1

reshape long prior post, i(id) j(fact)

* Convert to percentages
replace prior = 100*prior
replace post  = 100*post

	label var prior "Prior"
	label var post  "Posterior"

	* X‑axis category labels (with a line break)
	label define Lbl_fact   ///
		1 "Therapy Effective (Fact 1)" ///
		2 "Mild Users Common (Fact 2)" ///
		3 "No GPA-Distress Link (Fact 3)"  ///
			, replace 
	
	label val fact Lbl_fact

* Bar chart
graph bar prior post, over(fact, label(labsize(medsmall))) ///
    bar(1, color(ebblue%30)) bar(2, color(ebblue%90*1.25)) ///
    legend(order(1 "Prior" 2 "Posterior") pos(11) col(2) ring(0) size(medlarge) ) ///
    ytitle("Percent with Incorrect Belief (%)", size(medium)) ///
    ylabel(0(20)90, angle(horizontal)) yscale(range(0 90))  ///
	blabel(bar,  format(%4.1f) size(medsmall) color(ebblue%90)) 
	
	
	* save the graph
	graph export "${figures}/graph_bar_belief_updating_by_fact.pdf",  replace









