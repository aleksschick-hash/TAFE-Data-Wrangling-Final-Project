/* ----------------------------------------------------------------------------
	code author: roberto gonzalez
	
	Figure 9 : LR Therapy Recommendations to Peers
---------------------------------------------------------------------------- */

/* Read in survey dataset */
use "${clean}/mh_survey_analysis_w_followup.dta", replace 

/* define outcomes */
local outcome_list "recommend_mh_on_campus recommend_mh_off_campus"

/* define regressor list */
local reg_list "1.treat_any#0.therapy_use_12m 1.treat_any#1.therapy_use_12m 1.therapy_use_12m"

/* estimate regressions */
estimates clear

/* initialize model counter */
local mmm = 0
foreach outcome in `outcome_list' {
	local ++mmm
	eststo m_`mmm' : regress `outcome' `reg_list' if in_sample == 1, robust
}

/* make coefficient plot */
coefplot (m_1, mcolor(midblue%75) ciopts(lcolor(midblue%75) lwidth(0.6)) msize(1.5)) ///
	(m_2, mcolor(gold%95) ciopts(lcolor(orange%45) lwidth(0.6)) msize(1.5)), ///
		ci(90) color(%50) order(1.treat_any*) keep(1.treat*) vertical  /// 
		yline(0, lcolor(purple%50)) ///
		yscale(range(-0.3 0.3)) ylabel(-0.3 (0.1) 0.3) ///
		xsize(4) ysize(3) ///
		legend(pos(12) row(1) span ///
			title("Suggested Therapy:", size(medium) span)  ///
			order(2 "On-Campus" 4 "Off-Campus")) ///
		note("90% CI. Followup survey outcome: suggested on/off-campus therapy in the last 6 months.", span)
		
	
	graph export "${figures}/Figure_9.pdf", replace
