/* ----------------------------------------------------------------------------
	code author: roberto gonzalez
	
	Figure 12 : Self-reported Therapy Usage by WTP
---------------------------------------------------------------------------- */

/* Read in survey dataset */
use "${clean}/mh_survey_analysis_w_followup.dta", replace 	

twoway (lpolyci used_mh_on_campus winz_wtp_therapy_pct_self_pos if treat_any == 0 & took_classes_2025 == 1, ///
        kernel(triangle) level(90) ///
        acolor("128 128 128%10") alwidth(none) alpattern(shortdash) lcolor("128 128 128")) ///
		(lpolyci used_mh_on_campus winz_wtp_therapy_pct_self_pos if treat_any == 1 & took_classes_2025 == 1, ///
        kernel(triangle) level(90) ///
        acolor("15 82 186%10") alwidth(none) alpattern(shortdash) lcolor("15 82 186")), ///
    legend(order(2 "control" 4 "treatment") position(10) ring(0)) ///
    xtitle("wtp for therapy for oneself (%)", size(medsmall)) ///
    ytitle("self-reported therapy use", size(medsmall)) ///
    ylabel(#5, format(%2.1fc) labsize(medsmall)) ///
    xlabel(#4, nogrid format(%2.1fc) labsize(medsmall)) ///
    note("Shaded areas represent 90% confidence intervals", size(small))	

	graph export "${figures}/Figure_12a.pdf", replace


twoway (lpolyci used_mh_off_campus winz_wtp_therapy_pct_self_pos if treat_any == 0 & took_classes_2025 == 1, ///
        kernel(triangle) level(90) ///
        acolor("128 128 128%10") alwidth(none) alpattern(shortdash) lcolor("128 128 128")) ///
		(lpolyci used_mh_off_campus winz_wtp_therapy_pct_self_pos if treat_any == 1 & took_classes_2025 == 1, ///
        kernel(triangle) level(90) ///
        acolor("15 82 186%10") alwidth(none) alpattern(shortdash) lcolor("15 82 186")), ///
    legend(order(2 "control" 4 "treatment") position(10) ring(0)) ///
    xtitle("wtp for therapy for oneself (%)", size(medsmall)) ///
    ytitle("self-reported therapy use", size(medsmall)) ///
    ylabel(#5, format(%2.1fc) labsize(medsmall)) ///
    xlabel(#4, nogrid format(%2.1fc) labsize(medsmall)) ///
    note("Shaded areas represent 90% confidence intervals", size(small))	

	graph export "${figures}/Figure_12b.pdf", replace
