/* ============================================================================
   File: Table_1.do

   Purpose:
       Produce Table 1: baseline sample characteristics (summary statistics).

   Output:
       Console summary statistics (optionally redirected or captured downstream).

   Requirements:
       - $clean : folder with cleaned data
       - Dataset: "${clean}/mh_survey_analysis.dta"
         Variables needed:
             female
             age
             d_heterosexual
             degree_level
             scholarship_full
             scholarship_some
             parent_educ_1
             parent_educ_2
   ============================================================================ */

use "${clean}/mh_survey_analysis.dta", replace

* Generate variables used in Table 1
gen d_undergrad          = (degree_level == "Bachelor's")
gen d_educ_both_parents  = (parent_educ_1 > 4 & parent_educ_2 > 4)

* Table 1: summary statistics
summarize female age d_heterosexual d_undergrad scholarship_full scholarship_some d_educ_both_parents

exit
