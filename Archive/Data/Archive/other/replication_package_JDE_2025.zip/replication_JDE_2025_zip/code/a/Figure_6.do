/* ============================================================================
   File: Figure_6.do

   Purpose:
       Produce Figure 6:
           - Figure 6a: Prior Belief 3 distribution (MH → GPA relationship)
           - Figure 6b: Scatterplot of Mental Health Score vs GPA

   Outputs:
       $results/figures/prior_belief_3_mh_gpa_corr.png
       $results/figures/mh_score_gpa_scatter_lfit.png

   Requirements:
       Dataset must include:
           prior_3_mh_gpa_corr
           prior_3_mh_gpa_num
           gpa_1
           mh_score
   ============================================================================ */

use "${clean}/mh_survey_analysis.dta", replace


* ============================================================================
* FIGURE 6a — Horizontal bar chart of prior belief about GPA–MH correlation
* ============================================================================
gen freq = 1

graph hbar (count) freq, over(prior_3_mh_gpa_corr, ///
    relabel(1 `" "Better" "ρ∈(0.3,0.5)" "'         ///
            2 `" "Much better" "ρ>0.5" "'         ///
            3 `" "Much worse" "ρ< -0.5" "'        ///
            4 `" "No better/worse" "ρ∈(-0.3,0.3)" "' ///
            5 `" "Worse" "ρ∈(-0.5, -0.3)" "')     ///
    sort(prior_3_mh_gpa_num))                     ///
    bar(1, color(ebblue%50))                      ///
    bar(2, color(ebblue%50))                      ///
    bar(3, color(purple%40))                      ///
    bar(4, color(ebblue%50))                      ///
    bar(5, color(ebblue%50))                      ///
    ytitle("Number of students")                  ///
    title("A student with mental health issues …", size(medlarge)) ///
    subtitle("performs _______ compared to a student without MH issues", size(medlarge)) ///
    text(365 30 "53%", size(medium))              ///
    text(155 9 "22%", size(medium))               ///
    text(101 51 "14%", size(medium))              ///
    text(65 72 "8.5%", size(medium))              ///
    text(22 93 "2.5%", size(medium))

graph export "$results/figures/prior_belief_3_mh_gpa_corr.png", as(png) replace



* ============================================================================
* FIGURE 6b — Scatterplot of MH Score vs GPA with linear fit
* ============================================================================
corr gpa_1 mh_score if gpa_1 > 73
local rho = round(r(rho), 0.001)

twoway (scatter mh_score gpa_1 if gpa_1 > 73, color(ebblue%50) msize(1.5)) ///
       (lfit    mh_score gpa_1 if gpa_1 > 73, color(navy%50)   lwidth(*1.5)), ///
       title("Mental Health and GPA") ///
       ytitle("Mental Distress Index (higher = worse, cutoff = 12)") ///
       xtitle("Overall GPA") ///
       legend(off) ///
       note("Pearson correlation coefficient ρ = `rho'.", size(small))

graph export "$results/figures/mh_score_gpa_scatter_lfit.png", as(png) replace

exit
