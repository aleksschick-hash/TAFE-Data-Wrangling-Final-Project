/* ----------------------------------------------------------------------------
	code author: roberto gonzalez
	
	Figure 11 : Effects on Long Run Using Therapy by Prior Use
---------------------------------------------------------------------------- */

/* Read in survey dataset */
use "${clean}/mh_survey_analysis_w_followup.dta", replace 

/* define outcomes */
local outcome_list "winz_wtp_therapy_pct_self wtp_therapy_pct_friend"

/* define regressor list */
local reg_list "1.treat_any#0.therapy_use_12m 1.treat_any#1.therapy_use_12m 1.therapy_use_12m"

/* estimate regressions */
estimates clear

/* initialize model counter */
local mmm = 0
foreach outcome in `outcome_list' {
	local ++mmm
	eststo m_`mmm' : regress `outcome' `reg_list' if in_sample == 1, robust
}

/* make coefficient plot */
coefplot (m_1, mcolor(ebblue%75) ciopts(lcolor(ebblue%75) lwidth(0.6)) msize(1.5)) ///
	(m_2, mcolor(eltblue%95) ciopts(lcolor(eltblue%45) lwidth(0.6)) msize(1.5)), ///
		ci(90) color(%50) order(1.treat_any*) keep(1.treat*) vertical  /// 
		yline(0, lcolor(purple%50)) ///
		yscale(range(-0.3 0.3)) ylabel(-0.3 (0.1) 0.3) ///
		xsize(4) ysize(3) ///
		legend(pos(12) row(1) span ///
			title("SR Private Therapy", size(medium) span)  ///
			order(2 "WTP Self"  4  "WTP Friend")) ///
		note("90% CI. Outcome from the baseline survey:" "WTP for online therapy.", span)
		
graph export "${figures}/Figure_11a.pdf", replace

/* redefine outcome list */
local outcome_list "used_mh_on_campus used_mh_off_campus"

/* estimate regressions */
estimates clear

/* initialize model counter */
local mmm = 0
foreach outcome in `outcome_list' {
	local ++mmm
	eststo m_`mmm' : regress `outcome' `reg_list' if in_sample == 1, robust
}

coefplot (m_1, mcolor(midblue%75) ciopts(lc(midblue%75) lwidth(0.6)) msize(1.5)) ///
	(m_2, mcolor(gold%95) ciopts(lc(orange%45) lwidth(0.6)) msize(1.5)),  ///
	ci(90) color(%50) order(1.treat_any*) keep(1.treat*) vertical  /// 
	yline(0, lcolor(purple%50))   ///
	yscale(range(-0.2 0.45)) ylabel(-0.2 (0.2) 0.4) ///
	legend(pos(12) row(1) span ///
	title("Used Therapy (6m):", size(medium) span)  ///
	order(2 "On-Campus" 4 "Off-Campus"))  ///
	xsize(3.3) ysize(3)  ///
	note("90% CI. Outcome from the followup survey:" "using on/off-campus therapy in the last 6 months.", span)
	
graph export "${figures}/Figure_11b.pdf", replace
