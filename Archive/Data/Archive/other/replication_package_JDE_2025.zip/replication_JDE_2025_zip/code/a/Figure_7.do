/* ============================================================================
   File: Figure_7.do

   Purpose:
       Produce Figure 7:
           - Figure 7a: Guesses about self-stigma vs true share
           - Figure 7b: Guesses about openness to share vs true share

   Outputs:
       $figures/guess_self_stigma_distribution.pdf
       $figures/guess_open_to_share_distribution.pdf

   Requirements:
       - $clean   : folder with cleaned data
       - $figures : folder where figures will be saved
       - Dataset: "${clean}/mh_survey_analysis.dta"
         Variables needed:
             d_self_stigma
             guess_self_stigma
             open_to_share
             guess_open_to_share
   ============================================================================ */

use "${clean}/mh_survey_analysis.dta", replace


* ============================================================================
* FIGURE 7a — Guessed % of students with self-stigma
* ============================================================================
summarize d_self_stigma
local mean_self_stigma       = round(r(mean)*100, 0.1)
local xline_mean_self_stigma = `mean_self_stigma'

summarize guess_self_stigma if d_self_stigma == 1
local mean_self_stigma_yes   = round(r(mean), 0.1)

summarize guess_self_stigma if d_self_stigma == 0
local mean_self_stigma_no    = round(r(mean), 0.1)

twoway (hist guess_self_stigma if d_self_stigma == 1, ///
           color(gold%50) frac start(0) width(10)) ///
       (hist guess_self_stigma if d_self_stigma == 0, ///
           color(midblue%30) frac start(0) width(10)), ///
       legend(order(2 "Students without self-stigma" ///
                    1 "Students with self-stigma") pos(12) cols(2)) ///
       text(0.195 31 "Observed %", color(gray%70) size(small) place(e)) ///
       ytitle("Share of Students") ///
       xline(`xline_mean_self_stigma', lcolor(gray%80)) ///
       xtitle("Guessed % of students who self-stigmatize", size(medium)) ///
       subtitle(, fcolor(ltblue*0.2)) ///
       note(" " ///
            "Correct share (incentivized Q) = `mean_self_stigma'% (vertical line)." ///
            "Guess among NO self-stigma = `mean_self_stigma_no'%, " ///
            "among those WITH self-stigma = `mean_self_stigma_yes'%", ///
            size(medsmall))

graph export "$figures/guess_self_stigma_distribution.pdf", replace



* ============================================================================
* FIGURE 7b — Guessed % of students open to share vs true share
* ============================================================================
summarize open_to_share
local mean_open_to_share       = round(r(mean)*100, 0.1)
local xline_mean_open_to_share = `mean_open_to_share'

summarize guess_open_to_share if open_to_share == 0
local mean_open_to_share_no    = round(r(mean), 0.1)

summarize guess_open_to_share if open_to_share == 1
local mean_open_to_share_yes   = round(r(mean), 0.1)

twoway (hist guess_open_to_share if open_to_share == 0, ///
           color(gold%50) frac start(0) width(10)) ///
       (hist guess_open_to_share if open_to_share == 1, ///
           color(midblue%30) frac start(0) width(10)), ///
       legend(order(2 "Students open to share" ///
                    1 "Students NOT open to share") pos(12) cols(2)) ///
       ytitle("Share of Students") ///
       xline(`xline_mean_open_to_share', lcolor(gray%80)) ///
       text(0.29 38 "Observed %", color(gray%70) size(small) place(e)) ///
       xtitle("Guessed % of students open to share", size(medium)) ///
       xlabel(, nogrid) ///
       subtitle(, fcolor(ltblue*0.2)) ///
       note(" " ///
            "Correct share (incentivized Q) = `mean_open_to_share'% (vertical line)." ///
            "Guess among NOT open to share = `mean_open_to_share_no'%, " ///
            "among those Open to share = `mean_open_to_share_yes'%", ///
            size(medsmall))

graph export "$figures/guess_open_to_share_distribution.pdf", replace

exit
