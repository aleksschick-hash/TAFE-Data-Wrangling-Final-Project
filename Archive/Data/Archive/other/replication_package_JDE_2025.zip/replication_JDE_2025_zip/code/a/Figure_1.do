/* ============================================================================
   File: figure1_mh_score_distribution.do

   Purpose:
       Produce Figure 1: "Student Distribution by Mental Health Status"

   Output:
       $figures/mh_score_distribution.png

   Requirements:
       - Global macro $clean   : folder with cleaned data
       - Global macro $figures : folder where figures will be saved
       - Dataset "${clean}/mh_survey_analysis.dta"
         containing variables: mh_score, distress
   ============================================================================ */

* ---------------------------------------------------------------------------
* 1. Load data
* ---------------------------------------------------------------------------
use "${clean}/mh_survey_analysis.dta", clear

* (Optional) Descriptive check used in paper text
summarize distress mh_score

* ---------------------------------------------------------------------------
* 2. Figure 1 — Histogram of mental health score with distress cutoff
* ---------------------------------------------------------------------------
twoway (histogram mh_score if mh_score < 12, ///
            lcolor(navy%20) fcolor(ebg%80) ///
            freq start(0) width(2))          ///
       (histogram mh_score if mh_score >= 12, ///
            color(purple%40) width(2) freq), ///
       legend(off)                           ///
       title("Student Distribution by Mental Health Status", size(medium)) ///
       subtitle(, fcolor(ltblue*0.2))        ///
       xlabel(0(2)26, nogrid)                ///
       ytitle("Students")                    ///
       xline(12, lcolor(purple%40))          ///
       xtitle("Mental Distress Index (higher = worse)") ///
       text(75 16.5 "23% above cutoff", place(ur) size(large)) ///
       note("In purple, students in mental distress. Mental distress is defined as having a distress index equal to or above 12 points" ///
            "based on PHQ-4 and GAD-4 screening surveys (out of 24 points); N=680.", size(small))

graph export "$figures/mh_score_distribution.png", as(png) replace

exit
