/* ----------------------------------------------------------------------------
							Mental Health Paper
							
	Code author: Roberto Gonzalez
	Date: Januaray 26, 2025
	
	Objetive: Clean Health and Nutrition survey ENSANUT from 2023 to get some
	statistics
---------------------------------------------------------------------------- */

/* Read in dataset for respondents 20 years o older */
use "${raw}/ENSANUT/adultos_ensanut2023_w_n.dta", clear
generate adult = 1
append using "${raw}/ENSANUT/adolescentes_ensanut2023_w_n.dta"
replace adult = 0 if missing(adult)

/* Keep variables to be used */
keep adult x_region estrato ponde_f completa entidad desc_ent edad sexo a0211 a0212 a0213 a0214 a0215 a0216 a0217 ///
	d0601*
	
/* Unify the depression variables */
replace a0211 = d0601a if adult == 0
replace a0212 = d0601b if adult == 0
replace a0213 = d0601c if adult == 0
replace a0214 = d0601d if adult == 0
replace a0215 = d0601e if adult == 0
replace a0216 = d0601f if adult == 0
replace a0217 = d0601g if adult == 0

order x_region estrato ponde_f completa

/* Make mental health score */
recode a0211 a0212 a0213 a0214 a0215 a0216 a0217 (1=0) (2=1) (3=2) (4=3)

egen mh_score = rowtotal(a0211 a0212 a0213 a0214 a0215 a0216 a0217)

/* Make sample ages indicator */
generate samp_age = (edad >= 17 & edad <= 28)

/* Create distress indicator */
foreach kkk in `=floor((21)/2)' {
	generate distress_`kkk' = (mh_score >= `kkk')

quietly summarize distress_`kkk' [aw = ponde_f], detail
display in red "Sample size is `r(N)'"
local dist_mean = floor(100*r(mean))

/* Nationally representative */
twoway (histogram mh_score if (distress_`kkk' == 0), freq discrete start(0) width(1) color("15 82 186%50")) ///
	(histogram mh_score if (distress_`kkk' == 1), freq discrete start(0) width(1) color(cranberry%50) ///
	xlabel(0(2)22, nogrid labsize(medsmall)) ylabel(, labsize(medsmall)) ///
	xtitle("depression screening score" "higher = worse", size(medsmall)) ///
	ytitle("Respondents", size(medsmall)) text(570 18 "`dist_mean'% above cutoff") ///
	legend(off) )
	
graph export "${figures}/hist_mh_score_ensanut_national_cutoff`kkk'.png", replace


/* National restricted to ages 17-28 to match our sample */
quietly summarize distress_`kkk' if samp_age == 1, detail
display in red "Sample size is `r(N)'"
local dist_mean = floor(100*r(mean))

twoway (histogram mh_score if (distress_`kkk' == 0 & samp_age == 1), freq discrete start(0) width(1) color("15 82 186%50")) ///
	(histogram mh_score if (distress_`kkk' == 1 & samp_age == 1), freq discrete start(0) width(1) color(cranberry%50) ///
	xlabel(0(2)22, nogrid labsize(medsmall)) ylabel(, labsize(medsmall)) ///
	xtitle("depression screening score" "higher = worse", size(medsmall)) ///
	ytitle("Respondents", size(medsmall)) text(115 18 "`dist_mean'% above cutoff") ///
	legend(off) )
	
graph export "${figures}/hist_mh_score_ensanut_national_uniage_cutoff`kkk'.png", replace
}

/*	
/* Regionwise representative */
quietly summarize distress [aw = ponde_f] if (x_region == 1), detail
local dist_mean = floor(100*r(mean))

twoway (histogram mh_score if (distress == 0 & x_region == 1), freq start(0) width(2) color(navy%20)) ///
	(histogram mh_score if (distress == 1 & x_region == 1), freq start(0) width(2) color(purple%40) ///
	xlabel(0(2)22, nogrid labsize(medsmall)) ylabel(, labsize(medsmall)) ///
	xtitle("mental distress index" "higher = worse", size(medsmall)) ///
	ytitle("Respondents", size(medsmall)) text(120 16 "`dist_mean'% above cutoff") ///
	legend(off) xline(10, lcolor(cranberry) lpattern(solid)))
	
graph export "${tables}/hist_mh_score_ensanut_north.png", replace


/* Regionwise restricted to ages 17-28 to match sample */
quietly summarize distress_`kkk' if (x_region == 1 & samp_age == 1), detail
local dist_mean = floor(100*r(mean))

twoway (histogram mh_score if (distress_`kkk' == 0 & x_region == 1 & samp_age == 1), freq start(0) width(2) color(navy%20)) ///
	(histogram mh_score if (distress_`kkk' == 1 & x_region == 1 & samp_age == 1), freq start(0) width(2) color(purple%40) ///
	xlabel(0(2)22, nogrid labsize(medsmall)) ylabel(, labsize(medsmall)) ///
	xtitle("mental distress index" "higher = worse", size(medsmall)) ///
	ytitle("Respondents", size(medsmall)) text(23 16 "`dist_mean'% above cutoff") ///
	legend(off) xline(10, lcolor(cranberry) lpattern(solid)))
	
graph export "${tables}/hist_mh_score_ensanut_north_uniage.png", replace


/* Nuevo Leon - not representative and only 34 respondents */
generate nvoleon = (strpos(lower(desc_ent), "nuevo") > 0)
quietly summarize distress if (nvoleon == 1), detail
local dist_mean = floor(100*r(mean))
twoway (histogram mh_score if (distress == 0 & nvoleon == 1), freq start(0) width(2) color(navy%20)) ///
	(histogram mh_score if (distress == 1 & nvoleon == 1), freq start(0) width(2) color(purple%40) ///
	xlabel(0(2)22, nogrid labsize(medsmall)) ylabel(, labsize(medsmall)) ///
	xtitle("mental distress index" "higher = worse", size(medsmall)) ///
	ytitle("Respondents", size(medsmall)) text(8 16 "`dist_mean'% above cutoff") ///
	legend(off) xline(10, lcolor(cranberry) lpattern(solid)))
	
graph export "${tables}/hist_mh_score_ensanut_nvoleon.png", replace
*/