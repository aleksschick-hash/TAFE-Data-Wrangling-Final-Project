/* ============================================================================
   File: Figure_3.do

   Purpose:
       Produce all subfigures of Figure 3:
           - Figure 3a: Prior Belief 1 — Long-Run Therapy Effectiveness
           - Figure 3b: Prior Belief 2 — Who Goes to Therapy?
           - Figure 3c: Prior Belief 3 — Correlation Between GPA & MH

   Outputs:
       $figures/pie_prior_1_effectiveness.png
       $figures/pie_prior_2_who_goes_to_therapy.png
       $figures/pie_prior_3_corr_gpa_distress.png

   Requirements:
       - $clean   : folder with cleaned data
       - $figures : folder where figures will be saved
       - Dataset: "${clean}/mh_survey_analysis.dta"
         Variables needed:
             d_incorr_prior_1_effective
             d_incorr_prior_2_mild_moder
             d_incorr_prior_3_gpa
   ============================================================================ */

* ---------------------------------------------------------------------------
* 1. Load data
* ---------------------------------------------------------------------------
use "${clean}/mh_survey_analysis.dta", replace

* ---------------------------------------------------------------------------
* 2. Common labeling used across all three pie charts
* ---------------------------------------------------------------------------
label define Lbl_prior_01 1 "Incorrect" 0 "Correct", replace

label values d_incorr_prior_1_effective    Lbl_prior_01
label values d_incorr_prior_2_mild_moder   Lbl_prior_01
label values d_incorr_prior_3_gpa          Lbl_prior_01

* unified color scheme
global pie_colors "pie(1, color(midblue%50))   pie(2, color(gold%40))"

* ============================================================================
* FIGURE 3a — Prior Belief 1: Therapy Effectiveness (Long-run)
* ============================================================================
graph pie, over(d_incorr_prior_1_effective) ///
    plabel(_all name,    color(black) size(medlarge) format(%9.1f) gap(-5)) ///
    plabel(_all percent, color(black) size(medium)   format(%9.1f) gap(8)) ///
    title("Prior Belief 1: Long-Run Therapy Effectiveness", size(large)) ///
    subtitle("Therapy has positive effects on reducing mild and moderate " ///
             "depression symptoms 4-5 years later?", ///
             size(medlarge) span) ///
    legend(order(1 "Correct" 2 "Incorrect") rows(1) position(6)) ///
    ${pie_colors} ///
    xsize(5.25) ysize(5)

graph export "$figures/pie_prior_1_effectiveness.png", as(png) replace



* ============================================================================
* FIGURE 3b — Prior Belief 2: Who Goes to Therapy?
* ============================================================================
graph pie, over(d_incorr_prior_2_mild_moder) ///
    plabel(_all name,    color(black) size(medlarge) format(%9.1f) gap(-15)) ///
    plabel(_all percent, color(black) size(medium)   format(%9.1f) gap(8)) ///
    title("Prior Belief 2: Who goes to therapy?", size(large)) ///
    subtitle("Do most students receiving MH support have mild or no symptoms?", ///
             size(medlarge) span) ///
    legend(order(1 "Correct" 2 "Incorrect") rows(1) position(6)) ///
    ${pie_colors} ///
    xsize(5.25) ysize(5)

graph export "$figures/pie_prior_2_who_goes_to_therapy.png", as(png) replace



* ============================================================================
* FIGURE 3c — Prior Belief 3: Correlation Between GPA & Mental Distress
* ============================================================================
graph pie, over(d_incorr_prior_3_gpa) ///
    plabel(_all name,    color(black) size(medlarge) format(%9.1f) gap(-5)) ///
    plabel(_all percent, color(black) size(medium)   format(%9.1f) gap(10)) ///
    title("Prior Belief 3: Correlation between GPA & MH", size(large)) ///
    subtitle("Guess the relationship between GPA and mental distress " ///
             "across students in the survey?", size(medlarge) span) ///
    legend(order(1 "Correct" 2 "Incorrect") rows(1) position(6)) ///
    ${pie_colors} ///
    xsize(5.25) ysize(5)

graph export "$figures/pie_prior_3_corr_gpa_distress.png", as(png) replace

exit
