/* ----------------------------------------------------------------------------
	code author: roberto gonzalez
	
	Table 5: Covariate Balance
---------------------------------------------------------------------------- */

/* Read in survey dataset */
use "${clean}/mh_survey_analysis_w_followup.dta" , replace 

/* Label variables for appearance on tables */
label variable age "Age"
label variable female "Female"
label variable d_financ_stress "Financially Stressed"
label variable scholarship_some "Has Scholarship"
label variable d_moved "Moved Residence"
label variable gpa_1 "GPA"
label variable mh_score "MH Score"
label variable therapy_use_12m "Used Therapy L12 Months"
label variable open_to_share "Open to Share MH Challenges"
label variable d_self_stigma "Self-stigmatize"

/* Balance for Control v Any Treatment */
iebaltab age female d_financ_stress scholarship_some scholarship_full d_moved gpa_1 mh_score therapy_use_12m open_to_share d_self_stigma, ///
	replace savetex("${tables}/balance_control_treat_paper.tex") vce(robust) groupvar(treat_any) ///
	starlevels(0.1 0.05 0.01) stats(desc(sd) pair(diff)) format(%4.3fc) ///
	rowvarlabels nonote browse  
