/* ----------------------------------------------------------------------------
									MH Paper
						
	Code author: Roberto Gonzalez
	Date: May 17, 2025
	
	Objective: Replicate specifications shown in paper but including 
	controls selected via post double-selection lasso
---------------------------------------------------------------------------- */

/* Read in dataset */
use "${clean}/mh_survey_analysis_w_followup.dta", clear 

/* Specify covariates to be selected from in regressions */
local possible_x "age female d_financ_stress scholarship_some scholarship_full d_moved gpa_1 mh_score therapy_use_12m open_to_share d_self_stigma"

/* Define global for stars */
local want_stars = 1
if `want_stars' == 1 {
	global star = "star(* 0.1 ** 0.05  *** 0.01)"
}
else {
	global star = ""
}

/* Clear estimates */
estimates clear
/* Counter for outcomes */
local y_count = 0
/* ----------------------------------------------------------------------------
	Effects on Advice prompt at Baseline & recommending therapy in 6 months 
---------------------------------------------------------------------------- */
foreach outcome of varlist adv_campus_prof_help adv_prof_help_any adv_campus_prof_help adv_prof_help_any recommend_mh_on_campus recommend_mh_off_campus {
	/* Count outcome being analyzed */
	local ++y_count
	/* Loop over possible samples as needed */
	if inlist(`y_count', 1, 2) {
		local touse = ""
	}
	else {
		local touse = "if responded_followup == 1 & in_sample == 1"
	}
	/* Select controls via PDS Lasso */
	pdslasso `outcome' i.treat_any (`possible_x') `touse', robust
	local lasso_x = e(xselected_dex)
	if "`lasso_x'" == "_cons" {
		local lasso_x = ""
	}
	display in yellow "`lasso_x'"
	/* Estimate treatment effects */
	eststo m`y_count' : regress `outcome' i.treat_any `lasso_x' `touse', robust
	/* Compute outcome mean and sd and store in locals for adding to table */
	quietly summarize `outcome' if e(sample) & treat_any == 0, detail
	estadd scalar ymean = r(mean)
	estadd scalar ysd = r(sd)
	estadd local xvars = "\checkmark"
}

esttab _all using "${tables}/reg_advice_v2_pdslasso.tex", replace booktabs nonotes b(3) se(3) ///
	mgroups("SR: Advice Prompt (All)" "Advice Prompt (in Followup)" "LR: Suggested Therapy", pattern(1 0 1 0 1 0) /// 
		prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
	mtitles("On-Campus Help" "Any Prof. Help" "On-Campus Help" "Any Prof. Help" "On Campus" "Off Campus") ///
	keep(1.treat_any) coeflabels(1.treat_any "Treated") ${star} ///
	stats(ymean ysd N xvars, labels("Control Mean" "Control SD" "Observations" "LASSO Controls") fmt(3 2 0 0)) ///
	addnotes("\scriptsize Sample includes \textbf{all} respondents in col 1-2, only followup respondents who took classes in 2025 in cols 3-6. Robust S.E.  *** 1\%, ** 5\%, * 10\% significant. SR = Short-run (measured in the baseline survey experiment). LR = Long-run (measured in the 6-month followup survey).") ///
	title("Effects on Advice Prompt at Baseline \&  Recommending Therapy in 6 Months \label{tab:reg_advice_pdslasso}") ///
	substitute({l} {p{0.989\linewidth}})

/* ----------------------------------------------------------------------------
			Effects on Personal and Public Stigma Related Outcomes
---------------------------------------------------------------------------- */
/* Clear estimates */
estimates clear
/* Counter for outcomes */
local y_count = 0
foreach outcome of varlist pref_mh_symp_v_low_gpa pref_mh_talk_v_low_gpa discuss_own_mh_probl discuss_own_oth_therapy followup_discuss_mh {
	/* Count outcome being analyzed */
	local ++y_count
	/* Loop over possible samples as needed */
	if inlist(`y_count', 1, 2) {
		local touse = ""
	}
	else {
		local touse = "if responded_followup == 1 & in_sample == 1"
	}
	/* Select controls via PDS Lasso */
	pdslasso `outcome' i.treat_any (`possible_x') `touse', robust
	local lasso_x = e(xselected_dex)
	if "`lasso_x'" == "_cons" {
		local lasso_x = ""
	}
	/* Estimate treatment effects */
	eststo m`y_count' : regress `outcome' i.treat_any `lasso_x' `touse', robust
	/* Compute outcome mean and sd and store in locals for adding to table */
	quietly summarize `outcome' if e(sample) & treat_any == 0, detail
	estadd scalar ymean = r(mean)
	estadd scalar ysd = r(sd)
	estadd local xvars = "\checkmark"
}

esttab _all using "${tables}/reg_mh_stigma_cols5_pdslasso.tex", replace booktabs nonotes b(3) se(3) ///
	mgroups("SR: Prefer over Low GPA Student" "LR: Discuss MH / Therapy", pattern(1 0 1 0 0) /// 
		prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
	mtitles("Distress Sympt." "MH Talk" "Own MH Issues" "Therapy" "Any MH") ///
	keep(1.treat_any) coeflabels(1.treat_any "Treated") ${star} ///
	stats(ymean ysd N xvars, labels("Control Mean" "Control SD" "Observations" "LASSO Controls") fmt(3 2 0 0)) ///
	addnotes("\scriptsize Sample includes \textbf{all} respondents in col 1-2, only followup respondents who took classes in 2025 in cols 3-5. Robust S.E.  *** 1\%, ** 5\%, * 10\% significant. SR = Short-run (measured in the baseline survey experiment). LR = Long-run (measured in the 6-month followup survey).") ///
	title("Effects on Personal \&  Public Stigma-Related Outcomes  \label{tab:reg_rank_stigma_6} ") ///
	substitute({l} {p{0.989\linewidth}})