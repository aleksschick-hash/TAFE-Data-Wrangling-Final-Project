/* ----------------------------------------------------------------------------
	code author: roberto gonzalez
	
	Figure 10: 
---------------------------------------------------------------------------- */

/* Read in survey dataset */
use "${clean}/mh_survey_analysis_w_followup.dta", replace 

/* define outcome list */
local outcome_list "wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct" 

estimates clear
/* estimate effects */
local iii = 1	
foreach var in `outcome_list' {
	eststo reg`iii', title("test"):  ///
		regress `var'  treat_any, robust 
	local ++iii
}			

coefplot (reg1, mcolor(ebblue%70) ciopts(lc(ebblue%70) lwidth(0.6)) msize(1.5)) ///
	(reg2, mcolor(eltblue%70) ciopts(lc(eltblue%70) lwidth(0.6))  msize(1.5)) ///
	(reg3, mcolor(purple%70) ciopts(lc(purple%70) lwidth(0.6)) msize(1.5)), ///
		ci(90) vertical drop(_cons) levels(90) ///
		yline(0, lcolor(purple%50)) ///
		legend(pos(1) row(1) span size(medium) ///
		title(" ", size(mediuml) span) ///
		order(2 "WTP Self" 4 "WTP Friend"  6 "Donation %")) ///
		xsize(3) ysize(3) ///
		note("N = 680. CI 90%. ", size(small) ) ///
		yscale( range(-0.125 0.15) )    ylabel(-0.10 "-10%" -0.05 "-5%" 0 "0%" 0.05 "5%" 0.10 "10%"  0.15  "15%")    /*  */  /// 
		ylabel(, labsize(medium))  
graph export "${figures}/Figure_10a.pdf", replace
