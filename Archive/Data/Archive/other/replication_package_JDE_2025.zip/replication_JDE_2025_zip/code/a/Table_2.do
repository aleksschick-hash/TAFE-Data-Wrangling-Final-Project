/* ============================================================================
   File: Table_2.do

   Purpose:
       Produce Table 2: cross-tabulation of distress and past-year therapy use.

   Output:
       Console cross-tabulation of distress × therapy_use_12m (row & column %).

   Requirements:
       - $clean : folder with cleaned data
       - Dataset: "${clean}/mh_survey_analysis.dta"
         Variables needed:
             distress
             therapy_use_12m
   ============================================================================ */

use "${clean}/mh_survey_analysis.dta", replace

* Table 2: cross-tabulation of distress and therapy use (last 12 months)
tabulate distress therapy_use_12m, row column

exit
