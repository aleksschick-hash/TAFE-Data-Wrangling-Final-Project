/* Read in dataset */
use "${clean}/mh_survey_analysis_w_followup.dta" , replace

/* Set seed for reproducibility */
set seed 20250503
set sortseed 20250503

/* Set local for number of repetitions to conduct */
local numreps = 5000

/* Count number of control observations */
count if treat_any == 0 & responded_followup == 1 & took_classes_2025 == 1
local n_control = r(N)

/* Define matrix for storing fake difference */
matrix define fake_beta = J(`numreps', 1, .)

keep if responded_followup == 1 & took_classes_2025 == 1

foreach outcome of varlist wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct adv_campus_prof_help prefer_low_gpa_over_mh_sympt prefer_low_gpa_over_mh_talk adv_campus_prof_help adv_passive_share adv_sugg_share used_mh_on_campus used_mh_off_campus would_use_on_campus would_use_off_campus recommend_mh_off_campus recommend_mh_on_campus discuss_own_mh_probl discuss_own_oth_therapy {
	preserve
	/* Message on which outcome is being analyzed */
	display in yellow "Doing randomization inference for `outcome'"
	/* Store observed result */
	regress `outcome' 1.treat_any, robust
	local obs_eff = _b[1.treat_any]
	/* Counter of times the observed effect is smaller than the fake effect */
	local numtimes = 0
	forvalues rrr = 1/`numreps' {
		display in yellow "Loop `rrr' of `numreps'"
		quietly {
			/* Assign treatment randomly */
			capture drop fake_id
			generate fake_id = runiform()
			sort fake_id
			capture drop fake_treat
			generate fake_treat = (_n > `n_control')
			/* Estimate difference in means */
			regress `outcome' 1.fake_treat, robust
			/* Store result */
			matrix fake_beta[`rrr', 1] = _b[1.fake_treat]
			/* Add to counter */
			if abs(_b[1.fake_treat]) > abs(`obs_eff') {
				local numtimes = `numtimes' + 1
			}
		}
	}
	/* Plot distribution */
	clear
	svmat fake_beta
	sort fake_beta1
	/* Get 2.5 and 97.5 percentiles */
	summarize fake_beta1 if _n == `numreps'*0.05
	local low = r(mean)
	summarize fake_beta1 if _n == `numreps'*0.95
	local high = r(mean)
	
	/* Select where the percentiles text and observed estimate text appears */
	if inrange(`obs_eff', `low', 0)  {
		local x_pos_eff = `=0.93*`obs_eff''
		local x_pos_low = `=1.07*`low''
		local x_pos_high = `=1.07*`high''
	}
	else if `obs_eff' < `low' {
		local x_pos_eff = `=1.07*`obs_eff''
		local x_pos_low = `=0.93*`low''
		local x_pos_high = `=0.93*`high''
	}
	else if inrange(`obs_eff', 0, `high')  {
		local x_pos_eff = `=0.93*`obs_eff''
		local x_pos_low = `=1.07*`low''
		local x_pos_high = `=1.07*`high''
	}
	else if `obs_eff' > `high' {
		local x_pos_eff = `=1.07*`obs_eff''
		local x_pos_low = `=0.93*`low''
		local x_pos_high = `=0.93*`high''
	}
	
	/* Compute p-value */
	local ppp = string(`numtimes'/`numreps', "%4.3fc")
	
	graph set window fontface default
	histogram fake_beta1 if _n != _N, percent bin(40) fcolor("15 82 186%50") lcolor(none) ///
		xline(`obs_eff', lcolor("220 0 0") lpattern(solid) lwidth(thin)) ///
		xline(`low', lcolor(gs12) lpattern(solid) lwidth(thin)) ///
		xline(`high', lcolor(gs12) lpattern(solid) lwidth(thin)) ///
		xlabel(#5, nogrid format(%4.2fc)) ///
		ylabel(#5, nogrid) ///
		xtitle("placebo estimates") ///
		text(4.0 `x_pos_low' "5 percentile", size(medsmall) orientation(vertical) color(gs8)) ///
		text(4.0 `x_pos_high' "95 percentile", size(medsmall) orientation(vertical) color(gs8)) ///
		text(4.0 `x_pos_eff' "observed estimate", size(medsmall) orientation(vertical) color("220 0 0")) ///
		note("Randomization Inference {it:p} = `ppp'")
	graph export "${figures}/randinf_`outcome'.pdf", replace
		
	restore
}