/* ----------------------------------------------------------------------------
	code author: roberto gonzalez
	
	Table 9 : Effects on Advice Prompt at baseline & Recommending Therapy in
	6 Months
---------------------------------------------------------------------------- */

/* Read in survey dataset */
use "${clean}/mh_survey_analysis_w_followup.dta" , replace 

/* define outcome list */
local outcome_list "adv_campus_prof_help adv_prof_help_any adv_campus_prof_help adv_prof_help_any recommend_mh_on_campus recommend_mh_off_campus"

/* define treatment variable */
local treatvar "treat_any"

/* clear estimates */
estimates clear

/* initialize regression counter */
local mmm = 0
/* loop over outcomes to estimate regressions */
foreach outcome in `outcome_list' {
	/* add one to regression counter */
	local ++mmm
	/* define populations */
	if inlist(`mmm', 1, 2) {
		local population "1==1" 
	}
	else {
		local population "in_sample == 1"
	}
	/* estimate regression */
	eststo : regress `outcome' `treatvar' if `population', robust
	/* get outcome mean and sd */
	quietly summarize `outcome' if e(sample) & `treatvar' == 0
	estadd scalar ymean = r(mean)
	estadd scalar ysd = r(sd)
}

/* export regression table */
esttab _all using "${tables}/table_9.tex", replace booktabs b(3) se(3) nogaps ///
	nonotes keep(`treatvar') coeflabel(`treatvar' "Treated") stats(ymean ysd N, ///
		labels("Control Mean" "Control SD" "Observations") fmt(3 2 0)) ///
	mtitles("On-Campus Help" "Any Prof Help""On-Campus Help" "Any Prof Help" ///
		"ON Campus" "OFF Campus") star(* 0.1 ** 0.05 *** 0.01) 
	