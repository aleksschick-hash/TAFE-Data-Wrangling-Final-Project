/* ----------------------------------------------------------------------------
							Mental Health Paper
							
	Code author: Roberto Gonzalez
	Date: April 22, 2025
	
	Objective: Run power calculation do files for each outcome in PAP and 
	in final manuscript for JDE
---------------------------------------------------------------------------- */

/* NOTE: Please be aware that each power calculation takes about 8 minutes to run
on a laptop with 32 GB of RAM and an intel i7 vPRO processor. 
Hence, if you run all do files in this master file your computer will be running 
code for about 40 minutes. */

/* Set font size as sans serif */
graph set window fontface default

/* Pre-registered Main outcomes -------------------------------------------- */
/* Outcome: WTP for therapy for self */
do "${code}/a/power_calcs/power_wtp_therapy_pct_self.do"

/* Outcome: WTP for therapy for friend */
do "${code}/a/power_calcs/power_wtp_therapy_pct_friend.do"

/* Outcome: Donation to cover therapy cost to a student with financial need */
do "${code}/a/power_calcs/power_donation_pct.do"

/* Pre-registered Secondary outcomes --------------------------------------- */
/* Outcome: Prefer student who talks about MH issues over student with low GPA */
do "${code}/a/power_calcs/power_prefer_mh_talk_over_low_gpa.do"

/* Outcome: Prefer student who has MH symptoms over student with low GPA */
do "${code}/a/power_calcs/power_prefer_mh_sympt_over_low_gpa.do"



/* Other outcomes ---------------------------------------------------------- */
