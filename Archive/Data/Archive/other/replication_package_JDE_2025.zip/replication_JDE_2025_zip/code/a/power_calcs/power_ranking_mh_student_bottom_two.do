/* ----------------------------------------------------------------------------
									Mental Health
									
	Code author: Roberto Gonzalez
	Date: April 20, 2025
	
	Objective: Run power calculation for different MDE's using 
---------------------------------------------------------------------------- */

/* Read in dataset to use control group data for using distributions moments as inputs for simulations */
use "${clean}/mh_survey_analysis.dta" , replace

/* Keep control observations only */
keep if treat_any == 0

/* Generate the outcomes */
generate open_mh_stud_last = (rank_9 == 6) // Probability of ranking as least comfortable the student who talks about current MH struggles
generate open_mh_stud_bottom2 = (inlist(rank_9, 5, 6)) // Prob of ranking top 2 least comfortable the student who talks about current MH struggles

/* Create locals for storing sample size values and treatment allocations */
local n_control = 232
local n_treat = 680 - `n_control'

/* create local for fixing outcome mean and sd */
summarize open_mh_stud_bottom2
local outcomemean = r(mean)
local outcomesd = r(sd)

/* Local for storing jumps in effect size values */
local atejump = 0.025*`outcomesd'
local atestart = 0.05*`outcomesd'
local ateend = 0.55*`outcomesd'

/* Set local for number of repetitions per simulation */
local n_reps = 2000

/* Set significance level - Fix at alpha = 5% */
local alpha_val = 0.05

/* Set seed for reproducibility - from random.org between 1 and 1,000,000 */
set seed 477568
set sortseed 477568

/* Initiate loop simulating data ------------------------------------------- */
local ate_counter = 0
forvalues ate = `atestart'(`atejump')`ateend' {
	/* Add one to ate counter */
	local ++ate_counter
	/* Define matrix for storing p-values of estimates in simulations */
	display in yellow "Defining matrix for storing p-values"
	matrix define pvals = J(`n_reps', 1, .)
	/* Loop over repetitions with fixed ate */
	forvalues rrr = 1/`n_reps' {
		if `ate' == `atestart' & `rrr' == 1 {
			/* Define matrix for storing power */
			matrix define powermat = J(`=ceil((`ateend'-`atestart')/`atejump')', 1, .)
		}
		/* Simulate data */
		clear 
		/* Create N observations */
		set obs `=`n_control' + `n_treat''
		/* Create individual id's */
		generate id = _n
		/* Assign treatment and control observations */
		generate treated = (id > `n_control')
		/* Simulate outcome for both groups */
		generate int outcome = rbinomial(1, `outcomemean') if treated == 0
		replace outcome = rbinomial(1, `outcomemean' + `ate') if treated == 1
		/* Regress outcome on treatment indicator */
		regress outcome treated, robust
		/* Store p-value */
		display in red "Storing p-value for iteration `rrr' of ATE = `ate'"
		matrix pvals[`rrr', 1] = r(table)[4, 1]
	}
	/* Count number of times we reject H0 */
	clear
	svmat pvals
	browse
	generate rejected = (pvals1 < `alpha_val')
	collapse (mean) rejected
	matrix powermat[`ate_counter', 1] = rejected[1]
}

/* Save power matrix as data */
clear
svmat powermat
generate mde_in_sd = `atestart' if _n == 1
replace mde_in_sd = `atestart'/`outcomesd' + (`atejump'/`outcomesd')*(_n-1) if _n >= 2
format mde_in_sd %7.6fc

twoway 	(line powermat1 mde_in_sd, color(black%80) lpattern(solid)), ///
		ytitle("power", size(medium)) xtitle("minimum detectable effect ({&sigma}'s)", size(medium)) ///
		ylabel(0(0.2)1, nogrid labsize(medium) format(%3.2fc) ) ///
		xlabel(#8, labsize(medium) format(%5.2fc)) ///
		legend(off) ///
		yline(0.8, lcolor("220 0 0") lwidth(thin) lpattern(solid%10)) ///
		text(0.15 0.425 "{&alpha} = 0.05") ///
		text(0.10 0.45 "N control = `n_control'", size(medium)) ///
		text(0.05 0.45 "N treated = `n_treat'", size(medium))
		