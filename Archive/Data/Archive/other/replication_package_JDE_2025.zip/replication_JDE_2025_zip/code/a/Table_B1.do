/* ============================================================================
   File: Table_B1.do

   Purpose:
       Produce Table B1:
           Differences in baseline characteristics by distress status
           (ttests with means and p-values).

   Output:
       Console output with means by group and p-values (logged or redirected
       as needed for LaTeX table construction).

   Requirements:
       - $clean : folder with cleaned data
       - Dataset: "${clean}/mh_survey_analysis.dta"
         Variables needed:
             female
             age
             d_heterosexual
             year
             gpa_1
             scholarship_full
             scholarship_some
             d_financ_stress
             d_moved
             parent_educ_1
             parent_educ_2
             distress
   ============================================================================ */

use "${clean}/mh_survey_analysis.dta", replace

* Variables derived for this table
gen d_year3andabove      = (year >= 3)
gen d_educ_both_parents  = (parent_educ_1 > 4 & parent_educ_2 > 4)

* Loop over variables and report means by distress and p-value
foreach v in female age d_heterosexual d_year3andabove gpa_1 ///
            scholarship_full scholarship_some d_financ_stress d_moved d_educ_both_parents {
    di as text "=== Variable: `v' ==="
    quietly ttest `v', by(distress)
    di as result "In distress: " %6.2f r(mu_2) ///
                 "   Not in distress: " %6.2f r(mu_1) ///
                 "   p = " %6.3f r(p)
}

exit
