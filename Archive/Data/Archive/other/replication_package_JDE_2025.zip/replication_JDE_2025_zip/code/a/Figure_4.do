/* ============================================================================
   File: Figure_4.do

   Purpose:
       Produce all subfigures of Figure 4:
           - Figure 4a: Distribution of guesses about % of students seeking help
           - Figure 4b: Distribution of guesses by own prior use of help

   Outputs:
       $figures/therapy_use_guess_avg.png
       $figures/therapy_use_guess_by_prior_use_w_avg_by_group.png

   Requirements:
       - $clean   : folder with cleaned data
       - $figures : folder where figures will be saved
       - Dataset: "${clean}/mh_survey_analysis.dta"
         Variables needed:
             guess_therapy_use
             therapy_use_12m
   ============================================================================ */

* ---------------------------------------------------------------------------
* 1. Load data
* ---------------------------------------------------------------------------
use "${clean}/mh_survey_analysis.dta", replace


* ============================================================================
* FIGURE 4a — Average guess vs. true % of students seeking professional help
* ============================================================================
summarize therapy_use_12m
local correct_mean = round(r(mean)*100, 0.1)

summarize guess_therapy_use
local guess_avg = round(r(mean), 0.1)

twoway hist guess_therapy_use, ///
    color(emerald%20) frac start(0) width(10) ///
    legend(off pos(1) ring(0) cols(1)) ///
    ytitle("Students") ylabel(0(0.1)0.22) ///
    xtitle("Guessed % of students who seek prof help") ///
    subtitle(" ", size(small) color(white)) ///
    xline(`correct_mean', lcolor(midgreen%80) lpattern(solid)) ///
    text(0.22 41 "Correct %", color(midgreen%50) size(small) place(e)) ///
    xline(`guess_avg', lcolor(gray%80)) ///
    text(0.22 34 "Average guess %", color(gray%50) size(small) place(w)) ///
    xlabel(, nogrid) ///
    note("Correct share = `correct_mean'% vs. average guess = `guess_avg'% (incentivized).", size(small))

graph export "$figures/therapy_use_guess_avg.png", as(png) replace



* ============================================================================
* FIGURE 4b — Guesses by prior use of professional help (last 12 months)
* ============================================================================
summarize therapy_use_12m
local correct_mean = round(r(mean)*100, 0.1)

summarize guess_therapy_use
local guess_avg = round(r(mean), 0.1)

summarize guess_therapy_use if therapy_use_12m == 0
local guess_no_use = round(r(mean), 0.1)

summarize guess_therapy_use if therapy_use_12m == 1
local guess_use = round(r(mean), 0.1)

twoway (hist guess_therapy_use if therapy_use_12m == 0, ///
            color(gold%50) frac start(0) width(10)) ///
       (hist guess_therapy_use if therapy_use_12m == 1, ///
            color(midblue%20) frac start(0) width(10)), ///
       legend(order(2 "Get Prof Help" 1 "No Prof Help") pos(1) ring(0) cols(1)) ///
       ytitle("Students") ylabel(0(0.1)0.23) ///
       xtitle("Guessed % of students who seek prof help") ///
       subtitle(" ", size(small) color(white)) ///
       xline(`correct_mean', lcolor(midgreen%80) lpattern(solid)) ///
       text(0.23 41 "Correct %", color(midgreen%50) size(small) place(e)) ///
       xline(`guess_use',    lcolor(midblue%80)) ///
       text(0.245 37 "Guess if get help", color(midblue%50) size(small) place(e)) ///
       xline(`guess_no_use', lcolor(orange%70)) ///
       text(0.245 33 "Guess if NO help", color(orange%70) size(small) place(w)) ///
       xlabel(, nogrid) ///
       note("Correct share = `correct_mean'% vs. average guess = `guess_avg'%:" ///
            "Guess among those who have got prof help in the last 12 months = `guess_use'%, " ///
            "who have NOT = `guess_no_use'% (incentivized).", size(small))

graph export "$figures/therapy_use_guess_by_prior_use_w_avg_by_group.png", as(png) replace

exit
