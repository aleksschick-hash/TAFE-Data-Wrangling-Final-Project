/* ============================================================================
   File: Table_8.do

   Purpose:
       Analysis reported in this table is carried out in Python. The code file name is called "Python_Table_8_and_B7.ipynb"
   ============================================================================ */
