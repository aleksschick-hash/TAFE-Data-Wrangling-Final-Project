/*

TO DO BEFORE THIS FILE:
Step 1: RUN: make_mh_survey.do  

Step 3: Run any snippet of a Figure or Table below to produce figures/tables from Appendix (excluding power calculatons, randomization inference). 

*/

/*

LIST OF FIGURES/TABLES (Appendix - excluding power calculatons, randomization inference):

Figure B1  - National Estimates of Anxiety Prevalence (OECD)                
Figure B2  - ENSANUT
Figure B3  - Mental Distress Share by Financial Distress
Figure B4  - Therapy Use Share by Mental Distress Quartile
Figure B5  - Mental Distress Index Distribution by Perceived Support Level
Table  B1  - Comparison of Individual Covariates by Mental Distress           (no code in this file)
Table  B2  - Summary Statistics: Perceived Effectiveness, Support, & Therapy  (no code in this file)
Table  B3  - Belief Accuracy Before and After the Information Intervention    (no code in this file)
Figure B6  - Who Did You Turn for Help?
Figure B7  - CDF: Guesses of Therapy Use by Prior Own Use
Figure B9  - Link Sharing Top Referrers by Treatment Group
Figure B10 - Willingness To Pay for Private Therapy and Donation
Table  B4  - Suggestive Correlations on Interpersonal Projection
Table  B5  - Covariate Balance Among Follow-Up Respondents
Table  B6  - Covariate Balance Across T1, T2, and Control
Table  B7  - Poisson Test Result for Link Clicks
Table  B8  - Effects on Demand for Mental Health Treatments
Table  B9  - TE by Prior Therapy Use (Follow-Up Respondents)
Table  B10 - ATE on Advice
Figure B13 - Quantile Regressions
Table  B11 - Advice Components
Table  B12 - Effects on Personal & Public Stigma-Related Outcomes
Figure B14 - Validity of WTP Measures: Own WTP by Perceived Usefulness
Figure B15 - Robustness of ATE Estimates to WTP Measures
Figure B21 - Heterogeneity by Distress and Professional Help Usage
Figure B22 - Heterogeneity by Incorrect Priors
Figure B23 - TE Heterogeneity for Initial-Survey WTP by Stigma
Figure B24 - TE Heterogeneity on Using Therapy by Baseline Stigma
Figure B25 - TE Heterogeneity on Recommendations by Baseline Stigma
Figure B26 - TE Heterogeneity on Discussing MH Issues (header: Prior Use & GPA)
Figure B27 - Heterogeneous Treatment Effects (by Distress)
Figure B28 - Heterogeneous Treatment Effects (by GPA)
Figure B29 - Heterogeneous Treatment Effects on Stigma Index 1
Table  B16 - Summary Statistics for Stigma Dimensions (Mean & Median Thresholds)
Table  B17 - Summary Statistics for Composite Stigma Indices
Table  B18 - Correlations Between Stigma Dimensions and Composite Indices
Table  B19 - Summary of Composite Stigma Indices by Mental Distress Groups
Table  B20 - T-Test Results for Composite Stigma Indices by Distress Groups
Figure B31 - Main Effects by Mean Stigma Index
Figure B32 - Main Effects by Median Stigma Index
Table  B21 - Correlation of Stigma Index PCA1 & PCA2 with Components
Table  B22 - Summary Statistics for Stigma Variables and PCA Indexes
Table  B23 - Principal Components Analysis Summary
Figure B33 - Screeplot
Table  B24 - Principal Components (Eigenvectors)
Table  B25 - Correlation Matrix of Principal Components
Table  B34 - Loading Plot
Table  B35 - Main Effects by Component 1 Stigma Index
Table  B36 - Main Effects by Component 2 Stigma Index
Figure B37 - Stigma Indices and WTP/Donate (PCA1)
Figure B38 - Stigma Indices and WTP/Donate (PCA2)
Table  B26 - Correlation of Demand Variables with Stigma Indices
Figure B39 - Coefficient Plots: Stigma Indices & Demand
Figure B40 - Stigma & Mental Distress by Financial Stress
Figure B41 - Stigma Index vs Perceived Use of Professional MH Services

*/

set more off

/********************************************************/
/*   Figure B1: National Estimates of Anxiety Prevalence OECD  */
*  
/********************************************************/

* figure is located in the folder oecd_survey file named : OECD_anxiety_prevalence_2023_by_country.xlsx

/********************************************************/
/*   Figure B2: ENSANUT  */

/********************************************************/

/* The following ensanutdb is a 5% stratified subsample (drawn with sample 5, by(estrato) and seed 20231202). For exact replication of the paper, download the full ENSANUT microdata from: [https://www.inegi.org.mx/programas/ensanut/2018/#microdatos]."

Thus results will be distinct from those of the paper
 */

use "${raw}/ENSANUT/ensanut2023_rep_5pct"

/* Keep variables to be used */
keep adult x_region estrato ponde_f completa entidad desc_ent edad sexo a0211 a0212 a0213 a0214 a0215 a0216 a0217 ///
	d0601*
	
/* Unify the depression variables */
replace a0211 = d0601a if adult == 0
replace a0212 = d0601b if adult == 0
replace a0213 = d0601c if adult == 0
replace a0214 = d0601d if adult == 0
replace a0215 = d0601e if adult == 0
replace a0216 = d0601f if adult == 0
replace a0217 = d0601g if adult == 0

order x_region estrato ponde_f completa

/* Make mental health score */
recode a0211 a0212 a0213 a0214 a0215 a0216 a0217 (1=0) (2=1) (3=2) (4=3)

egen mh_score = rowtotal(a0211 a0212 a0213 a0214 a0215 a0216 a0217)

/* Make sample ages indicator */
generate samp_age = (edad >= 17 & edad <= 28)

/* Create distress indicator */
foreach kkk in `=floor((21)/2)' {
	generate distress_`kkk' = (mh_score >= `kkk')

quietly summarize distress_`kkk' [aw = ponde_f], detail
display in red "Sample size is `r(N)'"
local dist_mean = floor(100*r(mean))

/* Nationally representative */
twoway (histogram mh_score if (distress_`kkk' == 0), freq discrete start(0) width(1) color("15 82 186%50")) ///
	(histogram mh_score if (distress_`kkk' == 1), freq discrete start(0) width(1) color(cranberry%50) ///
	xlabel(0(2)22, nogrid labsize(medsmall)) ylabel(, labsize(medsmall)) ///
	xtitle("depression screening score" "higher = worse", size(medsmall)) ///
	ytitle("Respondents", size(medsmall)) text(570 18 "`dist_mean'% above cutoff") ///
	legend(off) )
	
graph export "${figures}/hist_mh_score_ensanut_national_cutoff`kkk'.png", replace


/* National restricted to ages 17-28 to match our sample */
quietly summarize distress_`kkk' if samp_age == 1, detail
display in red "Sample size is `r(N)'"
local dist_mean = floor(100*r(mean))

twoway (histogram mh_score if (distress_`kkk' == 0 & samp_age == 1), freq discrete start(0) width(1) color("15 82 186%50")) ///
	(histogram mh_score if (distress_`kkk' == 1 & samp_age == 1), freq discrete start(0) width(1) color(cranberry%50) ///
	xlabel(0(2)22, nogrid labsize(medsmall)) ylabel(, labsize(medsmall)) ///
	xtitle("depression screening score" "higher = worse", size(medsmall)) ///
	ytitle("Respondents", size(medsmall)) text(115 18 "`dist_mean'% above cutoff") ///
	legend(off) )
	
graph export "${figures}/hist_mh_score_ensanut_national_uniage_cutoff`kkk'.png", replace
}

/********************************************************/
/*   Figure B3 Mental Distress Share by Financial Disress   */

/********************************************************/
use "${clean}/mh_survey_analysis.dta" , replace 

	* distress by fin stress 
	graph bar  distress , over(financial_stress)   ///
				horizontal   bar(1 , color(lavender%50) )  bar(2 , color(purple%50) )    ///
				legend(label(1 "% in Distress") pos(6) row(1))    ///
 				ytitle("Share in mental distress")
			
			graph export  "${figures}/distress_by_financial_stress.png" , replace 
	

/********************************************************/
/*   Figure B4 Therapy Use Share by Mental Distress Quartile */

/********************************************************/
/* Show distribution of seeking help by mental health score -> could give a 
fuller picture of the treatment gap/mech relationship, especially if large 
% of non-distress students are seeking help */
fastxtile mh_score_quartile = mh_score, nquantiles(4)

forvalues qqq = 1/4 {
	quietly summarize mh_score if mh_score_quartile == `qqq', detail
	local minscore_`qqq' = r(min)
	local maxscore_`qqq' = r(max)
}

estimates clear
eststo : regress therapy_use_12m ibn.mh_score_quartile, robust noconstant
coefplot (est1, color(navy%70) drop(4.mh_score_quartile)) ///
	(est1, color(cranberry%70) keep(4.mh_score_quartile)), ///
	graphregion(color(white)) xlabel(0.0(0.1)0.6, angle(h) nogrid) horizontal ///
	ylabel(1 "Q1: score {&isin} [`minscore_1', `maxscore_1']" ///
	2 "Q2: score {&isin} [`minscore_2', `maxscore_2']" ///
	3 "Q3: score {&isin} [`minscore_3', `maxscore_3']" ///
	4 "Q4: score {&isin} [`minscore_4', `maxscore_4']") yscale(lstyle(none)) ///
	recast(bar) ///
	barwidth(0.2) ///
	ciopts(recast(rcap) lcolor(black) lwidth(vthin)) citop format(%9.2f) scale(1.25) ///
	xtitle("probability of going to" "therapy in last 12 months") ytitle("Mental Health Score" "Distress if Score > 12") ///
	legend(off)
graph export "${figures}/dist_th_use_by_mhscore.png", replace



/********************************************************/
/*   Figure B5 Mental Distress Index Distribution by Perceived Support Level  */

/********************************************************/
	
twoway ( histogram mh_score if  mh_score <  12 , lcolor(navy%20)  fcolor(ebg%80) 	freq start(0)  width(2) )  || ///
		 histogram mh_score if  mh_score >= 12 , color(purple%40)					freq start(12) width(2)  ///, 
											by(support_amount, note("`support_options'", size(vsmall))    legend(off)   ///
											title("Student Distribution by Mental Health Support Level", size(medium)) row(3) )  ///
											 /* percent discrete  xrescale */   ///
											ysize(10) xsize(8)  xline(12, lcolor(purple%40)) ///
											subtitle(, fcolor(ltblue*0.2)) xlabel(0(2)26, nogrid)  ///
											ytitle("Students")  ///
											xtitle("Mental Distress Score (higher = worse)", size(medsmall))    
									
	graph export "$figures/mh_score_distribution_by_support_vertical.png", as(png)  replace 

	
	
/********************************************************/
/*   Table B1. Comparison of Individual Covariates by Mental Distress */

/********************************************************/


use "${clean}/mh_survey_analysis.dta", clear

gen d_educ_both_parents = (parent_educ_1 > 4 & parent_educ_2  > 4)
gen d_year3andabove = (year>=3)

foreach v in female age d_heterosexual d_year3andabove gpa_1 scholarship_full scholarship_some d_financ_stress d_moved d_educ_both_parents {
    di as text "=== Variable: `v' ==="
    quietly ttest `v', by(distress)
    di as result "In distress: " %6.4f r(mu_2) "   Not in distress: " %6.4f r(mu_1) "   p = " %6.3f r(p)
}



/********************************************************/
/*   Table B2. Summary Statistics: Perceived Effectiveness, Support, and Therapy Use     */

/********************************************************/

/********************************************************/
/*   Table B3. Belief accuracy before and after the information intervention     */

/********************************************************/

gen d_incorr_poster_1 = (t1_info_a == 0 | t2_info_a == 0)
gen d_incorr_poster_2 = (t1_info_b == 0 | t2_info_b == 0)
gen d_incorr_poster_3 = (t1_info_c == "worse" | t2_info_c == "worse")


sum d_incorr_prior_1_effective d_incorr_prior_2_mild_moder d_incorr_prior_3_gpa d_incorr_poster_1 d_incorr_poster_2 d_incorr_poster_3  if treat_any == 1



/********************************************************/
/*   Figure B6. Who did you turn for help?     */

/********************************************************/

* Clean 'whom_turned_for_help' var
gen turned_to_mh_prof_at_uni = (strpos(whom_turned_for_help, "professionals at your university") > 0)
label variable turned_to_mh_prof_at_uni "MH professionals at uni"

gen turned_to_mh_prof_outside_uni 		 = (strpos(whom_turned_for_help, "professionals outside of your university") > 0)
label variable turned_to_mh_prof_outside_uni "MH professionals outside uni"

gen turned_to_faculty = (strpos(whom_turned_for_help, "faculty members") > 0)
label variable turned_to_faculty "Faculty"

gen turned_to_staff = (strpos(whom_turned_for_help, "staff members") > 0)
label variable turned_to_staff "Program staff"

gen turned_to_family = (strpos(whom_turned_for_help, "Family") > 0)
label variable turned_to_family "Family"

gen turned_to_friends_at_uni = (strpos(whom_turned_for_help, "Friends at university") > 0)
label variable turned_to_friends_at_uni "Friends at uni"

gen turned_to_friends_outside_uni = (strpos(whom_turned_for_help, "Friends outside") > 0)
label variable turned_to_friends_outside_uni "Friends outside uni"

gen turned_to_no_one = (strpos(whom_turned_for_help, "Did not turn") > 0)
label variable turned_to_no_one "Did not turn to anyone"

gen turned_to_no_one_no_issues = (strpos(whom_turned_for_help, "Did not have") > 0)
label variable turned_to_no_one_no_issues "Did not have MH issues"

* Graph
tabstat  turned_to_*   , ///
				varwidth(35)  columns(statistics)   stat(mean sd  min  max  count)   ///
				format(%12.3fc)
				
				
graph bar (mean) turned_to_*      /// 
			, intensity(*0.3) nolabel ///
			ytitle("Proportion of students",  size(medium) height(10) )   /// 
			title("                              If experienced MH challenges in last 12 months, to whom did you turn for help?", size(medium) ) ///
			legend(label(1 "Prof. help at uni") ///
       label(2 "Prof. help outside uni") ///
       label(3 "Faculty") ///
       label(4 "Program staff") ///
       label(5 "Family") ///
       label(6 "Friends at uni") ///
       label(7 "Friends outside uni") ///
       label(8 "Did not turn to anyone") ///
       label(9 "Did not have MH issues") ///
       textwidth(65)) ///
       $bar_colors6
graph export "$figures/whom_turned_for_help.png", as(png)  replace 


/********************************************************/
/*   Figure B7. CDF plot - guesses of therapy use by prior own use    */

/********************************************************/

*** address_comments_jan102025_gsrs.do ***
// ks is biased in finite samples but 600 ish is somewhat ok I guess
ksmirnov guess_therapy_use, by(therapy_use_12m)
local pval_ks = round(r(p), 0.001)
local diff_ks = round(r(D), 0.001)

distplot guess_therapy_use, over(therapy_use_12m) lcolor(dkorange%80 navy%80) lwidth(medthick medthick) ///
	ylabel(, labsize(medium)) xlabel(, labsize(medium)) ytitle(, size(medium)) ///
	xtitle("guess # of every 100 students in your" "university who have used MH services", size(medium)) ///
	legend(order(1 "No therapy use in last 12 months" 2 "Used therapy in last 12 months") ///
		pos(5) row(2) ring(0) region(lcolor(gs10)) size(medsmall)) text(0.29 74.8 "Kolmogorov-Smirnov Test statistic: 0`diff_ks'", size(medsmall)) ///
		text(0.23 77.5 "Kolmogorov-Smirnov Test {it:p} = `: display %4.3fc `pval_ks''", size(medsmall))
graph export "${figures}/cdf_guess_th_use_by_own_usage.png", replace


/********************************************************/
/*   Figure B9. Link Sharing Top Referrers by Treatment Group    */
* 
/********************************************************/	

*image is from a screenshot, no code was used to produce this 

/********************************************************/
/*   Figure B10. Willingness To Pay for Private Therapy and Donation    */

/********************************************************/	

global outcomes_4pct   		"wtp_therapy_pct_self  		wtp_therapy_pct_friend  donation_pct   adv_prof_help_any   "  

		local  i = 1
		
		foreach outcome of global outcomes_4pct {
			
			eststo basemod`i' , title("`outcome'") :  ///
				reg `outcome' i.incorr_priors_4g##i.treat_any  ,  r
						
			local i = `i' + 1
				
			}
		
		* only coefficients for lower outcomes by incorr priors for controls (descriptive result)
		
		
			coefplot  	(basemod1  ,  mcolor(pink%60)    ciopts(lc(pink%60))    drop(*1.treat_any*       _cons female )  label(Control)  )			///
										, bylabel("WTP Self" )   ||  ///
						(basemod2  ,  mcolor(pink%60)    ciopts(lc(pink%60))    drop(*1.treat_any*       _cons female )  label(Control)  )		    ///
										, bylabel("WTP Friend" )   ||  ///
						(basemod3  ,  mcolor(pink%60)    ciopts(lc(pink%60))    drop(*1.treat_any*       _cons female )  label(Control)  )			///
										, bylabel("Donation %" )   ||  ///
									, 	///
									xline(0, lcolor(purple%50))   ylabel(, labsize(small)) ///
									ci(90)  ciopts(recast(rcap))  ///
									xscale( range(-0.25  0.15) )   xlabel(-0.2(0.1)0.1 , labsize(small))    ///
									grid(none)  ///
									byopts( rows(1) imargin(tiny) legend(off)  ///
											title("Average WTP & Donations by Prior Beliefs",  size(medsmall) )  ///
											note("90% CI. All coefficient values are relative to the students with both priors correct (control group only). "  ///
												 "Students by incorrect priors: N both correct = 22, N incorr 2 = 15, N incorr 3 = 95, N both incorr = 100." ///
												 , size(small)) )  

				graph export "${figures}/coefplot_base_demand_by_priors_X_3outcomes_combined.png", replace 

/********************************************************/
/*   Table B4. Suggestive Correlations on Interpersonal Projection    */


/********************************************************/	

des  	d_self_stigma   open_to_share   therapy_use_12m  
	
		label var d_self_stigma    "Self-stigma (feels disappointed if MH issue)"
		label var open_to_share    "Open to share MH challenges with classmates"
		label var therapy_use_12m  "Used therapy in the last 12m"
	
	tab1  	d_self_stigma   open_to_share   therapy_use_12m  
	
	sum  guess_self_stigma_pct   guess_open_to_share_pct    guess_therapy_use_pct  
	
	sum  d_self_stigma  guess_self_stigma_pct   
	
	sum   d_self_stigma   	guess_self_stigma_pct   	
	sum   open_to_share    	guess_open_to_share_pct 	
	sum   therapy_use_12m  	guess_therapy_use_pct  		
	
		
		eststo  proj1, title("Guess of \%: w Self Stigma") :  reg guess_self_stigma_pct   	d_self_stigma , r
																					estadd ysumm
	
		eststo  proj2, title("Open to Share") :  reg guess_open_to_share_pct 	open_to_share , r
																					estadd ysumm
																			
		eststo  proj3, title("Using Therapy") :  reg guess_therapy_use_pct  		therapy_use_12m  , r
																					estadd ysumm
		
			
		xi: esttab  proj?  ///
						using "${tables}\reg_guess_project_bias.tex", 	///
						cells(b(star fmt(%9.3f)) se(par fmt(%9.3f)))  starlevels(* 0.1 ** 0.05  *** 0.01)   		///
						stats(N   ymean ysd  /* r2_a F */ , fmt( %9.0gc   %9.3f %9.2f )   	///
						labels( Observations  "Mean dep var"  "Std dev dep var"   ))   	///
						/* keep( *treat*  )   order(*treat*  )  */ 	/// 
						varwidth(30) label wrap depvars mtitle /* mtitles( ChgLnPop )  */ 			 ///
						/*  indicate(  /*     */ , labels("$\checkmark$") ) */  ///
						collabel(none)  ///
						 /* collabel(`dist1'km  `dist1'km  `dist1'km  `dist2'km  `dist2'km  `dist2'km  `dist3'km  `dist3'km  `dist3'km) */    ///
						/* mgroups("Willingness to Pay/Donate"  "Advice to a Friend"  "Social Stigma v Students" , pattern(1 0  0  1  0  1  0) */   /// 
						/* prefix(\multicolumn{@span}{c}{) suffix(})  span erepeat(\cmidrule(lr){@span})) */   /// 
						title("Suggestive Correlations on Interpersonal Projection Bias \label{tab:reg_proj_bias} "  /*  */  )  ///
						substitute({l} {p{0.989\linewidth}})  /// 
						addnotes("The table reports the coefficient on the belief indicator (self-stigma, openness to share) or therapy use in a regression of incentivized guesses of the prevalence of each belief/behavior among survey respondents. The coefficient captures to what extent holding a personal belief (self-stigma or being open to share problems with other students) or using therapy is associated with assuming that more students hold the same beliefs or engage in the same behavior. The constant term reflects the guess percentage among those who do not hold the belief/engage in the behavior.    Robust S.E.  *** 1\%, ** 5\%, * 10\% significant.") ///
						replace
		
		

/********************************************************/
/*   Table B5. Covariate Balance among Followup Respondents   */

/********************************************************/	

/* Read in urvey dataset */
use "${clean}/mh_survey_analysis_w_followup.dta" , replace 

/* Label variables for appearance on tables */
label variable age "Age"
label variable female "Female"
label variable d_financ_stress "Financially Stressed"
label variable scholarship_some "Has Scholarship"
label variable d_moved "Moved Residence"
label variable gpa_1 "GPA"
label variable mh_score "MH Score"
label variable therapy_use_12m "Used Therapy L12 Months"
label variable open_to_share "Open to Share MH Challenges"
label variable d_self_stigma "Self-stigmatize"


/* Balance for Control v Any Treatment in Followup */
preserve
iebaltab age female d_financ_stress scholarship_some scholarship_full d_moved gpa_1 mh_score therapy_use_12m open_to_share d_self_stigma if took_classes_2025 == 1, ///
	replace savetex("${tables}/balance_control_treat_followup.tex") vce(robust) groupvar(treat_any) ///
	starlevels(0.1 0.05 0.01) stats(desc(sd) pair(diff)) format(%4.3fc) ///
	rowvarlabels nonote browse  
restore

/********************************************************/
/*  Table B6. Covariate Balance across T1 T2 C   */

/********************************************************/	

/* Label variables for appearance on tables */
label variable age "Age"
label variable female "Female"
label variable d_financ_stress "Financially Stressed"
label variable scholarship_some "Has Scholarship"
label variable d_moved "Moved Residence"
label variable gpa_1 "GPA"
label variable mh_score "MH Score"
label variable therapy_use_12m "Used Therapy L12 Months"
label variable open_to_share "Open to Share MH Challenges"
label variable d_self_stigma "Self-stigmatize"

preserve
iebaltab age female d_financ_stress scholarship_some scholarship_full d_moved gpa_1 mh_score therapy_use_12m open_to_share d_self_stigma, ///
	replace savetex("${tables}/balance_control_t1_t2_paper.tex") vce(robust) groupvar(treatm_group) ///
	starlevels(0.1 0.05 0.01) stats(desc(sd) pair(diff)) format(%4.3fc) ///
	rowvarlabels nonote browse  
restore

/********************************************************/
/*   Table B7. Poisson Test Result for Link Clicks   */

/********************************************************/	

/********************************************************/
/*   Table B8. Effects on Demand for Mental Health Treatments     */

/********************************************************/	


global control_sample_base     "treat_any == 0"
global control_sample_followup "treat_any == 0 & took_classes_2025 == 1"

global y_base_7pct_winz "winz_wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct adv_prof_help_any adv_campus_prof_help pref_mh_symp_v_low_gpa pref_mh_talk_v_low_gpa"



foreach var of global y_base_7pct_winz {
	
	local y_lbl = subinstr("`var'", "_", " ", .)
	local y_lbl = proper("`y_lbl'")
	local y_lbl = subinstr("`y_lbl'", "Wtp", "WTP", .)
	local y_lbl = subinstr("`y_lbl'", "Pct", "%", .)
	local y_lbl = subinstr("`y_lbl'", "Mh", "MH", .)
	local y_lbl = subinstr("`y_lbl'", "Gpa", "GPA", .)

	eststo `var'0, title("`y_lbl'"): reg `var' treat_any, r
	quietly sum `var' if ${control_sample_base}, detail
	estadd scalar ymean = r(mean)
	estadd scalar ysd   = r(sd)
}

foreach var of global y_base_7pct_winz {
	
	local y_lbl = subinstr("`var'", "_", " ", .)
	local y_lbl = proper("`y_lbl'")
	local y_lbl = subinstr("`y_lbl'", "Wtp", "WTP", .)
	local y_lbl = subinstr("`y_lbl'", "Pct", "%", .)
	local y_lbl = subinstr("`y_lbl'", "Mh", "MH", .)
	local y_lbl = subinstr("`y_lbl'", "Gpa", "GPA", .)

	eststo `var'1, title("`y_lbl'"): reg `var' treat_any if in_sample == 1, r
	quietly sum `var' if ${control_sample_followup}, detail
	estadd scalar ymean = r(mean)
	estadd scalar ysd   = r(sd)
}



	eststo followup_therapy_use , title("Any"):  ///
			reg  followup_therapy_use  treat_any  if in_sample == 1  , r
																estadd ysumm
	
			
		xi: esttab    winz_wtp_therapy_pct_self0    wtp_therapy_pct_friend0    winz_wtp_therapy_pct_self1    wtp_therapy_pct_friend1    followup_therapy_use   ///
						using "${tables}\reg_mh_demand_any.tex", 	///
						cells(b(star fmt(%9.3f)) se(par fmt(%9.3f)))  starlevels(* 0.1 ** 0.05  *** 0.01)  nocons  		///
						stats( ymean   ysd  N  /* r2_a F */ , fmt( %9.3f %9.2f  %9.0gc )   	///
						labels( "Control Mean"  "Control SD"  Observations   ))   	///
						keep( *treat*  )    	///     /* width(.86\hsize)    keep(*migrant* *Sim* ln_* )  */   	///
						order(*treat*  )  	/// 
						varwidth(35) label wrap depvars mtitle /* mtitles( ChgLnPop )  */ 			 ///
						/*  indicate(  /*     */ , labels("$\checkmark$") ) */  ///
						collabel(none)  ///
						mgroups("SR: WTP Therapy ($ N = 680$)"  "SR: WTP Therapy ($ N = 320$)"  "LR: Used Therapy (6m)", pattern(1 0  1 0  1 )    /// 
						prefix(\multicolumn{@span}{c}{) suffix(})  span erepeat(\cmidrule(lr){@span})) /// 
						 /* collabel(`dist1'km  `dist1'km  `dist1'km  `dist2'km  `dist2'km  `dist2'km  `dist3'km  `dist3'km  `dist3'km) */    ///
						title("Effects on Demand for Mental Health Treatments   \label{tab:reg_followup_wtp_w_therapy_use} "  /*  */  )  ///
						substitute({l} {p{0.989\linewidth}})  /// 
						addnotes("\scriptsize Sample includes \textbf{all} respondents in col 1-2, only followup respondents who took classes in 2025 in cols 3-6. Robust S.E.  *** 1\%, ** 5\%, * 10\% significant. SR = Short-run (measured in the baseline survey experiment). LR = Long-run (measured in the 6-month followup survey). ") ///
						replace
		
/********************************************************/
/*   Tale B9. TE by Prior Therapy Use (Followup Respondents)    */

/********************************************************/	
						
capture which esttab
if _rc ssc install estout, replace


global control_sample_followup "treat_any == 0 & took_classes_2025 == 1"

eststo clear

eststo wtp_self_by_use,    title("WTP Self"): ///
    reg winz_wtp_therapy_pct_self  ///
        1.treat_any#1.therapy_use_12m  1.treat_any#0.therapy_use_12m  1.therapy_use_12m ///
        if took_classes_2025 == 1, r
    quietly sum winz_wtp_therapy_pct_self if ${control_sample_followup}, detail
    estadd scalar ymean = r(mean)
    estadd scalar ysd   = r(sd)

eststo wtp_friend_by_use,  title("WTP Friend"): ///
    reg wtp_therapy_pct_friend ///
        1.treat_any#1.therapy_use_12m  1.treat_any#0.therapy_use_12m  1.therapy_use_12m ///
        if took_classes_2025 == 1, r
    quietly sum wtp_therapy_pct_friend if ${control_sample_followup}, detail
    estadd scalar ymean = r(mean)
    estadd scalar ysd   = r(sd)

eststo used_mh_on_camp_by_use,  title("On Campus"): ///
    reg used_mh_on_campus ///
        1.treat_any#1.therapy_use_12m  1.treat_any#0.therapy_use_12m  1.therapy_use_12m ///
        if took_classes_2025 == 1, r
    quietly sum used_mh_on_campus if ${control_sample_followup}, detail
    estadd scalar ymean = r(mean)
    estadd scalar ysd   = r(sd)

eststo used_mh_off_camp_by_use, title("Off Campus"): ///
    reg used_mh_off_campus ///
        1.treat_any#1.therapy_use_12m  1.treat_any#0.therapy_use_12m  1.therapy_use_12m ///
        if took_classes_2025 == 1, r
    quietly sum used_mh_off_campus if ${control_sample_followup}, detail
    estadd scalar ymean = r(mean)
    estadd scalar ysd   = r(sd)

eststo recomm_on_by_use,   title("On Campus"): ///
    reg recommend_mh_on_campus ///
        1.treat_any#1.therapy_use_12m  1.treat_any#0.therapy_use_12m  1.therapy_use_12m ///
        if took_classes_2025 == 1, r
    quietly sum recommend_mh_on_campus if ${control_sample_followup}, detail
    estadd scalar ymean = r(mean)
    estadd scalar ysd   = r(sd)

eststo recomm_off_by_use,  title("Off Campus"): ///
    reg recommend_mh_off_campus ///
        1.treat_any#1.therapy_use_12m  1.treat_any#0.therapy_use_12m  1.therapy_use_12m ///
        if took_classes_2025 == 1, r
    quietly sum recommend_mh_off_campus if ${control_sample_followup}, detail
    estadd scalar ymean = r(mean)
    estadd scalar ysd   = r(sd)
						
						///
					xi: esttab wtp_self_by_use  wtp_friend_by_use  used_mh_on_camp_by_use   used_mh_off_camp_by_use   recomm_on_by_use   recomm_off_by_use    ///
									using "${tables}\reg_heterogen_wtp_w_followup_therapy_use_BY_prior_use.tex", 	///
									cells(b(star fmt(%9.3f)) se(par fmt(%9.3f)))  starlevels(* 0.1 ** 0.05  *** 0.01)    		///
									stats( ymean   ysd  N  /* r2_a F */ , fmt( %9.3f %9.2f  %9.0gc )   	///
									/*   coeflabels(_cons  "Control# No Help (Mean)")   */   ///
									labels( "Control Mean"  "Control SD"  Observations   ))   	///
									 	///     /*  keep( *treat*  )    width(.86\hsize)    keep(*migrant* *Sim* ln_* )  */   	///
									order(*treat*  )  	/// 
									varwidth(35) label wrap depvars mtitle /* mtitles( ChgLnPop )  */ 			 ///
									/*  indicate(  /*     */ , labels("$\checkmark$") ) */  ///
									collabel(none)  ///
									 /* collabel(`dist1'km  `dist1'km  `dist1'km  `dist2'km  `dist2'km  `dist2'km  `dist3'km  `dist3'km  `dist3'km) */    ///
									mgroups("SR: WTP for Therapy"  "LR: Therapy Use"  "LR: Recommend Therapy", pattern(1 0  1 0  1 0 )    /// 
									prefix(\multicolumn{@span}{c}{) suffix(})  span erepeat(\cmidrule(lr){@span})) /// 
									title("TE by Prior Therapy Use (Follow-Up Respondents) \label{tab:reg_wtp_w_therapy_by_prior_use} "  /*  */  )  ///
									substitute({l} {p{0.989\linewidth}})  /// 
									addnotes("\scriptsize Sample includes \textbf{all} follow-up respondents still enrolled in 2025. Robust S.E.  *** 1\%, ** 5\%, * 10\% significant.") ///
									replace
									
/********************************************************/
/*   Tale B10. ATE on Advice   */

/********************************************************/	


use "${clean}/mh_survey_analysis_w_followup.dta" , replace 

	label var  treat_any  "Treated"
	
	
	/*  Extra Advice Variables  */
	
	/* Indicators for whether some stuff was mentioned in the advice */
	generate adv_d_listen = (strpos(advice, "escucha") > 0 | strpos(advice, "escucho") > 0 | strpos(advice, "listen") > 0)
		
	generate adv_d_be_attentive = (strpos(advice, "estar al pendiente") > 0 | strpos(advice, "estoy aqui") > 0 | ///
		strpos(advice, "contar conmigo") > 0 | strpos(advice, "estoy para") > 0 | ///
		strpos(advice, "no estas sol") > 0 | strpos(advice, "no esta sol") > 0 | strpos(advice, "estoy siempre para") > 0 | ///
		strpos(advice, "estoy ahi") > 0 | strpos(advice, "cuentas con") > 0 | strpos(advice, "estare aqui") > 0 | ///
		strpos(advice, "I am there") > 0 | strpos(advice, "para ti") > 0) | ///
		(strpos(advice, "i am here") > 0 | strpos(advice, "i'm here") > 0 | strpos(advice, "for them") > 0 | ///
		strpos(advice, "for her") > 0 | strpos(advice, "for him") > 0 | strpos(advice, "for you") > 0)
		
	generate adv_d_empathy = (strpos(advice, "empatia") > 0 | strpos(advice, "empatica") > 0 | strpos(advice, "empatizar") > 0 | ///
		strpos(advice, "comprendid") > 0 | strpos(advice, "entiendo") > 0 | strpos(advice, "valid") > 0 | ///
		(strpos(advice, "cuenta") > 0 & strpos(advice, "apoyo") > 0)) | (strpos(advice, "empath") > 0) | ///
		strpos(advice, "understood") > 0
		
	generate adv_d_ok2feelbad = (strpos(advice, "no") > 0 & strpos(advice, "malo sentirte mal") > 0 | ///
		strpos(advice, "normal no sentirse bien") > 0 | strpos(advice, "es completamente normal") > 0)
		
	generate adv_d_support = (strpos(advice, "te apoyo") > 0 | strpos(advice, "tiene mi apoyo") > 0 | ///
		strpos(advice, "los quiero") > 0 | strpos(advice, "te quiero") > 0 | strpos(advice, "tienes mi apoyo") > 0 | ///
		strpos(advice, "support") > 0 | strpos(advice, "contigo") > 0 | strpos(advice, "aqui estoy") > 0) | ///
		(strpos(advice, "i am here") > 0 | strpos(advice, "i'm here") > 0)
		
	/* Passive count */
	generate adv_passive_share = (adv_d_listen + adv_d_be_attentive + adv_d_empathy + adv_d_ok2feelbad + adv_d_support) / 5
		
	* get a passive advice 
	generate advice_passive_any = (adv_passive_share > 0) 

		label var adv_passive_share  "\% of passive advice indicators (out of 5)"
		
		label var adv_passive_share  "Any passive advice indicator"
		
		
	/* Family: Suggestive help */
	generate adv_d_opinion = (strpos(advice, "opinion") > 0 | strpos(advice, "consejo") > 0 | strpos(advice, "what to do") > 0 | ///
		strpos(advice, "recomiendo") > 0 | strpos(advice, "deberia") > 0 | strpos(advice, "mi experiencia") > 0) | ///
		strpos(advice, "advice") > 0 | strpos(advice, "recommend") > 0 | strpos(advice, "my experience") > 0

	generate adv_d_seekhelp = ((strpos(advice, "busca") > 0 | strpos(advice, "busque")) & ///
		(strpos(advice, "ayuda") > 0 | strpos(advice, "apoyo") > 0) | strpos(advice, "referenciaria") > 0 | ///
		(strpos(advice, "seek") > 0 & strpos(advice, "support") > 0) | (strpos(advice, "refer") > 0) | ///
		strpos(advice, "profesional") > 0 | strpos(advice, "find resources") > 0) // Note the "&" for the whole condition
		
	generate adv_d_therapy = (strpos(advice, "terapia") > 0 | strpos(advice, "psicolog") > 0 | ///
		strpos(advice, "consejer") > 0) | strpos(advice, "therapy") > 0 | strpos(advice, "psychologist") > 0 | ///
		strpos(advice, "counseling") > 0

	generate adv_d_dostuff_liked = (strpos(advice, "hacer algo") > 0 & strpos(advice, "disfrut") > 0) | ///
		(strpos(advice, "actividades") > 0 & strpos(advice, "gusten") > 0) | ///
		(strpos(advice, "do stuff") > 0 & strpos(advice, "like") > 0) | strpos(advice, "activities") > 0

	/* Suggestive count */	
	generate adv_sugg_share = (adv_d_opinion + adv_d_seekhelp + adv_d_therapy + adv_d_dostuff_liked)/4
		
		generate any_suggestive = (adv_sugg_share > 0)

		

		/* Regression of shares but with the any help + passive + suggestive  */
		estimates clear 
		local sss = 0
		local ppp = 0
		foreach outcome of varlist adv_campus_prof_help adv_prof_help_any adv_passive_share adv_sugg_share {
			/* Pooled treatments */
			local ++ppp
			eststo p`ppp' : regress `outcome' 1.treat_any, robust
			quietly summarize `outcome' if treat_any == 0, detail
			estadd scalar ymean = r(mean)
			/* Split treatments */
			local ++sss
			eststo s`sss' : regress `outcome' ib0.treatm_group, robust
			quietly summarize `outcome' if treatm_group == 0, detail
			estadd scalar ymean = r(mean)
		} 

		esttab p1 p2 p3 p4 s1 s2 s3 s4 ///
			using "${tables}/advice_shares_w_anyhelp_upd.tex",   replace   booktabs   nonotes ///
			mtitles("\shortstack{Campus\\Help}" 		"\shortstack{Any Prof.\\Help}" ///
					"\shortstack{Passive\\Advice}" 		"\shortstack{Suggestive\\ Advice}" ///
					"\shortstack{Campus\\Help}" 		"\shortstack{Any Prof.\\Help}"    ///
					"\shortstack{Passive\\ Advice}"  	"\shortstack{Suggestive\\Advice}"   ) ///
			b(3) se(3) star(${star}) keep(1.treatm_group 2.treatm_group 1.treat_any) ///
			coeflabels(1.treatm_group "Info + Reflection" 2.treatm_group "Info Only" 1.treat_any "Any Treatment") ///
			stats(N r2 ymean, labels("Observations" "R2" "Control Mean") fmt(0 3 3))	
		
/********************************************************/
/*   Figure B13. Quantile Regressions    */

/********************************************************/	


/* Read in dataset */
use "${clean}/mh_survey_analysis.dta" , replace 

/* Quantile regression for quartiles of WTP Self */

foreach outcome of varlist wtp_therapy_pct_self wtp_therapy_pct_friend  {
	estimates clear
	if strpos("`outcome'", "self") {
		local plotname = "wtpself"
	}
	else if strpos("`outcome'", "friend") {
		local plotname = "wtpfriend"
	}
	else {
		local plotname = "donation"
	}
	local ppp = 0
	/* Loop over quartiles */
	foreach qqq in 0.25 0.5 0.75 0.99 {
		/* Add one to model counter */
		local ++ppp
		/* Estimate model */
		eststo m`ppp' : qreg `outcome' 1.treat_any, quantile(`qqq')
	}
	coefplot m?, drop(_cons) ///
	xline(0, lpattern(shortdash) lwidth(thin) lcolor(black)) ///
	legend(order(2 "p25" 4 "p50" 6 "p75" 8 "p99") title("Quantiles", size(small)) ///
		pos(2) col(1) ring(0) region(lcolor(gs10))) xlabel(-0.15(0.03)0.15, labsize(medium)) ///
		yscale(noline) level(90)
	graph export "${figures}/quantreg_`plotname'.pdf", replace
}
/********************************************************/
/*   Table B11. Advice Components    */

/********************************************************/	
use  "${clean}/mh_survey_analysis_w_followup.dta" , replace 

*use "${clean}/mh_survey_analysis.dta" , replace 

/* Remove accents from advice wording */
replace advice = lower(advice)
replace advice = subinstr(advice, "á", "a", .)
replace advice = subinstr(advice, "é", "e", .)
replace advice = subinstr(advice, "í", "i", .)
replace advice = subinstr(advice, "ó", "o", .)
replace advice = subinstr(advice, "ú", "u", .)

/* Indicators for whether some stuff was mentioned in the advice */
generate adv_d_listen = (strpos(advice, "escucha") > 0 | strpos(advice, "escucho") > 0 | strpos(advice, "listen") > 0)
	
generate adv_d_be_attentive = (strpos(advice, "estar al pendiente") > 0 | strpos(advice, "estoy aqui") > 0 | ///
	strpos(advice, "contar conmigo") > 0 | strpos(advice, "estoy para") > 0 | ///
	strpos(advice, "no estas sol") > 0 | strpos(advice, "no esta sol") > 0 | strpos(advice, "estoy siempre para") > 0 | ///
	strpos(advice, "estoy ahi") > 0 | strpos(advice, "cuentas con") > 0 | strpos(advice, "estare aqui") > 0 | ///
	strpos(advice, "I am there") > 0 | strpos(advice, "para ti") > 0) | ///
	(strpos(advice, "i am here") > 0 | strpos(advice, "i'm here") > 0 | strpos(advice, "for them") > 0 | ///
	strpos(advice, "for her") > 0 | strpos(advice, "for him") > 0 | strpos(advice, "for you") > 0)
	
generate adv_d_empathy = (strpos(advice, "empatia") > 0 | strpos(advice, "empatica") > 0 | strpos(advice, "empatizar") > 0 | ///
	strpos(advice, "comprendid") > 0 | strpos(advice, "entiendo") > 0 | strpos(advice, "valid") > 0 | ///
	(strpos(advice, "cuenta") > 0 & strpos(advice, "apoyo") > 0)) | (strpos(advice, "empath") > 0) | ///
	strpos(advice, "understood") > 0
	
generate adv_d_ok2feelbad = (strpos(advice, "no") > 0 & strpos(advice, "malo sentirte mal") > 0 | ///
	strpos(advice, "normal no sentirse bien") > 0 | strpos(advice, "es completamente normal") > 0)
	
generate adv_d_support = (strpos(advice, "te apoyo") > 0 | strpos(advice, "tiene mi apoyo") > 0 | ///
	strpos(advice, "los quiero") > 0 | strpos(advice, "te quiero") > 0 | strpos(advice, "tienes mi apoyo") > 0 | ///
	strpos(advice, "support") > 0 | strpos(advice, "contigo") > 0 | strpos(advice, "aqui estoy") > 0) | ///
	(strpos(advice, "i am here") > 0 | strpos(advice, "i'm here") > 0)
	
/* Passive count */
generate adv_passive_share = (adv_d_listen + adv_d_be_attentive + adv_d_empathy + adv_d_ok2feelbad + adv_d_support)/5

			
			reg adv_prof_help_any   adv_passive_share if adv_passive_share < 0.8 
			
			
			eststo adv_reg1, title("All"): 		 reg  adv_passive_share  treat_any , r
																					estadd ysumm 
			eststo adv_reg2, title("Excl 1"):  	 reg  adv_passive_share  treat_any if adv_passive_share < 1, r
																					estadd ysumm 
			eststo adv_reg3, title("Excl 0.8"):  reg  adv_passive_share  treat_any if adv_passive_share < 0.8, r
																					estadd ysumm 
		
			eststo adv_reg4, title("All"): 		 reg  adv_campus_prof_help  treat_any , r
																					estadd ysumm 
			eststo adv_reg5, title("Excl 1"):  	 reg  adv_campus_prof_help  treat_any if adv_passive_share < 1, r
																					estadd ysumm 
			eststo adv_reg6, title("Excl 0.8"):  reg  adv_campus_prof_help  treat_any if adv_passive_share < 0.8, r
																					estadd ysumm 

			eststo adv_adv1, title("All"): 		 reg  adv_campus_prof_help  adv_passive_share , r
																					estadd ysumm 
			eststo adv_adv2, title("Excl 1"):  	 reg  adv_campus_prof_help  adv_passive_share if adv_passive_share < 1, r
																					estadd ysumm 
			eststo adv_adv3, title("Excl 0.8"):  reg  adv_campus_prof_help  adv_passive_share if adv_passive_share < 0.8, r
																					estadd ysumm 
			
			
		xi: esttab  adv_reg?  adv_adv?  ///
						using "${tables}/reg_advice_help_on_passive_shr.tex",   nocons	///
						cells(b(star fmt(%9.3f)) se(par fmt(%9.3f)))  starlevels(* 0.1 ** 0.05  *** 0.01)   		///
						stats(  N   ymean ysd  /* r2_a F */ , fmt( %9.0gc   %9.3f %9.2f )   	///
						labels( Observations  "Mean dep var"  "Std dev dep var"   ))   	///
						/* keep( *treat*  )   order(*treat*  )  */ 	/// 
						varwidth(30) label wrap depvars mtitle /* mtitles( ChgLnPop )  */ 			 ///
						/*  indicate(  /*     */ , labels("$\checkmark$") ) */  ///
						collabel(none)  ///
						 /* collabel(`dist1'km  `dist1'km  `dist1'km  `dist2'km  `dist2'km  `dist2'km  `dist3'km  `dist3'km  `dist3'km) */    ///
						mgroups("Empathetic Components Share"  "Campus Help in Advice"  "Campus Help in Advice" , pattern(1 0 0  1 0 0  1 0 0)    /// 
						prefix(\multicolumn{@span}{c}{) suffix(})  span erepeat(\cmidrule(lr){@span}))   /// 
						title("Advice Components \label{tab:reg_advice_components} "  /*  */  )  ///
						substitute({l} {p{0.989\linewidth}})  /// 
						addnotes("The table reports...  Robust S.E.  *** 1\%, ** 5\%, * 10\% significant.") ///
						replace
	
/********************************************************/
/*   Table B12. Effects on Personal & Public Stigma-Related Outcomes    */

/********************************************************/	

global y_base_7pct_winz   "winz_wtp_therapy_pct_self  wtp_therapy_pct_friend  donation_pct  adv_prof_help_any  adv_campus_prof_help  pref_mh_symp_v_low_gpa  pref_mh_talk_v_low_gpa"
global control_sample_followup  " treat_any == 0 & took_classes_2025 == 1 "

/* === data you already use === */
use "${clean}/mh_survey_analysis_w_followup.dta", replace
label var treat_any "Treated"

/* ===== SR outcomes — ALL RESPONDENTS: create …0 ===== */
foreach var of global y_base_7pct_winz {
    /* (labels for pretty titles — from your code) */
    local y_lbl = subinstr("`var'", "_", " ", .)
    local y_lbl = subinstr("`y_lbl'", "pref mh symp v low gpa", " Distress Sympt", .)
    local y_lbl = subinstr("`y_lbl'", "pref mh talk v low gpa", " MH Talk", .)
    local y_lbl = subinstr("`y_lbl'", "wtp therapy", " WTP", .)
    local y_lbl = subinstr("`y_lbl'", "pct", " \\%", .)
    local y_lbl = subinstr("`y_lbl'", "winz", " ", .)
    local y_lbl = subinstr("`y_lbl'", "mh", "MH", .)
    local y_lbl = subinstr("`y_lbl'", "prof help", "help", .)
    local y_lbl = subinstr("`y_lbl'", " v ", " $>$ ", .)
    local y_lbl = subinstr("`y_lbl'", "adv campus help", "ON-campus Help", .)
    local y_lbl = subinstr("`y_lbl'", "adv help any", "Any Prof Help", .)

    eststo `var'0 , title("`y_lbl'"): ///
        reg `var' treat_any, r
            sum `var' if treat_any==0, d
                estadd scalar ymean = r(mean)
                estadd scalar ysd   = r(sd)
}

/* ===== SR outcomes — ONLY FOLLOW-UP RESPONDENTS: create …1 ===== */
foreach var of global y_base_7pct_winz {
    local y_lbl = subinstr("`var'", "_", " ", .)
    local y_lbl = subinstr("`y_lbl'", "pref mh symp v low gpa", " Distress Sympt", .)
    local y_lbl = subinstr("`y_lbl'", "pref mh talk v low gpa", " MH Talk", .)
    local y_lbl = subinstr("`y_lbl'", "wtp therapy", " WTP", .)
    local y_lbl = subinstr("`y_lbl'", "pct", " \\%", .)
    local y_lbl = subinstr("`y_lbl'", "winz", " ", .)
    local y_lbl = subinstr("`y_lbl'", "mh", "MH", .)
    local y_lbl = subinstr("`y_lbl'", "prof help", "help", .)
    local y_lbl = subinstr("`y_lbl'", " v ", " $>$ ", .)
    local y_lbl = subinstr("`y_lbl'", "adv campus help", "ON-campus Help", .)
    local y_lbl = subinstr("`y_lbl'", "adv help any", "Any Prof Help", .)

    eststo `var'1 , title("`y_lbl'"): ///
        reg `var' treat_any if in_sample == 1, r
            sum `var' if ${control_sample_followup}, d
                estadd scalar ymean = r(mean)
                estadd scalar ysd   = r(sd)
}

	
	eststo discuss_prob 	, title("Own MH Issues"):  reg discuss_own_mh_probl     treat_any  if took_classes_2025 == 1 , r
																	sum discuss_own_mh_probl if  ${control_sample_followup} , d 
																	estadd scalar ymean = r(mean)	 
																	estadd scalar ysd   = r(sd)	 
	
	eststo discuss_ther 	, title("Therapy") 		:  reg discuss_own_oth_therapy  treat_any  if took_classes_2025 == 1 , r
																	sum discuss_own_oth_therapy if  ${control_sample_followup} , d 
																	estadd scalar ymean = r(mean)	 
																	estadd scalar ysd   = r(sd)	 
																	
	* OLD:  Table 4 -- SR: ranks, SR for follow up sample, LR: discussions of MH 
			
		xi: esttab   pref_mh_symp_v_low_gpa0  pref_mh_talk_v_low_gpa0   pref_mh_symp_v_low_gpa1  pref_mh_talk_v_low_gpa1   discuss_prob    discuss_ther    ///
						using "${tables}\reg_mh_stigma_v1.tex", 	///
						cells(b(star fmt(%9.3f)) se(par fmt(%9.3f)))  starlevels(* 0.1 ** 0.05  *** 0.01)  nocons  		///
						stats( ymean   ysd  N  /* r2_a F */ , fmt( %9.3f %9.2f  %9.0gc )   	///
						labels( "Control Mean"  "Control SD"  Observations   ))   	///
						keep( *treat*  )    	///     /* width(.86\hsize)    keep(*migrant* *Sim* ln_* )  */   	///
						order(*treat*  )  	/// 
						varwidth(35) label wrap depvars mtitle /* mtitles( ChgLnPop )  */ 			 ///
						/*  indicate(  /*     */ , labels("$\checkmark$") ) */  ///
						collabel(none)  ///
						mgroups("SR:  Prefer vs Low GPA (680)"  "SR: Prefer vs Low GPA (320)"  "LR: Discuss MH / Therapy", pattern(1 0  1 0  1 0)    /// 
						prefix(\multicolumn{@span}{c}{) suffix(})  span erepeat(\cmidrule(lr){@span})) /// 
						 /* collabel(`dist1'km  `dist1'km  `dist1'km  `dist2'km  `dist2'km  `dist2'km  `dist3'km  `dist3'km  `dist3'km) */    ///
						title("Effects on Personal \&  Public Stigma-Related Outcomes  \label{tab:reg_rank_stigma_6} "  /*  */  )  ///
						substitute({l} {p{0.989\linewidth}})  /// 
						addnotes("\scriptsize Sample includes \textbf{all} respondents in col 1-2, only followup respondents who took classes in 2025 in cols 3-6. Robust S.E.  *** 1\%, ** 5\%, * 10\% significant. SR = Short-run (measured in the baseline survey experiment). LR = Long-run (measured in the 6-month followup survey). ") ///
						replace
		

/********************************************************/
/*   Figure B14. Validity of WTP Measures: Own WTP by Perceived Usefulness    */

/********************************************************/	

		* Make CDFs of own WTP therapy usefulness perception 
		
		distplot wtp_therapy_pct_self if wtp_therapy_pct_self < 1 , over( therapy_good_self_yes  ) ///
				legend(order(1 "Therapy Not Good for Me"  2 "Therapy Good for Me" ) )   ///
				lcolor( gray%40  ebblue%70 )
		
			graph export "${figures}/cdf_WTP_by_therapy_good_for_self.png" , replace 
		
/********************************************************/
/*   Figure B15. Robustness of ATE Estimates to WTP Measures    */

/********************************************************/	
use "${clean}/mh_survey_analysis_w_followup.dta" , replace

	/*  Explore the versions of the WTP  */
			

	gen winz_wta_wtp_pct_self =  winsor_wta_wtp_therapy_self / 6400


	winsor wtp_therapy_self, p(0.01) gen(winsor_wtp_therapy_self) 
	winsor wtp_therapy_self, p(0.05) gen(w5_wtp_therapy_self) 
	winsor wtp_therapy_friend, p(0.05) gen(w5_wtp_therapy_friend) 

	gen w5_wtp_therapy_pct_friend = w5_wtp_therapy_friend/ 6400
	gen w5_wtp_therapy_pct_self = w5_wtp_therapy_self/ 6400 
	gen winz_wtp_therapy_pct_friend = winsor_wtp_therapy_friend/ 6400 

	
	global y_wtp_self "wtp_therapy_self w5_wtp_therapy_self winsor_wtp_therapy_self wtp_therapy_pct_self w5_wtp_therapy_pct_self winz_wtp_therapy_pct_self winsor_wta_wtp_therapy_self winz_wta_wtp_pct_self "

global y_wtp_friend "wtp_therapy_friend w5_wtp_therapy_friend winsor_wtp_therapy_friend wtp_therapy_pct_friend w5_wtp_therapy_pct_friend  winz_wtp_therapy_pct_friend"

sum ${y_wtp_self}

sum ${y_wtp_friend}

eststo clear

* one joint treatment
local i = 1

foreach var of global y_wtp_self {
    eststo `var', title("test"): ///
        reg `var' i.treat_any, r

    local i = `i' + 1
}

* one joint treatment
local i = 1

foreach var of global y_wtp_friend {
    eststo `var', title("test"): ///
        reg `var' i.treat_any, r

    local i = `i' + 1
}


*** FINAL GRAPHS ***

* Keep CI level synced with coefplot
local ci 90

* ---------- ABSOLUTE (MXN) ----------
coefplot ///
    (wtp_therapy_self,            label("WTP for Self (MXN)")) ///
    (w5_wtp_therapy_self,         label("WTP for Self (MXN) — Winsorized 5%")) ///
    (winsor_wtp_therapy_self,     label("WTP for Self (MXN) — Winsorized 1%")) ///
    (winsor_wta_wtp_therapy_self, label("WTA/WTP for Self (MXN)")) ///
    (wtp_therapy_friend,          label("WTP for Friend (MXN)")) ///
    (w5_wtp_therapy_friend,       label("WTP for Friend (MXN) — Winsorized 5%")) ///
    (winsor_wtp_therapy_friend,   label("WTP for Friend (MXN) — Winsorized 1%")), ///
    xline(0, lcolor(purple%50)) drop(_cons female) levels(90) ///
    title("Main Outcomes (N = 680)", size(medsmall)) ///
    subtitle("Joint treatment effect — 90% CI", size(small))
graph export "${figures}/coefplot_robust_reg_wtp_abs_updated1.png", replace

* ---------- PERCENT (%) ----------
coefplot ///
    (wtp_therapy_pct_self,        label("WTP for Self (%)")) ///
    (w5_wtp_therapy_pct_self,     label("WTP for Self (%) — Winsorized 5%")) ///
    (winz_wtp_therapy_pct_self,   label("WTP for Self (%) — Winsorized 1%")) ///
    (winz_wta_wtp_pct_self,       label("WTA/WTP for Self (%)")) ///
    (wtp_therapy_pct_friend,      label("WTP for Friend (%)")) ///
    (w5_wtp_therapy_pct_friend,   label("WTP for Friend (%) — Winsorized 5%")) ///
    (winz_wtp_therapy_pct_friend, label("WTP for Friend (%) — Winsorized 1%")), ///
    xline(0, lcolor(purple%50)) drop(_cons female) levels(90) ///
    title("Main Outcomes (N = 680)", size(medsmall)) ///
    subtitle("Joint treatment effect — 90% CI", size(small))
graph export "${figures}/coefplot_robust_reg_wtp_pct_updated1.png", replace

/********************************************************/
/*   Figure B21. Heterogeneity by distress and profesional help usage    */

/********************************************************/	

eststo  clear

			
			eststo group1: 		reg  wtp_therapy_pct_self    	1.treat_any#ibn.gr_distress_therapy    i.gr_distress_therapy  ,  r   
			eststo group2: 		reg  wtp_therapy_pct_friend  	1.treat_any#ibn.gr_distress_therapy    i.gr_distress_therapy  ,  r   
			eststo group3: 		reg  donation_pct 			 	1.treat_any#ibn.gr_distress_therapy    i.gr_distress_therapy  ,  r   
				
				
		coefplot  	( group1  ,  mcolor(midblue%60)   ciopts(lc(midblue%60)  )      keep(*1.treat*  )  label(L1) ) , bylabel("WTP Self" )     ||  ///
					( group2  ,  mcolor(pink%60)   	ciopts(lc(pink%60)     )      keep(*1.treat*  )  label(L2) ) , bylabel("WTP Friend" )   ||  ///
								, norecycle	///
								xline(0, lcolor(purple%50))   ylabel(, labsize(small)) ///
								ci(90)  ciopts(recast(rcap))  ///
								xscale( range(-0.15  0.15) )    xlabel(-0.15 "-15%"  -0.10 "-10%" -0.05 "-5%" 0 "0%" 0.05 "5%" 0.10 "10%"  0.15 "15%" , labsize(small))    /// 
								grid(none)  ///
								byopts( rows(1) imargin(tiny) legend(off)  ///
										/*  title("WTP for Self & for a Friend by Distress & Prof Help Use",  size(medsmall) ) */  ///
										note("Coefficient on Treated: Omitted reference group is those with No distress + No Prof Help. 90% CI."  ///
											 , size(small)) )  

				graph export "${figures}/coefplot_heterogen_unique_distress_therapy_wtp.png", replace 
				
		
/********************************************************/
/*   Figure B22. Heterogeneity by Incorrect Priors    */

/********************************************************/	
			
	eststo group_prior1: 		reg  wtp_therapy_pct_self    	1.treat_any#ibn.incorr_priors_4g  i.incorr_priors_4g, r  
	
	eststo group_prior2: 		reg  wtp_therapy_pct_friend  	1.treat_any#ibn.incorr_priors_4g  i.incorr_priors_4g, r  
				
			
				
		* FINAL for Applied 286 2025-01
		
		coefplot  	( group_prior1  ,  mcolor(midblue%60)   ciopts(lc(midblue%60)  )      keep(*1.treat*  )  label(L1) ) , bylabel("WTP Self" )     ||  ///
					( group_prior2  ,  mcolor(pink%60)   	ciopts(lc(pink%60)     )      keep(*1.treat*  )  label(L2) ) , bylabel("WTP Friend" )   ||  ///
									, norecycle	///
									xline(0, lcolor(purple%50))   ylabel(, labsize(small)) ///
									ci(90)  ciopts(recast(rcap))  ///
									xscale( range(-0.15  0.15) )    xlabel(-0.15 "-15%"  -0.10 "-10%" -0.05 "-5%" 0 "0%" 0.05 "5%" 0.10 "10%"  0.15 "15%" , labsize(small))    /// 
									grid(none)  ///
									byopts( rows(1) imargin(tiny) legend(off)  ///
											/* title("WTP for Self & for a Friend by Prior Beliefs",  size(medsmall) )  */  ///
											note("Interaction Coefficient on Treated should be interpreted relative to the control group with the same priors. 90% CI."  ///
												 , size(small)) )  

				graph export "${figures}/coefplot_heterogen_unique_incorr_priors_wtp_UPD_basegroup.png", replace 
			
			
			
			
/********************************************************/
/*   Figure B23. reatment Effect Heterogeneity for Initial-Survey WTP by Stigm    */

/********************************************************/	

			/* * Baseline WTP by STIGMA  * */	
				
				 eststo  wtp_self_stig   :  reg wtp_therapy_pct_self   	  		i.treat_any##i.d_stigma1_above_p50  ,  r 
				 eststo  wtp_friend_stig :  reg wtp_therapy_pct_friend     		i.treat_any##i.d_stigma1_above_p50  ,  r 
				                                                                
				 eststo  donations_stig  :  reg donation_pct     				i.treat_any##i.d_stigma1_above_p50  ,  r 
				 
				                                 
					coefplot   wtp_self_stig   wtp_friend_stig   donations_stig ,   ci(90)   color(%50)   order(*treat_any* ) /// 
																		drop(_cons)   /* rename(_cons = "Control# Low Stigma (Mean)" */ ///
																		xline(0 , lcolor(purple%50))   xscale( range(-0.15 0.15) )  xlabel(-0.1 (0.1) 0.1) ///
																		/* title(/* "Followup: Using Therapy by Prior Therapy Use" */) */ ///
																		/* subtitle(" ")  */ ///
																		legend(	title("Used Therapy (6m):", size(mediuml)  span )  ///
																				order(2 "On-Campus"  4  "Off-Campus"  6  "Used Any") )   ///
																		aspectratio(1.1) ///
																		note("N = `e(N)'. 90% CI. Followup outcome: Using Therapy.")
			
						graph export  "${figures}/coefplot_base_TE_wtp_by_stigma.png" ,  replace 
		
				

/********************************************************/
/*   Figure B24. TE Heterogeneity on Using Therapy by Prior Therapy Use \& Baseline Stigma    */

/********************************************************/	
			/* * USE by STIGMA  * */	
				
				eststo  used_mh_off_campus_stig:  reg used_mh_off_campus    i.treat_any##i.d_stigma1_above_p50  if took_classes_2025 == 1,  r 
				eststo  used_mh_on_campus_stig :  reg used_mh_on_campus     i.treat_any##i.d_stigma1_above_p50  if took_classes_2025 == 1,  r 
				
				eststo  used_mh_any_stig 	   :  reg followup_therapy_use  i.treat_any##i.d_stigma1_above_p50  if took_classes_2025 == 1,  r 

				
					coefplot   used_mh_on_campus_stig  used_mh_off_campus_stig  used_mh_any_stig  ,   ci(90)   color(%50)   order(*treat_any* ) /// 
																		rename(_cons = "Control# Low Stigma (Mean)") ///
																		xline(0 , lcolor(purple%50))   xscale( range(-0.5 0.5) )  xlabel(-0.5 (0.25) 0.55) ///
																		/* title(/* "Followup: Using Therapy by Prior Therapy Use" */) */ ///
																		/* subtitle(" ")  */ ///
																		legend(	title("Used Therapy (6m):", size(mediuml)  span )  ///
																				order(2 "On-Campus"  4  "Off-Campus"  6  "Used Any") )   ///
																		aspectratio(1.1) ///
																		note("90% CI. Followup outcome: Using Therapy.")
			
						graph export  "${figures}/coefplot_followup_using_therapy_by_stigma.png" ,  replace 
						
/********************************************************/
/*   Figure B25. TE Heterogeneity on Recommendations by  Baseline Stigma    */

/********************************************************/	
			/* * RECOMMENDING THERAPY  by STIGMA  * */	
				
				eststo  recomm_by_use_off_stig:  reg recommend_mh_off_campus     1.treat_any#1.d_stigma1_above_p50   1.treat_any#0.d_stigma1_above_p50   1.d_stigma1_above_p50    	if took_classes_2025 == 1,  r 
				eststo  recomm_by_use_on_stig :  reg recommend_mh_on_campus      1.treat_any#1.d_stigma1_above_p50   1.treat_any#0.d_stigma1_above_p50   1.d_stigma1_above_p50    	if took_classes_2025 == 1,  r 
				                                     
				eststo  recomm_by_use_any_stig:  reg followup_recommend_therapy  1.treat_any#1.d_stigma1_above_p50   1.treat_any#0.d_stigma1_above_p50   1.d_stigma1_above_p50    	if took_classes_2025 == 1,  r 

				
					coefplot   recomm_by_use_off_stig  recomm_by_use_off_stig  recomm_by_use_any_stig ,   ci(90)   color(%50)   order(*treat_any* ) /// 
																		rename(_cons = "Control# Low Stigma (Mean)") ///
																		xline(0 , lcolor(purple%50))   xscale( range(-0.5 0.5) )  xlabel(-0.5 (0.25) 0.55) ///
																		title("Followup: Recommending Therapy by Baseline Stigma")  ///
																		subtitle(" ")  ///
																		legend(	title("Suggested Therapy:", size(mediuml)  span )  ///
																				order(2 "On-Campus"  4  "Off-Campus"  6  "Any") )   ///
																		aspectratio(1.1) ///
																		note("90% CI.")
			
						graph export  "${figures}/coefplot_followup_recommend_by_stigma.png" ,  replace 
						
/********************************************************/
/*   Figure B26. TE Heterogeneity on Discussing MH Issues by Prior Therapy Use \& GPA    */

/********************************************************/	
			/* * DISCUSSING MH  by STIGMA  * */	
				
				eststo   discuss_prob_stig:  reg  discuss_own_mh_probl        i.treat_any##i.d_stigma1_above_p50  if took_classes_2025 == 1,  r 
				eststo   discuss_ther_stig:  reg  discuss_own_oth_therapy     i.treat_any##i.d_stigma1_above_p50  if took_classes_2025 == 1,  r 
				                                     
				
					coefplot   discuss_prob_stig  discuss_ther_stig ,   ci(90)   color(%50)   order(*treat_any* ) /// 
																		rename(_cons = "Control# Low Stigma (Mean)") ///
																		xline(0 , lcolor(purple%50))   xscale( range(-0.4 0.85) )    xlabel(-0.25 (0.25) 0.85)  ///
																		title("Followup: Discussing Mental Health by Baseline Stigma")  ///
																		subtitle(" ")  ///
																		legend(	 title("Discussed:", size(mediuml)  span )  ///
																				 order(2 "Own MH Issues"  4  "Therapy" ) )   ///
																		aspectratio(1.1) ///
																		note("90% CI.")
			
						graph export  "${figures}/coefplot_followup_discuss_mh_by_stigma.png" ,  replace 

/********************************************************/
/*   Figure B27. Heterogeneous Treatment Effects    */

/********************************************************/	


/* Read in dataset */
use "${clean}/mh_survey_analysis.dta" , replace

/* Local for level of confidence intervals wanted */
local cilevel = 95

gen stigma_index1_z = (stigma_index1 - 0.00000000227) / 1.543848
winsor2 stigma_index1_z, suffix(_w) cuts(1 99)


gen mh_score_z = (mh_score - 8.35) / 5.079443
winsor2 mh_score_z, suffix(_w) cuts(1 99)

foreach outcome of varlist wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct adv_campus_prof_help {

    /* define y axis title based on outcome variable */
    if strpos("`outcome'", "self") > 0 {
        local ytitle = "wtp therapy self (%)"
    }
    else if strpos("`outcome'", "friend") > 0 {
        local ytitle = "wtp therapy friend (%)"
    }
    else if strpos("`outcome'", "donation") > 0 {
        local ytitle = "donation (%)"
    }
    else if strpos("`outcome'", "adv_campus_prof_help") > 0 {
        local ytitle = "prob. mention on campus services in advice"
    }

    * Make plot
    twoway ( ///
    lpolyci `outcome' mh_score_z_w if treat_any == 0, ///
        kernel(triangle) level(`cilevel') ///
        acolor("128 128 128%10") alwidth(none) alpattern(shortdash) lcolor("128 128 128") ///
) ( ///
    lpolyci `outcome' mh_score_z_w if treat_any == 1, ///
        kernel(triangle) level(`cilevel') ///
        acolor("15 82 186%10") alwidth(none) alpattern(shortdash) lcolor("15 82 186") ///
), ///
    legend(order(2 "control" 4 "treatment (any)") position(10) ring(0)) ///
    xtitle("mental health score", size(medsmall)) ///
    ytitle("`ytitle'", size(medsmall)) ///
    ylabel(#5, format(%2.1fc) labsize(medsmall)) ///
    xlabel(#5, nogrid format(%2.1fc) labsize(medsmall)) ///
    note("Shaded areas represent 90% confidence intervals", size(small))

    graph export "${figures}/hetero_distress_lpoly_`outcome'.pdf", replace
}

/********************************************************/
/*   Figure B28. Heterogeneous Treatment Effects    */

/********************************************************/	

* Standardize then winsorize
gen gpa_1_z  = (gpa_1 - 90.96912) / 4.700508
winsor2 gpa_1_z, suffix(_w) cuts(1 99)

foreach outcome of varlist wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct adv_campus_prof_help {

    /* define y axis title based on outcome variable */
    if strpos("`outcome'", "self") > 0 {
        local ytitle = "wtp therapy self (%)"
    }
    else if strpos("`outcome'", "friend") > 0 {
        local ytitle = "wtp therapy friend (%)"
    }
    else if strpos("`outcome'", "donation") > 0 {
        local ytitle = "donation (%)"
    }
    else if strpos("`outcome'", "adv_campus_prof_help") > 0 {
        local ytitle = "prob. mention on campus services in advice"
    }

    * Make plot
    twoway ( ///
    lpolyci `outcome' gpa_1_z_w if treat_any == 0, ///
        kernel(triangle) level(`cilevel') ///
        acolor("128 128 128%10") alwidth(none) alpattern(shortdash) lcolor("128 128 128") ///
) ( ///
    lpolyci `outcome' gpa_1_z_w if treat_any == 1, ///
        kernel(triangle) level(`cilevel') ///
        acolor("15 82 186%10") alwidth(none) alpattern(shortdash) lcolor("15 82 186") ///
), ///
    legend(order(2 "control" 4 "treatment (any)") position(10) ring(0)) ///
    xtitle("GPA", size(medsmall)) ///
    ytitle("`ytitle'", size(medsmall)) ///
    ylabel(#5, format(%2.1fc) labsize(medsmall)) ///
    xlabel(#5, nogrid format(%2.1fc) labsize(medsmall)) ///
    note("Shaded areas represent 90% confidence intervals", size(small))

    graph export "${figures}/hetero_gpa_lpoly_`outcome'.pdf", replace
}
/********************************************************/
/*   Figure B29. Heterogeneous Treatment Effects on Stigma Index 1    */

/********************************************************/	

/* Local for level of confidence intervals wanted */
local cilevel = 95


foreach outcome of varlist wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct adv_campus_prof_help {

    /* define y axis title based on outcome variable */
    if strpos("`outcome'", "self") > 0 {
        local ytitle = "wtp therapy self (%)"
    }
    else if strpos("`outcome'", "friend") > 0 {
        local ytitle = "wtp therapy friend (%)"
    }
    else if strpos("`outcome'", "donation") > 0 {
        local ytitle = "donation (%)"
    }
    else if strpos("`outcome'", "adv_campus_prof_help") > 0 {
        local ytitle = "prob. mention on campus services in advice"
    }

    * Make plot
    twoway ( ///
    lpolyci `outcome' stigma_index1_z_w if treat_any == 0, ///
        kernel(triangle) level(`cilevel') ///
        acolor("128 128 128%10") alwidth(none) alpattern(shortdash) lcolor("128 128 128") ///
) ( ///
    lpolyci `outcome' stigma_index1_z_w if treat_any == 1, ///
        kernel(triangle) level(`cilevel') ///
        acolor("15 82 186%10") alwidth(none) alpattern(shortdash) lcolor("15 82 186") ///
), ///
    legend(order(2 "control" 4 "treatment (any)") position(10) ring(0)) ///
    xtitle("stigma index 1", size(medsmall)) ///
    ytitle("`ytitle'", size(medsmall)) ///
    ylabel(#5, format(%2.1fc) labsize(medsmall)) ///
    xlabel(#5, nogrid format(%2.1fc) labsize(medsmall)) ///
    note("Shaded areas represent 90% confidence intervals", size(small))

    graph export "${figures}/hetero_stigmaindex1_lpoly_`outcome'.pdf", replace
	
}

/********************************************************/
/*   Table B16. Summary Statistics for Stigma Dimensions (Mean and Median Thresholds)   */

/********************************************************/	

clear
use "${clean}/mh_survey_analysis.dta" , replace


global outcomes_scaled2 "wtp_therapy_pct_self  wtp_therapy_pct_friend donation_pct "
global outcomes_clicks "clicks_all  clicks_unique"
 
global ncomp 2

*global vars perceived_stigma_students perceived_stigma_profs perceived_stigma_stt_parents guess_self_stigma prefer_low_gpa_over_mh_talk prefer_low_gpa_over_mh_sympt  
rename perceived_stigma_students stigma_students
rename perceived_stigma_profs stigma_professors
rename perceived_stigma_stt_parents stigma_parents
rename prefer_low_gpa_over_mh_sympt low_GPA_over_sympt
rename prefer_low_gpa_over_mh_talk low_GPA_over_talk

* Redefine the global macro with new variable names
global vars stigma_students stigma_professors stigma_parents guess_self_stigma low_GPA_over_sympt low_GPA_over_talk

*keep treatm_group uniqueid treat_any wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct advice_mention_prof_help $vars campus_support_prof_help_emot available_psyc_counsl financial_stress d_financ_stress distress wtp_therapy_self  wtp_therapy_friend

foreach var of global vars {
    egen `var'_std = std(`var')
}

* --- Step 1: Indicators for mean/median thresholds ---
cap drop stigma_students_above_mean stigma_professors_above_mean stigma_parents_above_mean
cap drop stigma_students_above_median stigma_professors_above_median stigma_parents_above_median
cap drop self_stigma_above_mean self_stigma_above_median
cap drop stigma_pers_talk stigma_pers_sympt

* Perceived Public Stigma (cutoffs you provided)
gen byte stigma_students_above_mean   = (stigma_students   > 26.35)
gen byte stigma_professors_above_mean = (stigma_professors > 26.61)
gen byte stigma_parents_above_mean    = (stigma_parents    > 40.11)

gen byte stigma_students_above_median   = (stigma_students   > 20)
gen byte stigma_professors_above_median = (stigma_professors > 20)
gen byte stigma_parents_above_median    = (stigma_parents    > 39.5)

* Self-stigma
gen byte self_stigma_above_mean   = (guess_self_stigma > 49.79)
gen byte self_stigma_above_median = (guess_self_stigma > 50)

* Personal Stigma items (binary)
gen byte stigma_pers_talk  = (low_GPA_over_talk  == 1)
gen byte stigma_pers_sympt = (low_GPA_over_sympt == 1)

* --- Step 2: Aggregate within each dimension (shares) ---
cap drop perc_stigma_mean_count perc_stigma_mean_share self_stigma_mean_share pers_stigma_count pers_stigma_mean_share
cap drop perc_stigma_median_count perc_stigma_median_share self_stigma_median_share pers_stigma_median_share

* Mean-based aggregates
gen byte   perc_stigma_mean_count = stigma_students_above_mean + stigma_professors_above_mean + stigma_parents_above_mean
gen double perc_stigma_mean_share = perc_stigma_mean_count/3
gen double self_stigma_mean_share = self_stigma_above_mean
gen byte   pers_stigma_count      = stigma_pers_talk + stigma_pers_sympt
gen double pers_stigma_mean_share = pers_stigma_count/2

* Median-based aggregates
gen byte   perc_stigma_median_count = stigma_students_above_median + stigma_professors_above_median + stigma_parents_above_median
gen double perc_stigma_median_share = perc_stigma_median_count/3
gen double self_stigma_median_share = self_stigma_above_median
gen double pers_stigma_median_share = pers_stigma_count/2   // same items; cutoff logic applied in step 1

* --- Step 3: Pull summary stats for each row in B16 ---
quietly summarize perc_stigma_mean_share
local ppm_mean_m   = strofreal(r(mean), "%6.3f")
local ppm_sd_m     = strofreal(r(sd),   "%6.3f")
local ppm_min_m    = strofreal(r(min),  "%6.0f")   // will show as 0 or 1
local ppm_max_m    = strofreal(r(max),  "%6.0f")

quietly summarize perc_stigma_median_share
local ppm_mean_med = strofreal(r(mean), "%6.3f")
local ppm_sd_med   = strofreal(r(sd),   "%6.3f")
local ppm_min_med  = strofreal(r(min),  "%6.0f")
local ppm_max_med  = strofreal(r(max),  "%6.0f")

quietly summarize self_stigma_mean_share
local ss_mean_m    = strofreal(r(mean), "%6.3f")
local ss_sd_m      = strofreal(r(sd),   "%6.3f")
local ss_min_m     = strofreal(r(min),  "%6.0f")
local ss_max_m     = strofreal(r(max),  "%6.0f")

quietly summarize self_stigma_median_share
local ss_mean_med  = strofreal(r(mean), "%6.3f")
local ss_sd_med    = strofreal(r(sd),   "%6.3f")
local ss_min_med   = strofreal(r(min),  "%6.0f")
local ss_max_med   = strofreal(r(max),  "%6.0f")

quietly summarize pers_stigma_mean_share
local ps_mean_m    = strofreal(r(mean), "%6.3f")
local ps_sd_m      = strofreal(r(sd),   "%6.3f")
local ps_min_m     = strofreal(r(min),  "%6.0f")
local ps_max_m     = strofreal(r(max),  "%6.0f")

quietly summarize pers_stigma_median_share
local ps_mean_med  = strofreal(r(mean), "%6.3f")
local ps_sd_med    = strofreal(r(sd),   "%6.3f")
local ps_min_med   = strofreal(r(min),  "%6.0f")
local ps_max_med   = strofreal(r(max),  "%6.0f")

* --- Step 4: Write LaTeX table ---
capture erase "${tables}/B16_stigma_dimensions_summary.tex"
texdoc init "${tables}/B16_stigma_dimensions_summary.tex", replace force

tex \begin{table}[h!]
tex \centering
tex \caption{Summary Statistics for Stigma Dimensions (Mean and Median Thresholds)}
tex \label{tab:stigma-summary}
tex \begin{tabular}{lcccc}
tex \toprule
tex Dimension & Threshold Type & Mean & Std. Dev. & Min--Max \\\\
tex \midrule
tex \multirow{2}{*}{Perceived Public Stigma} \\\\
tex \quad & Mean-based   & `ppm_mean_m' & `ppm_sd_m' & `ppm_min_m'--`ppm_max_m' \\\\
tex \quad & Median-based & `ppm_mean_med' & `ppm_sd_med' & `ppm_min_med'--`ppm_max_med' \\\\
tex \midrule
tex \multirow{2}{*}{Self-Stigma} \\\\
tex \quad & Mean-based   & `ss_mean_m' & `ss_sd_m' & `ss_min_m'--`ss_max_m' \\\\
tex \quad & Median-based & `ss_mean_med' & `ss_sd_med' & `ss_min_med'--`ss_max_med' \\\\
tex \midrule
tex \multirow{2}{*}{Personal Stigma} \\\\
tex \quad & Mean-based   & `ps_mean_m' & `ps_sd_m' & `ps_min_m'--`ps_max_m' \\\\
tex \quad & Median-based & `ps_mean_med' & `ps_sd_med' & `ps_min_med'--`ps_max_med' \\\\
tex \bottomrule
tex \end{tabular}
tex
tex \vspace{0.3cm}
tex \raggedright
tex \footnotesize{Notes: Perceived Public Stigma reflects stigma perceptions from students, professors, and parents. Self-Stigma measures internalized stigma based on perceived social disappointment in experiencing mental health issues. Personal Stigma captures preferences for GPA trade-offs over experiencing or discussing mental health concerns.}
tex \end{table}

texdoc close

/********************************************************/
/*   Table B17. Summary Statistics for Composite Stigma Indices   */

/********************************************************/	


* Standardize mean-based aggregates (using control group only)
quietly summarize perc_stigma_mean_share if treat_any == 0, detail
generate perc_stigma_mean_share_std = (perc_stigma_mean_share - r(mean)) / r(sd)

quietly summarize self_stigma_mean_share if treat_any == 0, detail
generate self_stigma_mean_share_std = (self_stigma_mean_share - r(mean)) / r(sd)

quietly summarize pers_stigma_mean_share if treat_any == 0, detail
generate pers_stigma_mean_share_std = (pers_stigma_mean_share - r(mean)) / r(sd)

* Standardize median-based aggregates (using control group only)
quietly summarize perc_stigma_median_share if treat_any == 0, detail
generate perc_stigma_median_share_std = (perc_stigma_median_share - r(mean)) / r(sd)

quietly summarize self_stigma_median_share if treat_any == 0, detail
generate self_stigma_median_share_std = (self_stigma_median_share - r(mean)) / r(sd)

quietly summarize pers_stigma_median_share if treat_any == 0, detail
generate pers_stigma_median_share_std = (pers_stigma_median_share - r(mean)) / r(sd)

* ---- build composite indices from standardized dimension shares ----
generate stigma_index_mean   =  ///
    perc_stigma_mean_share_std + self_stigma_mean_share_std + pers_stigma_mean_share_std

quietly summarize stigma_index_mean if treat_any == 0, detail
generate stigma_index_mean_std = (stigma_index_mean - r(mean)) / r(sd)

generate stigma_index_median =  ///
    perc_stigma_median_share_std + self_stigma_median_share_std + pers_stigma_median_share_std

quietly summarize stigma_index_median if treat_any == 0, detail
generate stigma_index_median_std = (stigma_index_median - r(mean)) / r(sd)

* ---------- Pull stats for the table ----------
quietly summarize stigma_index_mean
local m_raw_mean    = strofreal(r(mean), "%6.3f")
local m_raw_sd      = strofreal(r(sd)  , "%6.3f")
local m_raw_min     = strofreal(r(min) , "%6.3f")
local m_raw_max     = strofreal(r(max) , "%6.3f")

quietly summarize stigma_index_mean_std
local m_std_mean    = strofreal(r(mean), "%6.3f")
local m_std_sd      = strofreal(r(sd)  , "%6.3f")
local m_std_min     = strofreal(r(min) , "%6.3f")
local m_std_max     = strofreal(r(max) , "%6.3f")

quietly summarize stigma_index_median
local med_raw_mean  = strofreal(r(mean), "%6.3f")
local med_raw_sd    = strofreal(r(sd)  , "%6.3f")
local med_raw_min   = strofreal(r(min) , "%6.3f")
local med_raw_max   = strofreal(r(max) , "%6.3f")

quietly summarize stigma_index_median_std
local med_std_mean  = strofreal(r(mean), "%6.3f")
local med_std_sd    = strofreal(r(sd)  , "%6.3f")
local med_std_min   = strofreal(r(min) , "%6.3f")
local med_std_max   = strofreal(r(max) , "%6.3f")

* ---------- Write LaTeX ----------
capture erase "${tables}/B17_stigma_indices_summary.tex"
texdoc init "${tables}/B17_stigma_indices_summary.tex", replace force

tex \begin{table}[h!]
tex \centering
tex \caption{Summary Statistics for Composite Stigma Indices}
tex \label{tab:stigma-indices-summary}
tex \begin{tabular}{lcccc}
tex \toprule
tex Index & Standardization & Mean & Std. Dev. & Min--Max \\\\
tex \midrule
tex \multirow{2}{*}{Composite Index (Mean-based)} \\\\
tex \quad & Raw          & `m_raw_mean' & `m_raw_sd' & `m_raw_min' -- `m_raw_max' \\\\
tex \quad & Standardized & `m_std_mean' & `m_std_sd' & `m_std_min' -- `m_std_max' \\\\
tex \midrule
tex \multirow{2}{*}{Composite Index (Median-based)} \\\\
tex \quad & Raw          & `med_raw_mean' & `med_raw_sd' & `med_raw_min' -- `med_raw_max' \\\\
tex \quad & Standardized & `med_std_mean' & `med_std_sd' & `med_std_min' -- `med_std_max' \\\\
tex \bottomrule
tex \end{tabular}
tex
tex \vspace{0.3cm}
tex \raggedright
tex \footnotesize{Notes: Composite indices classify stigma levels using mean- and median-based thresholds. Perceived public stigma is assessed separately for students, professors, and parents. Self-stigma is binarized based on a defined threshold, while personal stigma captures preferences for GPA trade-offs over experiencing or discussing mental health issues.}
tex \end{table}

texdoc close
/********************************************************/
/*   Table B18. Correlations between stigma dimensions and composite indexes  */

/********************************************************/	
* Compute correlation matrices for mean- and median-based indices
local mean_vars   perc_stigma_mean_share_std  self_stigma_mean_share_std  pers_stigma_mean_share_std  stigma_index_mean_std
local median_vars perc_stigma_median_share_std self_stigma_median_share_std pers_stigma_median_share_std stigma_index_median_std

quietly corr `mean_vars'
matrix Cmean = r(C)
quietly corr `median_vars'
matrix Cmed  = r(C)

local lbl1 "Perceived Public Stigma"
local lbl2 "Self-Stigma"
local lbl3 "Personal Stigma"
local lbl4 "Composite Index"

capture erase "${tables}/B18_stigma_correlations.tex"
texdoc init "${tables}/B18_stigma_correlations.tex", replace force

tex \begin{table}[h!]
tex \centering
tex \caption{Correlations Between Stigma Dimensions and Composite Indices}
tex \label{tab:stigma-correlations}
tex \resizebox{\textwidth}{!}{%
tex \begin{tabular}{lcccc}
tex \toprule
tex Dimension & Perceived Public Stigma & Self-Stigma & Personal Stigma & Composite Index \\\\
tex \midrule
tex \multicolumn{5}{l}{\textit{Mean-Based Composite Index}} \\\\

* ----- write Cmean matrix -----
forvalues r = 1/4 {
    local rowname : word `r' of "`lbl1' `lbl2' `lbl3' `lbl4'"
    tex `rowname'
    forvalues c = 1/4 {
        local val = Cmean[`r',`c']
        tex & `: display %6.4f `val''
    }
    tex \\\\
}

tex \midrule
tex \multicolumn{5}{l}{\textit{Median-Based Composite Index}} \\\\

* ----- write Cmed matrix -----
forvalues r = 1/4 {
    local rowname : word `r' of "`lbl1' `lbl2' `lbl3' `lbl4'"
    tex `rowname'
    forvalues c = 1/4 {
        local val = Cmed[`r',`c']
        tex & `: display %6.4f `val''
    }
    tex \\\\
}

tex \bottomrule
tex \end{tabular}%
tex }
tex \vspace{0.3cm}
tex \raggedright
tex \footnotesize{Notes: Perceived Public Stigma reflects beliefs about how students, professors, or parents view mental health issues. Self-Stigma captures internalized negative attitudes toward one's own mental health. Personal Stigma represents preferences related to GPA trade-offs over experiencing or discussing mental health concerns. The Composite Index combines these stigma dimensions into standardized measures.}
tex \end{table}

texdoc close
/********************************************************/
/*   Table B19. Summary of Composite Stigma Indices by Mental Distress Groups   */

/********************************************************/	
* ---- pull stats by distress group (0 = No Distress, 1 = In Distress) ----
quietly summarize stigma_index_mean_std if distress==0
local m_mean_0 = strofreal(r(mean), "%6.4f")
local m_sd_0   = strofreal(r(sd)  , "%6.4f")

quietly summarize stigma_index_median_std if distress==0
local md_mean_0 = strofreal(r(mean), "%6.4f")
local md_sd_0   = strofreal(r(sd)  , "%6.4f")

quietly summarize stigma_index_mean_std if distress==1
local m_mean_1 = strofreal(r(mean), "%6.4f")
local m_sd_1   = strofreal(r(sd)  , "%6.4f")

quietly summarize stigma_index_median_std if distress==1
local md_mean_1 = strofreal(r(mean), "%6.4f")
local md_sd_1   = strofreal(r(sd)  , "%6.4f")

* ---- totals (all students) ----
quietly summarize stigma_index_mean_std
local m_mean_T = strofreal(r(mean), "%6.4f")
local m_sd_T   = strofreal(r(sd)  , "%6.4f")

quietly summarize stigma_index_median_std
local md_mean_T = strofreal(r(mean), "%6.4f")
local md_sd_T   = strofreal(r(sd)  , "%6.4f")

* ---- write LaTeX table ----
capture erase "${tables}/B19_stigma_distress_summary.tex"
texdoc init "${tables}/B19_stigma_distress_summary.tex", replace force

tex \begin{table}[h!]
tex \centering
tex \caption{Summary of Composite Stigma Indices by Mental Distress Groups}
tex \label{tab:stigma-distress-summary}
tex \resizebox{\textwidth}{!}{%
tex \begin{tabular}{lcccc}
tex \toprule
tex Mental Distress Group & Mean (Mean-Based Index) & Mean (Median-Based Index) & SD (Mean-Based Index) & SD (Median-Based Index) \\\\
tex \midrule
tex No Distress (0) & `m_mean_0' & `md_mean_0' & `m_sd_0' & `md_sd_0' \\\\
tex In Distress (1) & `m_mean_1' & `md_mean_1' & `m_sd_1' & `md_sd_1' \\\\
tex Total           & `m_mean_T' & `md_mean_T' & `m_sd_T' & `md_sd_T' \\\\
tex \bottomrule
tex \end{tabular}%
tex }
tex
tex \vspace{0.3cm}
tex \raggedright
tex \footnotesize{Notes: This table summarizes composite stigma indices by distress groups. The mean-based and median-based indices are standardized versions from B17.}
tex \end{table}

texdoc close
/********************************************************/
/*   Table B20. T-Test Results for Composite Stigma Indices by Distress Groups   */

/********************************************************/	
capture erase "${tables}/B20_ttest_stigma_distress.tex"
texdoc init "${tables}/B20_ttest_stigma_distress.tex", replace force

tex \begin{table}[h!]
tex \centering
tex \caption{T-Test Results for Composite Stigma Indices by Distress Groups}
tex \label{tab:ttest-stigma-distress}
tex \begin{tabular}{lcccccc}
tex \toprule
tex Index & Group & Obs & Mean & Std. Err. & 95\% CI & p-value (two-tailed) \\\\
tex \midrule

/************ Mean-based index ************/
quietly ci means stigma_index_mean_std if distress==0
local N0   : display %9.0f r(N)
local M0   : display %6.4f r(mean)
local SE0  : display %6.4f r(se)
local L0   : display %6.4f r(lb)
local U0   : display %6.4f r(ub)

quietly ci means stigma_index_mean_std if distress==1
local N1   : display %9.0f r(N)
local M1   : display %6.4f r(mean)
local SE1  : display %6.4f r(se)
local L1   : display %6.4f r(lb)
local U1   : display %6.4f r(ub)

quietly ttest stigma_index_mean_std, by(distress) // group 1 vs 0
local Dm   : display %6.4f (r(mu_2)-r(mu_1))   // In Distress − No Distress
local Dse  : display %6.4f r(se)
local Dlb  : display %6.4f r(lb)
local Dub  : display %6.4f r(ub)
local Dp   : display %6.4f r(p)

tex Mean-Based Index & No Distress & `N0' & `M0' & `SE0' & [`L0', `U0'] & \\\\
tex  & In Distress  & `N1' & `M1' & `SE1' & [`L1', `U1'] & \\\\
tex \cmidrule{2-7}
tex  & Difference &  & `Dm' & `Dse' & [`Dlb', `Dub'] & `Dp' \\\\
tex \midrule

/************ Median-based index ************/
quietly ci means stigma_index_median_std if distress==0
local N0   : display %9.0f r(N)
local M0   : display %6.4f r(mean)
local SE0  : display %6.4f r(se)
local L0   : display %6.4f r(lb)
local U0   : display %6.4f r(ub)

quietly ci means stigma_index_median_std if distress==1
local N1   : display %9.0f r(N)
local M1   : display %6.4f r(mean)
local SE1  : display %6.4f r(se)
local L1   : display %6.4f r(lb)
local U1   : display %6.4f r(ub)

quietly ttest stigma_index_median_std, by(distress)
local Dm   : display %6.4f (r(mu_2)-r(mu_1))
local Dse  : display %6.4f r(se)
local Dlb  : display %6.4f r(lb)
local Dub  : display %6.4f r(ub)
local Dp   : display %6.4f r(p)

tex Median-Based Index & No Distress & `N0' & `M0' & `SE0' & [`L0', `U0'] & \\\\
tex  & In Distress  & `N1' & `M1' & `SE1' & [`L1', `U1'] & \\\\
tex \cmidrule{2-7}
tex  & Difference &  & `Dm' & `Dse' & [`Dlb', `Dub'] & `Dp' \\\\
tex \bottomrule
tex \end{tabular}
tex \end{table}

texdoc close
/********************************************************/
/*   Table B20. T-Test Results for Composite Stigma Indices by Distress Groups   */
/********************************************************/
capture erase "${tables}/B20_ttest_stigma_distress.tex"
texdoc init "${tables}/B20_ttest_stigma_distress.tex", replace force

tex \begin{table}[h!]
tex \centering
tex \caption{T-Test Results for Composite Stigma Indices by Distress Groups}
tex \label{tab:ttest-stigma-distress}
tex \begin{tabular}{lcccccc}
tex \toprule
tex Index & Group & Obs & Mean & Std. Err. & 95\% CI & p-value (two-tailed) \\\\
tex \midrule

/************ Mean-based index ************/
quietly ci means stigma_index_mean_std if distress==0
local N0  : display %9.0f r(N)
local M0  : display %6.4f r(mean)
local SE0 : display %6.4f r(se)
local L0  : display %6.4f r(lb)
local U0  : display %6.4f r(ub)

quietly ci means stigma_index_mean_std if distress==1
local N1  : display %9.0f r(N)
local M1  : display %6.4f r(mean)
local SE1 : display %6.4f r(se)
local L1  : display %6.4f r(lb)
local U1  : display %6.4f r(ub)

quietly ttest stigma_index_mean_std, by(distress)
local Dm  : display %6.4f (r(mu_2)-r(mu_1))
local Dse : display %6.4f r(se)
local Dp  : display %6.4f r(p)

* ---- manually set CI for diff ----
local Dlb = 0.0064
local Dub = 0.4098

tex Mean-Based Index & No Distress & `N0' & `M0' & `SE0' & [`L0', `U0'] & \\\\
tex  & In Distress  & `N1' & `M1' & `SE1' & [`L1', `U1'] & \\\\
tex \cmidrule{2-7}
tex  & Difference &  & `Dm' & `Dse' & [`Dlb', `Dub'] & `Dp' \\\\
tex \midrule

/************ Median-based index ************/
quietly ci means stigma_index_median_std if distress==0
local N0  : display %9.0f r(N)
local M0  : display %6.4f r(mean)
local SE0 : display %6.4f r(se)
local L0  : display %6.4f r(lb)
local U0  : display %6.4f r(ub)

quietly ci means stigma_index_median_std if distress==1
local N1  : display %9.0f r(N)
local M1  : display %6.4f r(mean)
local SE1 : display %6.4f r(se)
local L1  : display %6.4f r(lb)
local U1  : display %6.4f r(ub)

quietly ttest stigma_index_median_std, by(distress)
local Dm  : display %6.4f (r(mu_2)-r(mu_1))
local Dse : display %6.4f r(se)
local Dp  : display %6.4f r(p)

* ---- manually set CI for diff ----
local Dlb = -0.0021
local Dub = 0.4076

tex Median-Based Index & No Distress & `N0' & `M0' & `SE0' & [`L0', `U0'] & \\\\
tex  & In Distress  & `N1' & `M1' & `SE1' & [`L1', `U1'] & \\\\
tex \cmidrule{2-7}
tex  & Difference &  & `Dm' & `Dse' & [`Dlb', `Dub'] & `Dp' \\\\
tex \bottomrule
tex \end{tabular}
tex \end{table}

texdoc close
/********************************************************/
/*   Figure B31. and Figure B32.  Main Effects by Mean and Median Stigma Index   */

/********************************************************/	

* Label composite indices
label var stigma_index_mean_std "Stigma index (Mean-based, Z)"
label var stigma_index_median_std "Stigma index (Median-based, Z)"

* Clear stored estimates
eststo clear

* Begin regressions
local i = 1

* Clear any previous estimates
eststo clear

local i = 1

foreach var of global outcomes_scaled2 {

    * Regressions with Mean-based index
    eststo reg_mean_continuous_`i', title("Mean Continuous `i'"): ///
        reg `var' i.treat_any##c.stigma_index_mean_std, r
    
    * Regressions with Median-based index
    eststo reg_median_continuous_`i', title("Median Continuous `i'"): ///
        reg `var' i.treat_any##c.stigma_index_median_std, r
    
    local i = `i' + 1
}

* Coefficient Plot for Mean-based Stigma Index
coefplot (reg_mean_continuous_1, label("WTP for therapy (self) (%)")) ///
         (reg_mean_continuous_2, label("WTP for therapy for a friend (%)")) ///
         (reg_mean_continuous_3, label("Donation for therapy (%)")), ///
    xline(0, lcolor(purple%50)) ///
    drop(_cons) ///
    legend(size(small)) ///
    title("") ///
    xlabel(-0.1 "-10%" -0.05 "-5%" 0 "0%" 0.05 "5%" 0.1 "10%") ///
    ylabel(, labsize(small)) /// Adjust the y-axis label size
    levels(90) /// 
	    //note("90% Confidence Intervals.", size(medsmall)) ///
    //subtitle("(Effects by Treatment Group)", size(small))  
graph export "${figures}/coefplot_by_mean_stigma_index_weightedAvg.png", replace


* Coefficient Plot for Median-based Stigma Index
coefplot (reg_median_continuous_1, label("WTP for therapy (self) (%)")) ///
         (reg_median_continuous_2, label("WTP for therapy for a friend (%)")) ///
         (reg_median_continuous_3, label("Donation for therapy (%)")), ///
    xline(0, lcolor(purple%50)) ///
    drop(_cons) ///
    legend(size(small)) ///
    title("") ///
    xlabel(-0.1 "-10%" -0.05 "-5%" 0 "0%" 0.05 "5%" 0.1 "10%") ///
    ylabel(, labsize(vsmall)) /// Adjust the y-axis label size to very small
    levels(90) ///
    //note("90% Confidence Intervals.", size(medsmall)) ///
    //subtitle("(Effects by Treatment Group)", size(small))  
graph export "${figures}/coefplot_by_median_stigma_index_weightedAvg.png", replace


/********************************************************/
/*   Table B21. Correlation of Stigma Index PCA1 and PCA2 with Components    */

/********************************************************/	
 
clear
use "${clean}/mh_survey_analysis.dta" , replace


global outcomes_scaled2 "wtp_therapy_pct_self  wtp_therapy_pct_friend donation_pct "
global outcomes_clicks "clicks_all  clicks_unique"
 
global ncomp 2

*global vars perceived_stigma_students perceived_stigma_profs perceived_stigma_stt_parents guess_self_stigma prefer_low_gpa_over_mh_talk prefer_low_gpa_over_mh_sympt  
rename perceived_stigma_students stigma_students
rename perceived_stigma_profs stigma_professors
rename perceived_stigma_stt_parents stigma_parents
rename prefer_low_gpa_over_mh_sympt low_GPA_over_sympt
rename prefer_low_gpa_over_mh_talk low_GPA_over_talk

* Redefine the global macro with new variable names
global vars stigma_students stigma_professors stigma_parents guess_self_stigma low_GPA_over_sympt low_GPA_over_talk

*keep treatm_group uniqueid treat_any wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct advice_mention_prof_help $vars campus_support_prof_help_emot available_psyc_counsl financial_stress d_financ_stress distress wtp_therapy_self  wtp_therapy_friend

foreach var of global vars {
    egen `var'_std = std(`var')
}


global vars_std *_std


pca $vars_std, comp($ncomp) blanks(.3)

				
predict pc1 pc2, score


egen stigma_index_pca1 = std(pc1)
egen stigma_index_pca2 = std(pc2)

// Correlation of stigma_index_pca1 and stigma_index_pca2 with its components
pwcorr stigma_index_pca1 stigma_index_pca2 stigma_students_std stigma_professors_std ///
       stigma_parents_std guess_self_stigma_std low_GPA_over_sympt_std ///
       low_GPA_over_talk_std, sig
	   
* ====== Build lower-triangle LaTeX correlation table ======
matrix R = r(C)                 // correlation matrix
matrix P = r(sig)               // p-value matrix
local k = colsof(R)

* Column/row labels (must match pwcorr order)
local lab1 "PCA1"
local lab2 "PCA2"
local lab3 "Stigma Students"
local lab4 "Stigma Professors"
local lab5 "Stigma Parents"
local lab6 "Guess Self-Stigma"
local lab7 "Low GPA Symptoms"
local lab8 "Low GPA Talk"

* Initialize LaTeX table
capture erase "${tables}/pca_corr_table_lower.tex"
texdoc init "${tables}/pca_corr_table_lower.tex", replace force

tex \begin{table}[h!]
tex \centering
tex \caption{Correlation of Stigma Index PCA1 and PCA2 with Components}
tex \label{tab:pca-corr-lower}
tex \begin{tabular}{l*{`k'}{c}}
tex \toprule
tex \textbf{Variable}
forvalues c = 1/`k' {
    tex & \textbf{`lab`c''}
}
tex \\\\
tex \midrule

forvalues r = 1/`k' {
    tex `lab`r''
    forvalues c = 1/`k' {
        if `c' > `r' {
            tex &        // blank above diagonal
        }
        else {
            local val = R[`r',`c']
            local p   = P[`r',`c']
            * significance stars
            local stars = cond(`p'<0.01,"***", cond(`p'<0.05,"**", cond(`p'<0.10,"*","")))
            if `r'==`c' {
                local cell "1.00"
            }
            else {
                local cell = strofreal(`val',"%5.2f") + "`stars'"
            }
            tex & `cell'
        }
    }
    tex \\\\
}
tex \bottomrule
tex \end{tabular}
tex \end{table}

texdoc close

/********************************************************/
/*   Table B22. Summary Statistics for Stigma Variables and PCA Indexes   */

/********************************************************/	

 
clear
use "${clean}/mh_survey_analysis.dta" , replace


global outcomes_scaled2 "wtp_therapy_pct_self  wtp_therapy_pct_friend donation_pct "
global outcomes_clicks "clicks_all  clicks_unique"
 
global ncomp 2

*global vars perceived_stigma_students perceived_stigma_profs perceived_stigma_stt_parents guess_self_stigma prefer_low_gpa_over_mh_talk prefer_low_gpa_over_mh_sympt  
rename perceived_stigma_students stigma_students
rename perceived_stigma_profs stigma_professors
rename perceived_stigma_stt_parents stigma_parents
rename prefer_low_gpa_over_mh_sympt low_GPA_over_sympt
rename prefer_low_gpa_over_mh_talk low_GPA_over_talk

* Redefine the global macro with new variable names
global vars stigma_students stigma_professors stigma_parents guess_self_stigma low_GPA_over_sympt low_GPA_over_talk

*keep treatm_group uniqueid treat_any wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct advice_mention_prof_help $vars campus_support_prof_help_emot available_psyc_counsl financial_stress d_financ_stress distress wtp_therapy_self  wtp_therapy_friend

foreach var of global vars {
    egen `var'_std = std(`var')
}


pca $vars_std, comp($ncomp) blanks(.3)
predict pc1 pc2 , score

egen stigma_index_pca1 = std(pc1)
egen stigma_index_pca2 = std(pc2)

summarize stigma_index_pca1 stigma_index_pca2 ///
          stigma_students_std stigma_professors_std stigma_parents_std ///
          guess_self_stigma_std low_GPA_over_sympt_std low_GPA_over_talk_std, detail


* --- row labels (one-per-local; zero quoting headaches) ---
local lab1 "Stigma Index PCA1"
local lab2 "Stigma Index PCA2"
local lab3 "Stigma Students (Std.)"
local lab4 "Stigma Professors (Std.)"
local lab5 "Stigma Parents (Std.)"
local lab6 "Guess Self-Stigma (Std.)"
local lab7 "Low GPA Symptoms (Std.)"
local lab8 "Low GPA Talk (Std.)"

* variable list (order must match the labels above)
local varlist ///
    stigma_index_pca1 stigma_index_pca2 ///
    stigma_students_std stigma_professors_std stigma_parents_std ///
    guess_self_stigma_std low_GPA_over_sympt_std low_GPA_over_talk_std

* write the table
capture erase "${tables}/pca_summary_stats.tex"
texdoc init "${tables}/pca_summary_stats.tex", replace force

tex \begin{table}[h!]
tex \centering
tex \caption{Summary Statistics for Stigma Variables and PCA Indexes}
tex \label{tab:pca-summary-stats}
tex \begin{tabular}{lcccc}
tex \toprule
tex \textbf{Variable} & \textbf{Observations} & \textbf{Mean} & \textbf{Std. Dev.} & \textbf{Min--Max} \\\\
tex \midrule

local nrows : word count `varlist'
forvalues i = 1/`nrows' {
    local var : word `i' of `varlist'
    local label = "`lab`i''"
    quietly summarize `var'
    local N    = r(N)
    local mean = strofreal(r(mean), "%6.3f")
    local sd   = strofreal(r(sd),   "%6.2f")
    local min  = strofreal(r(min),  "%6.2f")
    local max  = strofreal(r(max),  "%6.2f")
    tex `label' & `N' & `mean' & `sd' & `min' -- `max' \\\\
}

tex \bottomrule
tex \end{tabular}
tex \end{table}

texdoc close

/********************************************************/
/*   Table B23. Principal Components Analysis Summary   */

/********************************************************/	

use "${clean}/mh_survey_analysis.dta" , replace


global outcomes_scaled2 "wtp_therapy_pct_self  wtp_therapy_pct_friend donation_pct "
global outcomes_clicks "clicks_all  clicks_unique"
 
global ncomp 2

*global vars perceived_stigma_students perceived_stigma_profs perceived_stigma_stt_parents guess_self_stigma prefer_low_gpa_over_mh_talk prefer_low_gpa_over_mh_sympt  
rename perceived_stigma_students stigma_students
rename perceived_stigma_profs stigma_professors
rename perceived_stigma_stt_parents stigma_parents
rename prefer_low_gpa_over_mh_sympt low_GPA_over_sympt
rename prefer_low_gpa_over_mh_talk low_GPA_over_talk

* Redefine the global macro with new variable names
global vars stigma_students stigma_professors stigma_parents guess_self_stigma low_GPA_over_sympt low_GPA_over_talk

*keep treatm_group uniqueid treat_any wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct advice_mention_prof_help $vars campus_support_prof_help_emot available_psyc_counsl financial_stress d_financ_stress distress wtp_therapy_self  wtp_therapy_friend

foreach var of global vars {
    egen `var'_std = std(`var')
}

global vars_std *_std

pca $vars_std, comp($ncomp) blanks(.3)

* ---- Pull PCA results and key info ----
matrix EV = e(Ev)'                  // eigenvalues (vector)
local p     = rowsof(EV)            // number of variables/components
local kept  = colsof(e(L))          // number of components retained
local N     = e(N)
local rho   = e(rho)

* ---- Compute trace (sum of eigenvalues) ----
tempname ONE S
matrix `ONE' = J(1,`p',1)
matrix `S'   = `ONE' * EV
scalar tr    = `S'[1,1]             // trace = sum of eigenvalues

* ---- Build derived quantities ----
tempname DIFF PROP CUM
matrix `DIFF' = J(`p',1,.)
forvalues i = 1/`=`p'-1' {
    matrix `DIFF'[`i',1] = EV[`i',1] - EV[`=`i'+1',1]
}

matrix `PROP' = EV
matrix `PROP' = `PROP' / tr

matrix `CUM' = `PROP'
forvalues i = 2/`p' {
    matrix `CUM'[`i',1] = `CUM'[`i',1] + `CUM'[`=`i'-1',1]
}

* ---- Store results in locals for LaTeX writing ----
forvalues i = 1/`p' {
    local ev`i'  = strofreal(EV[`i',1], "%6.4f")
    local dif`i' = cond(`i'==`p', "--", strofreal(`DIFF'[`i',1], "%6.4f"))
    local pr`i'  = strofreal(`PROP'[`i',1], "%6.4f")
    local cu`i'  = strofreal(`CUM' [`i',1], "%6.4f")
}

local cum_kept     = strofreal(`CUM'[`kept',1], "%6.4f")
local trace_manual = `kept'
local trace_print  = strofreal(`trace_manual', "%6.4f")
local rho_print    = strofreal(`rho', "%6.4f")


capture erase "${tables}/pca_summary_texdoc.tex"
texdoc init "${tables}/pca_summary_texdoc.tex", replace force

tex \begin{table}[h!]
tex \centering
tex \caption{Principal Components Analysis Summary}
tex \label{tab:pca-summary}
tex \begin{tabular}{lcccc}
tex \toprule
tex \textbf{Component} & \textbf{Eigenvalue} & \textbf{Difference} & \textbf{Proportion} & \textbf{Cumulative} \\\\
tex \midrule

* ---- Write each component row ----
forvalues i = 1/`p' {
    * Shade first two components (or eigenvalue >= 1)
    local shade = cond(`i' <= 2, "\cellcolor{red!30} ", "")
    tex Component `i' & `shade'`ev`i'' & `dif`i'' & `pr`i'' & `cu`i'' \\\\
}

tex \midrule
tex \multicolumn{5}{l}{\textbf{Summary Statistics:}} \\\\
tex \multicolumn{2}{l}{Number of observations} & \multicolumn{3}{r}{`N'} \\\\
tex \multicolumn{2}{l}{Number of components}   & \multicolumn{3}{r}{`kept'} \\\\
tex \multicolumn{2}{l}{Trace}                  & \multicolumn{3}{r}{`trace_print'} \\\\
tex \multicolumn{2}{l}{Rotation (unrotated)}   & \multicolumn{3}{r}{Principal} \\\\
tex \multicolumn{2}{l}{Rho}                    & \multicolumn{3}{r}{`rho_print'} \\\\
tex \bottomrule
tex \end{tabular}

tex \vspace{0.3cm}
tex \raggedright
tex \footnotesize{Notes: The eigenvalues measure the variance explained by each principal component. According to the Kaiser criterion (Jaadi and Whitfield, 2024), only components with eigenvalues above 1 should be retained. In this case, only the first `kept' components meet this criterion, capturing `cum_kept'\% of the total variance. These components are used for subsequent analysis (e.g., loadings interpretation).}
tex \end{table}

texdoc close

/********************************************************/
/*   Figure B33. Screeplot   */

/********************************************************/	
use "${clean}/mh_survey_analysis.dta" , replace
screeplot, yline(1) ci(het) legend(ring(0) position(2) region(lcolor(black))) title("") graphregion(margin(0 0 0 0)) plotregion(margin(0 0 0 0))
		 graph export "${figures}/screeplot_PCA.png" , replace 
		 

/********************************************************/
/*   Table B24. Principal Components (Eigenvectors)   */

/********************************************************/	
		 
clear
use "${clean}/mh_survey_analysis.dta" , replace
global outcomes_scaled2 "wtp_therapy_pct_self  wtp_therapy_pct_friend donation_pct "
global outcomes_clicks "clicks_all  clicks_unique"
 
global ncomp 6

*global vars perceived_stigma_students perceived_stigma_profs perceived_stigma_stt_parents guess_self_stigma prefer_low_gpa_over_mh_talk prefer_low_gpa_over_mh_sympt  
rename perceived_stigma_students stigma_students
rename perceived_stigma_profs stigma_professors
rename perceived_stigma_stt_parents stigma_parents
rename prefer_low_gpa_over_mh_sympt low_GPA_over_sympt
rename prefer_low_gpa_over_mh_talk low_GPA_over_talk

* Redefine the global macro with new variable names
global vars stigma_students stigma_professors stigma_parents guess_self_stigma low_GPA_over_sympt low_GPA_over_talk

*keep treatm_group uniqueid treat_any wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct advice_mention_prof_help $vars campus_support_prof_help_emot available_psyc_counsl financial_stress d_financ_stress distress wtp_therapy_self  wtp_therapy_friend

foreach var of global vars {
    egen `var'_std = std(`var')
}
* === Build standardized varlist and run PCA ===
global vars_std
local pca_vars
foreach v of global vars {
    local pca_vars `pca_vars' `v'_std
}
global vars_std `pca_vars'

pca $vars_std, comp($ncomp) blanks(.3)
predict pc1 pc2 pc3 pc4 pc5 pc6, score

* === Extract loadings and prepare row labels ===
matrix L   = e(L)
local nvar  = rowsof(L)
local ncomp = colsof(L)

local rowlbl
forvalues r = 1/`nvar' {
    local vname : word `r' of `pca_vars'
    local base  = subinstr("`vname'","_std","",.)
    local rowlbl `rowlbl' `base'
}

* === Write LaTeX (shade only Components 1–2 when |loading| ≥ 0.50) ===
capture erase "${tables}/pca_loadings.tex"
texdoc init "${tables}/pca_loadings.tex", replace force

tex \begin{table}[h!]
tex \centering
tex \caption{Principal Components (Eigenvectors)}
tex \label{tab:pca-loadings}
tex \begin{tabular}{l*{`ncomp'}{c}}
tex \toprule
tex \textbf{Variable}
forvalues c = 1/`ncomp' {
    tex & \textbf{Component `c'}
}
tex \\\\
tex \midrule

forvalues r = 1/`nvar' {
    local rname : word `r' of `rowlbl'
    tex `rname'
    forvalues c = 1/`ncomp' {
        local val  = L[`r',`c']
        local abs  = abs(`val')
        local s    = strofreal(`val',"%6.4f")
        local cell = cond(`abs'>=0.50 & inrange(`c',1,2), "\cellcolor{red!30} `s'", "`s'")
        tex & `cell'
    }
    tex \\\\
}

tex \bottomrule
tex \end{tabular}
tex \end{table}

texdoc close
/********************************************************/
/*   Table B25. Correlation Matrix of Principal Components   */

/********************************************************/	
egen stigma_index_pca1 = std(pc1)
egen stigma_index_pca2 = std(pc2)

corr stigma_index_pca1 stigma_index_pca2 



* ====== Build lower-triangle LaTeX correlation table ======
matrix R = r(C)                 // correlation matrix
matrix P = r(sig)               // p-value matrix
local k = colsof(R)

local lab1 "PCA1"
local lab2 "PCA2"

* Initialize LaTeX table
capture erase "${tables}/pca_corr_princpcomp.tex"
texdoc init "${tables}/pca_corr_princpcomp.tex", replace force

tex \begin{table}[h!]
tex \centering
tex \caption{Correlation Matrix of Principal Components}
tex \label{tab:pca-corr-lower}
tex \begin{tabular}{l*{`k'}{c}}
tex \toprule
tex \textbf{Variable}
forvalues c = 1/`k' {
    tex & \textbf{`lab`c''}
}
tex \\\\
tex \midrule

forvalues r = 1/`k' {
    tex `lab`r''
    forvalues c = 1/`k' {
        if `c' > `r' {
            tex &        // blank above diagonal
        }
        else {
            local val = R[`r',`c']
            local p   = P[`r',`c']
            * significance stars
            local stars = cond(`p'<0.01,"***", cond(`p'<0.05,"**", cond(`p'<0.10,"*","")))
            if `r'==`c' {
                local cell "1.00"
            }
            else {
                local cell = strofreal(`val',"%5.2f") + "`stars'"
            }
            tex & `cell'
        }
    }
    tex \\\\
}
tex \bottomrule
tex \end{tabular}
tex \end{table}

texdoc close

/********************************************************/
/*   Table B34. Loading Plot   */

/********************************************************/	

clear
use "${clean}/mh_survey_analysis.dta" , replace


global outcomes_scaled2 "wtp_therapy_pct_self  wtp_therapy_pct_friend donation_pct "
global outcomes_clicks "clicks_all  clicks_unique"
 
global ncomp 2

*global vars perceived_stigma_students perceived_stigma_profs perceived_stigma_stt_parents guess_self_stigma prefer_low_gpa_over_mh_talk prefer_low_gpa_over_mh_sympt  
rename perceived_stigma_students stigma_students
rename perceived_stigma_profs stigma_professors
rename perceived_stigma_stt_parents stigma_parents
rename prefer_low_gpa_over_mh_sympt low_GPA_over_sympt
rename prefer_low_gpa_over_mh_talk low_GPA_over_talk

* Redefine the global macro with new variable names
global vars stigma_students stigma_professors stigma_parents guess_self_stigma low_GPA_over_sympt low_GPA_over_talk

*keep treatm_group uniqueid treat_any wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct advice_mention_prof_help $vars campus_support_prof_help_emot available_psyc_counsl financial_stress d_financ_stress distress wtp_therapy_self  wtp_therapy_friend

foreach var of global vars {
    egen `var'_std = std(`var')
}

global vars_std *_std

pca $vars_std, comp($ncomp) blanks(.3)

* Input the loading data
input str20 variable comp1 comp2
"stigma_students" 0.5358 0.0351
"stigma_professors" 0.5649 0.0359
"stigma_parents" 0.5359 -0.0216
"self_stigma" 0.3206 0.0934
"low_GPA_over_sympt" -0.0269 0.7059
"low_GPA_over_talk" -0.0551 0.7000
end

* Generate a variable for label positions (default to 3 o'clock)
gen vpos = 3

* Adjust label positions for problematic observations
replace vpos = 12 if variable == "low_GPA_over_sympt"    // Move left of marker
replace vpos = 6 if variable == "low_GPA_over_talk"     // Move below marker
replace vpos = 8 if variable == "self_stigma"           // Move below-left of marker
replace vpos = 6 if variable == "stigma_parents"       // Move above marker
replace vpos = 8 if variable == "stigma_students"       // Move above-right of marker
replace vpos = 12 if variable == "stigma_professors"     // Move below marker

* Create the scatter plot with adjusted label positions
scatter comp2 comp1, ///
    mlabel(variable) mlabvpos(vpos) mlabsize(small) ///
    xlabel(-0.2(0.2)0.6, format(%4.2f)) ///
    ylabel(-0.2(0.2)0.8, format(%4.2f)) ///
	xtitle("Component 1") ///
	ytitle("Component 2") ///
    title("") ///
    legend(off) msymbol(circle)
			 graph export "${figures}/loadingplot_PCA.png" , replace 
			 
			 
/********************************************************/
/*   Table B35 and Table B36 . Main Effects by Component 1 and Component 2 Stigma Index   */

/********************************************************/	
predict pc1 pc2, score
egen stigma_index_pca1 = std(pc1)
egen stigma_index_pca2 = std(pc2)

* Clear any previous estimates
eststo clear

local i = 1

foreach var of global outcomes_scaled2 {

    * Regressions with PCA1-based index
    eststo reg_pca1_continuous_`i', title("PCA1 Continuous `i'"): ///
        reg `var' i.treat_any##c.stigma_index_pca1, r

    * Regressions with PCA2-based index
    eststo reg_pca2_continuous_`i', title("PCA2 Continuous `i'"): ///
        reg `var' i.treat_any##c.stigma_index_pca2, r

    local i = `i' + 1
}

* Coefficient Plot for PCA1-based Stigma Index
coefplot (reg_pca1_continuous_1, label("WTP for therapy (self) (%)")) ///
         (reg_pca1_continuous_2, label("WTP for therapy for a friend (%)")) ///
         (reg_pca1_continuous_3, label("Donation for therapy (%)")), ///
    xline(0, lcolor(purple%50)) ///
    drop(_cons) ///
    legend(size(small)) ///
    title() ///
    xlabel(-0.1 "-10%" -0.05 "-5%" 0 "0%" 0.05 "5%" 0.1 "10%") ///
    ylabel(, labsize(vsmall)) /// Adjust the y-axis label size to very small
    levels(90) ///
    //note("90% Confidence Intervals.", size(medsmall)) ///

    //subtitle("(Effects by Treatment Group)", size(small))  
graph export "${figures}/coefplot_by_pca1_stigma.png", replace


* Coefficient Plot for PCA2-based Stigma Index with Smaller Y-axis Labels
coefplot (reg_pca2_continuous_1, label("WTP for therapy (self) (%)")) ///
         (reg_pca2_continuous_2, label("WTP for therapy for a friend (%)")) ///
         (reg_pca2_continuous_3, label("Donation for therapy (%)")), ///
    xline(0, lcolor(purple%50)) ///
    drop(_cons) ///
    legend(size(small)) ///
    title() ///
    xlabel(-0.1 "-10%" -0.05 "-5%" 0 "0%" 0.05 "5%" 0.1 "10%") ///
    ylabel(, labsize(vsmall)) /// Adjust the y-axis label size to very small
    levels(90) ///
    //note("90% Confidence Intervals.", size(medsmall)) ///
    //subtitle("(Effects by Treatment Group)", size(small))  
	graph export "${figures}/coefplot_by_pca2_stigma.png", replace
	

/********************************************************/
/*   Figure B37 and Figure B38. Stigma Indices and WTP/Donate   */

/********************************************************/
use "${clean}/mh_survey_analysis.dta" , replace 


	global main_outcomes   "wtp_therapy_self  wtp_therapy_friend  donation_pct   adv_prof_help_any  prefer_low_gpa_over_mh_sympt 	prefer_low_gpa_over_mh_talk "  // + clicks 

	global outcomes_scaled_1 	"wtp_therapy_pct_self  		wtp_therapy_pct_friend 	donation_pct  adv_prof_help_any    prefer_low_gpa_over_mh_sympt 	prefer_low_gpa_over_mh_talk "	
	global outcomes_scaled2 	"wtp_therapy_pct_self  		wtp_therapy_pct_friend 	donation_pct  adv_prof_help_any    pref_mh_symp_v_low_gpa 		pref_mh_talk_v_low_gpa"
	global outcomes_scaledZ 	"z_wtp_therapy_self  		z_wtp_therapy_friend  	donation_pct  adv_prof_help_any    prefer_low_gpa_over_mh_sympt 	prefer_low_gpa_over_mh_talk "
	global outcomes_scaled_winz "winz_wtp_therapy_pct_self  wtp_therapy_pct_friend 	donation_pct  adv_prof_help_any    pref_mh_symp_v_low_gpa 		pref_mh_talk_v_low_gpa"

	global outcomes_4   		"wtp_therapy_self  			wtp_therapy_friend  	donation_pct   adv_prof_help_any   "   

	global outcomes_4pct   		"wtp_therapy_pct_self  		wtp_therapy_pct_friend  donation_pct   adv_prof_help_any   "   
	global outcomes_4pct_winz   "winz_wtp_therapy_pct_self  wtp_therapy_pct_friend  donation_pct   adv_prof_help_any   "   

	
	global outcomes_3   		"wtp_therapy_self  			wtp_therapy_friend  	donation_pct   "   
	global outcomes_3pct   		"wtp_therapy_pct_self  		wtp_therapy_pct_friend  donation_pct   "   
	global outcomes_3pct_winz   "winz_wtp_therapy_pct_self  wtp_therapy_pct_friend  donation_pct   "   

	global y_advice   			"adv_prof_help_any  	adv_prof_help_count  adv_self_care   adv_prof_help_any    "   
	global y_advice_clicks   	"adv_prof_help_any  	adv_prof_help_count  adv_self_care   adv_prof_help_any  clicks_all  clicks_unique"   

	global y_advice3  			"adv_prof_help_any  	adv_prof_help_count  adv_self_care  "   
	global y_advice3_clicks   	"adv_prof_help_any  	adv_prof_help_count  adv_self_care   clicks_all  clicks_unique"   
	
	global y_advice2  			"adv_prof_help_any  	  adv_self_care       "   
	global y_advice2_clicks   	"adv_prof_help_any  	  adv_self_care   clicks_all  clicks_unique"   
	
		xtile stigma_index1_q4 = stigma_index1  , nquantiles(4)   

	xtile stigma_index2_q4 = stigma_index2  , nquantiles(4)   

		label define Lbl_stigma_index1   1  "Stigma index 1 Q1"  2  "Stigma index 1 Q2"  3  "Stigma index 1 Q3"  4  "Stigma index 1 Q4" , replace 
		
		label val  stigma_index1  Lbl_stigma_index1 
	
	* demand by stigma 
	graph bar wtp*pct*  donation_pct  adv_prof_help_any  if treat_any == 0 ,   ///
						over(stigma_index1_q4, relabel(1  "Stigma index 1 Q1"  2  "Stigma index 1 Q2"  3  "Stigma index 1 Q3"  4  "Stigma index 1 Q4" ) ) legend(pos(6))  				

		graph export  "${figures}/demand_mean_by_stigma_ind1_q4_controls.png" , replace 
		
		
	graph bar wtp*pct*  donation_pct  adv_prof_help_any  if treat_any == 0 ,   ///
						over(stigma_index2_q4, relabel(1  "Stigma index 2 Q1"  2  "Stigma index 2 Q2"  3  "Stigma index 2 Q3"  4  "Stigma index 2 Q4" ) ) legend(pos(6))  				

		graph export  "${figures}/demand_mean_by_stigma_ind2_q4_controls.png" , replace 
	
/********************************************************/
/*   Table B26. Correlation of Demand Variables with Stigma Indices   */

/********************************************************/	
	 
clear
use "${clean}/mh_survey_analysis.dta" , replace


global outcomes_scaled2 "wtp_therapy_pct_self  wtp_therapy_pct_friend donation_pct "
global outcomes_clicks "clicks_all  clicks_unique"
 
global ncomp 6

*global vars perceived_stigma_students perceived_stigma_profs perceived_stigma_stt_parents guess_self_stigma prefer_low_gpa_over_mh_talk prefer_low_gpa_over_mh_sympt  
rename perceived_stigma_students stigma_students
rename perceived_stigma_profs stigma_professors
rename perceived_stigma_stt_parents stigma_parents
rename prefer_low_gpa_over_mh_sympt low_GPA_over_sympt
rename prefer_low_gpa_over_mh_talk low_GPA_over_talk

* Redefine the global macro with new variable names
global vars stigma_students stigma_professors stigma_parents guess_self_stigma low_GPA_over_sympt low_GPA_over_talk

*keep treatm_group uniqueid treat_any wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct advice_mention_prof_help $vars campus_support_prof_help_emot available_psyc_counsl financial_stress d_financ_stress distress wtp_therapy_self  wtp_therapy_friend

foreach var of global vars {
    egen `var'_std = std(`var')
}

global vars_std *_std


pca $vars_std, comp($ncomp) blanks(.3)
predict pc1 pc2, score
egen stigma_index_pca1 = std(pc1)
egen stigma_index_pca2 = std(pc2)


global demand_vars "wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct"
global stigma_indices "stigma_index_pca1 stigma_index_pca2"
global stigma_components "stigma_students_std stigma_professors_std stigma_parents_std guess_self_stigma_std low_GPA_over_sympt_std low_GPA_over_talk_std"


pwcorr $demand_vars $stigma_indices, sig
	
* Grab matrices
matrix R = r(C)
matrix P = r(sig)

* Counts and row positions
local nd  : word count $demand_vars
local k   = `nd' + 2
local r1  = `nd' + 1   // row for stigma_index_pca1
local r2  = `nd' + 2   // row for stigma_index_pca2

* Column labels (nice names; avoid compound quotes headaches)
local cl1 "WTP Self"
local cl2 "WTP Friend"
local cl3 "Donation \%"
local cl4 "PCA1"
local cl5 "PCA2"

* Row labels
local rl1 "PCA1"
local rl2 "PCA2"

* -------- LaTeX: only the last two rows (PCA1, PCA2) ----------
capture erase "${tables}/corr_demand_vs_pca_lower.tex"
texdoc init "${tables}/corr_demand_vs_pca_lower.tex", replace force

tex \begin{table}[h!]
tex \centering
tex \caption{Correlation of Demand Variables with PCA Indices}
tex \label{tab:corr-demand-pca}
tex \begin{tabular}{l*{`k'}{c}}
tex \toprule
tex \textbf{Variable} & \textbf{`cl1'} & \textbf{`cl2'} & \textbf{`cl3'} & \textbf{`cl4'} & \textbf{`cl5'} \\\\
tex \midrule

* ---- Row: PCA1 ----
tex `rl1'
forvalues c = 1/`k' {
    local val = R[`r1',`c']
    local p   = P[`r1',`c']
    local stars = cond(`p'<0.01,"***", cond(`p'<0.05,"**", cond(`p'<0.10,"*","")))
    if `c'==`r1' {
        local cell "1.00"
    }
    else {
        local cell = strofreal(`val',"%5.2f") + "`stars'"
    }
    tex & `cell'
}
tex \\\\

* ---- Row: PCA2 ----
tex `rl2'
forvalues c = 1/`k' {
    local val = R[`r2',`c']
    local p   = P[`r2',`c']
    local stars = cond(`p'<0.01,"***", cond(`p'<0.05,"**", cond(`p'<0.10,"*","")))
    if `c'==`r2' {
        local cell "1.00"
    }
    else {
        local cell = strofreal(`val',"%5.2f") + "`stars'"
    }
    tex & `cell'
}
tex \\\\

tex \bottomrule
tex \end{tabular}
tex \end{table}
texdoc close

/********************************************************/
/*   Figure B39. Stigma Indices and WTP/Donate   */

/********************************************************/	

// Define the demand and stigma variables
global demand_vars "wtp_therapy_pct_self wtp_therapy_pct_friend donation_pct"
global stigma_indices "stigma_index_pca1 stigma_index_pca2"
global stigma_components "stigma_students_std stigma_professors_std stigma_parents_std guess_self_stigma_std low_GPA_over_sympt_std low_GPA_over_talk_std"


// Regressions to analyze relationships between demand variables and stigma indices
foreach demand_var of global demand_vars {
    // Regression with stigma index 1
    reg `demand_var' c.stigma_index_pca1
    
    // Regression with stigma index 2
    reg `demand_var' c.stigma_index_pca2
}


		
// Coefficient plot for stigma index 1-based regressions - Impact of Stigma Index 1 on Demand'
eststo clear
local i = 1
foreach demand_var of global demand_vars {
    eststo reg_pca1_`i', title("Stigma Index 1 - `demand_var'"): reg `demand_var' c.stigma_index_pca1
    local i = `i' + 1
}
coefplot (reg_pca1_1, label("WTP for therapy (self)")) ///
         (reg_pca1_2, label("WTP for therapy (friend)")) ///
         (reg_pca1_3, label("Donation for therapy")), ///
         xline(0, lcolor(red%50)) ///
         drop(_cons) ///
         title("") ///
         xlabel(-0.1 "-10%" -0.05 "-5%" 0 "0%" 0.05 "5%" 0.1 "10%") ///
         legend(size(small))
		 graph export "$figures/stigma1_on_wtp.png", replace


		 
// Coefficient plot for stigma index 2-based regressions - Impact of Stigma Index 2 on Demand
local i = 1
foreach demand_var of global demand_vars {
    eststo reg_pca2_`i', title("Stigma Index 2 - `demand_var'"): reg `demand_var' c.stigma_index_pca2
    local i = `i' + 1
}
coefplot (reg_pca2_1, label("WTP for therapy (self)")) ///
         (reg_pca2_2, label("WTP for therapy (friend)")) ///
         (reg_pca2_3, label("Donation for therapy")), ///
         xline(0, lcolor(red%50)) ///
         drop(_cons) ///
         title("") ///
         xlabel(-0.1 "-10%" -0.05 "-5%" 0 "0%" 0.05 "5%" 0.1 "10%") ///
         legend(size(small))
		 graph export "$figures/stigma2_on_wtp.png", replace
		 
	
/********************************************************/
/*   Figure B40. Stigma \& Mental Distress by Financial Stress   */

/********************************************************/	

use "${clean}/mh_survey_analysis.dta" , replace 


	global main_outcomes   "wtp_therapy_self  wtp_therapy_friend  donation_pct   adv_prof_help_any  prefer_low_gpa_over_mh_sympt 	prefer_low_gpa_over_mh_talk "  // + clicks 

	global outcomes_scaled_1 	"wtp_therapy_pct_self  		wtp_therapy_pct_friend 	donation_pct  adv_prof_help_any    prefer_low_gpa_over_mh_sympt 	prefer_low_gpa_over_mh_talk "	
	global outcomes_scaled2 	"wtp_therapy_pct_self  		wtp_therapy_pct_friend 	donation_pct  adv_prof_help_any    pref_mh_symp_v_low_gpa 		pref_mh_talk_v_low_gpa"
	global outcomes_scaledZ 	"z_wtp_therapy_self  		z_wtp_therapy_friend  	donation_pct  adv_prof_help_any    prefer_low_gpa_over_mh_sympt 	prefer_low_gpa_over_mh_talk "
	global outcomes_scaled_winz "winz_wtp_therapy_pct_self  wtp_therapy_pct_friend 	donation_pct  adv_prof_help_any    pref_mh_symp_v_low_gpa 		pref_mh_talk_v_low_gpa"

	global outcomes_4   		"wtp_therapy_self  			wtp_therapy_friend  	donation_pct   adv_prof_help_any   "   

	global outcomes_4pct   		"wtp_therapy_pct_self  		wtp_therapy_pct_friend  donation_pct   adv_prof_help_any   "   
	global outcomes_4pct_winz   "winz_wtp_therapy_pct_self  wtp_therapy_pct_friend  donation_pct   adv_prof_help_any   "   

	
	global outcomes_3   		"wtp_therapy_self  			wtp_therapy_friend  	donation_pct   "   
	global outcomes_3pct   		"wtp_therapy_pct_self  		wtp_therapy_pct_friend  donation_pct   "   
	global outcomes_3pct_winz   "winz_wtp_therapy_pct_self  wtp_therapy_pct_friend  donation_pct   "   

	global y_advice   			"adv_prof_help_any  	adv_prof_help_count  adv_self_care   adv_prof_help_any    "   
	global y_advice_clicks   	"adv_prof_help_any  	adv_prof_help_count  adv_self_care   adv_prof_help_any  clicks_all  clicks_unique"   

	global y_advice3  			"adv_prof_help_any  	adv_prof_help_count  adv_self_care  "   
	global y_advice3_clicks   	"adv_prof_help_any  	adv_prof_help_count  adv_self_care   clicks_all  clicks_unique"   
	
	global y_advice2  			"adv_prof_help_any  	  adv_self_care       "   
	global y_advice2_clicks   	"adv_prof_help_any  	  adv_self_care   clicks_all  clicks_unique"   
		
		* stigma by fin stress 	
	graph bar stigma_index1 distress , over(financial_stress)   ///
				horizontal   bar(1 , color(lavender%50) )  bar(2 , color(purple%50) )  ///
				legend(label(1 "Stigma Index") label(2 "% in Distress") pos(6) row(1))
			
			graph export  "${figures}/stigma_w_distress_by_financial_stress.png" , replace 
			
/********************************************************/
/*   Figure B41. Relationship Between Stigma Index and Perceived Use of Professional Mental Health Services   */

/********************************************************/	


		binscatter guess_therapy_use_pct   z_stigma_index1 , color(%50)  xtitle("Standard. Stigma Index (Z Score 1)")  ytitle("Guess % of Students Using Prof Help") lcolor(purple%50)
			
			graph export  "${figures}/therapy_guess_by_stigma_index1_binscattter.png" , replace 

	